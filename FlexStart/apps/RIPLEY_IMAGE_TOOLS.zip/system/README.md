# Ripley Image Tools

Suite de herramientas de procesamiento de imágenes para Ripley Corporation.

## Aplicaciones Incluidas

### 1. Descargador de Imágenes Chile
Descarga automática de imágenes de productos desde servidores de Ripley Chile.

**Características:**
- Descarga desde Rimage y Store
- Copia desde carpeta local
- Agrupación por padre+color
- Reportes de faltantes

### 2. Descargador de Imágenes Perú
Descarga automática de imágenes para operaciones de Perú.

**Características:**
- Descarga desde URLs Perú
- Copia desde carpeta local
- Configuración region-específica
- Reportes de procesamiento

### 3. Flujo Productivo CL→PE
Proceso completo de conversión de imágenes de Chile a Perú.

**Pasos:**
1. Descarga de imágenes
2. Renombrar carpetas (SKU → EAN)
3. Normalizar extensiones (.webp)
4. Renombrar imágenes

## Requisitos

- Python 3.11+
- Ver `requirements/requirements.txt` para dependencias completas

## Instalación

```bash
# 1. Clonar repositorio o descargar release
git clone https://github.com/your-org/ripley-image-tools.git
cd ripley-image-tools

# 2. Instalar dependencias
pip install -r requirements/requirements.txt

# 3. Ejecutar launcher
python launcher.py
```

## Uso

1. Ejecutar `launcher.py`
2. Se abrirá navegador con página de login
3. Autenticarse con correo corporativo de Ripley
4. Acceder al dashboard con las 3 herramientas
5. Hacer clic en cualquier herramienta para abrirla en nueva pestaña

## Autenticación

El sistema usa autenticación SharePoint/Microsoft SSO:
- Cliente ID: Azure CLI public client
- Authority: login.microsoftonline.com/common
- Cache de tokens: `~/.ripley_imagetools_cache/`

## Actualización

El launcher verifica automáticamente si hay nuevas versiones en GitHub Releases y permite actualizar con un clic.

## Estructura del Proyecto

```
RipleyImageTools/
├── launcher.py              # Lanzador principal
├── updater.py               # Sistema de actualización
├── config.ini               # Configuración
├── VERSION.txt              # Versión actual
├── backend/                 # Backend FastAPI
│   ├── app.py              # Gateway central
│   └── auth/               # Autenticación
├── frontend/                # Dashboard web
│   ├── index.html          # Login
│   └── dashboard.html      # Panel principal
├── apps/                    # 3 aplicaciones
│   ├── descargador_imagenes/
│   ├── descargador_imagenes_peru/
│   └── flujo_productivo/
└── requirements/
    └── requirements.txt     # Dependencias
```

## Desarrollo

### Ejecutar en modo desarrollo

```bash
# Backend standalone
cd backend
uvicorn app:app --reload --port 8005

# Launcher con auto-reload
python launcher.py
```

### Crear release

```bash
# 1. Actualizar VERSION.txt
echo "1.0.1" > VERSION.txt

# 2. Commit y tag
git commit -am "Release v1.0.1"
git tag v1.0.1
git push origin v1.0.1

# 3. GitHub Actions crea release automáticamente
```

## Soporte

Para reportar bugs o solicitar funcionalidades, crear un issue en GitHub.

## Licencia

© 2025 Ripley Corporation. Todos los derechos reservados.
