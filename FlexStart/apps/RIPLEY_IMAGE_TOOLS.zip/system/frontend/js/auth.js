/**
 * Authentication Module - Ripley Image Tools
 * Handles Microsoft/SharePoint SSO authentication
 */

document.addEventListener('DOMContentLoaded', () => {
    const loginBtn = document.getElementById('login-btn');

    if (loginBtn) {
        loginBtn.addEventListener('click', login);
    }
});

async function login() {
    const btn = document.getElementById('login-btn');

    // Disable button and show loading state
    btn.disabled = true;
    btn.textContent = 'Autenticando...';

    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json();

        if (data.success) {
            // Successful authentication - redirect to dashboard
            window.location.href = data.redirect;
        } else {
            // Authentication failed
            showError('Error de autenticación: ' + (data.error || 'Error desconocido'));
            resetButton(btn);
        }
    } catch (error) {
        // Network or server error
        showError('Error de conexión: ' + error.message);
        resetButton(btn);
    }
}

function resetButton(btn) {
    btn.disabled = false;
    btn.innerHTML = `
        <svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="10" height="10" fill="#f25022"/>
            <rect x="11" width="10" height="10" fill="#7fba00"/>
            <rect y="11" width="10" height="10" fill="#00a4ef"/>
            <rect x="11" y="11" width="10" height="10" fill="#ffb900"/>
        </svg>
        Iniciar sesión con Microsoft
    `;
}

function showError(message) {
    alert(message);  // Simple alert for now - can be replaced with better UI
}
