/**
 * Dashboard Module - Ripley Image Tools
 * Handles dashboard UI interactions and authentication checks
 */

// Verificar autenticación al cargar la página
document.addEventListener('DOMContentLoaded', async () => {
    // Check if user is authenticated
    await requireAuth();

    // Setup logout button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', logout);
    }

    // Display user email if available
    displayUserInfo();
});

/**
 * Verifica si el usuario está autenticado.
 * Si no lo está, redirige a la página de login.
 */
async function requireAuth() {
    try {
        const response = await fetch('/api/auth/status');
        const data = await response.json();

        if (!data.authenticated) {
            // User is not authenticated - redirect to login
            window.location.href = '/';
        }
    } catch (error) {
        console.error('Error checking authentication:', error);
        // On error, redirect to login for safety
        window.location.href = '/';
    }
}

/**
 * Cierra la sesión del usuario y redirige al login.
 */
async function logout() {
    try {
        await fetch('/api/auth/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        // Redirect to login page
        window.location.href = '/';
    } catch (error) {
        console.error('Error during logout:', error);
        // Even on error, redirect to login
        window.location.href = '/';
    }
}

/**
 * Abre una herramienta en una nueva pestaña/ventana.
 * @param {string} url - URL de la herramienta
 */
function openApp(url) {
    // Open in new tab
    window.open(url, '_blank');
}

/**
 * Muestra la información del usuario en la navbar.
 */
async function displayUserInfo() {
    try {
        const response = await fetch('/api/auth/user');
        const data = await response.json();

        const userEmailElement = document.querySelector('.user-email-text');
        if (userEmailElement && data.email) {
            userEmailElement.textContent = data.email;
        }
    } catch (error) {
        console.log('Could not fetch user info:', error);
        // Silently fail - user info is optional
    }
}
