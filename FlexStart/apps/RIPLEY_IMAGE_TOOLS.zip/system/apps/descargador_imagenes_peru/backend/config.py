# backend/config.py
"""
Configuración centralizada para Descargador de Imágenes PERÚ.

Este archivo contiene todas las constantes, URLs y parámetros de configuración
utilizados en el proceso de descarga y procesamiento de imágenes para Ripley Perú.

IMPORTANTE - SEGURIDAD CORPORATIVA:
    - NO modificar URLs sin aprobación del equipo de seguridad
    - Las URLs de Ripley Perú están aprobadas y validadas
    - El User-Agent está configurado según estándares corporativos
    - Los timeouts están optimizados para evitar bloqueos por rate limiting
"""

# === CONFIGURACIÓN DE DESCARGA ===

# User Agent para requests HTTP (NO MODIFICAR sin aprobación)
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

# Timeouts para conexiones HTTP (connect_timeout, read_timeout)
# Estos son los valores BASE para lotes pequeños
DEFAULT_REQUEST_TIMEOUT = (10, 20)

# Timeouts aumentados para lotes grandes (>100 SKUs)
# El servidor puede estar más saturado con descargas masivas
LARGE_BATCH_REQUEST_TIMEOUT = (15, 30)

# === CONFIGURACIÓN DE REINTENTOS ===

# Número total de reintentos para requests fallidos (MEJORADO de 5 a 8)
RETRY_TOTAL = 8

# Factor de backoff exponencial entre reintentos (segundos)
RETRY_BACKOFF_FACTOR = 2

# Códigos HTTP que deben reintentarse
RETRY_STATUS_FORCELIST = [429, 500, 502, 503, 504]

# Reintentos específicos para conexión y lectura (MEJORADO de 3 a 5)
RETRY_CONNECT = 5
RETRY_READ = 5

# === CONFIGURACIÓN DE POOL DE CONEXIONES ===

# Tamaño del pool de conexiones HTTP (número de conexiones simultáneas)
HTTP_POOL_CONNECTIONS = 20

# Tamaño máximo del pool (máximo de conexiones que pueden ser reusadas)
HTTP_POOL_MAXSIZE = 30

# === CONFIGURACIÓN DE RATE LIMITING ===

# Delay entre el procesamiento de cada SKU (segundos) - BASE para lotes pequeños
DELAY_BETWEEN_SKUS = 2.0

# Delay entre el procesamiento de cada SKU para LOTES GRANDES (>100 SKUs)
DELAY_BETWEEN_SKUS_LARGE_BATCH = 3.5

# Umbral para considerar un lote como "grande"
LARGE_BATCH_THRESHOLD = 100

# Jitter máximo aleatorio para agregar a los delays (segundos)
# Esto ayuda a evitar patrones detectables por rate limiters
DELAY_JITTER_MAX = 0.8

# Delay entre la descarga de cada imagen del mismo SKU (segundos)
DELAY_BETWEEN_IMAGES = 0.5

# Delay adicional cuando se recibe error 429 (Too Many Requests)
DELAY_ON_429_ERROR = 10.0

# === URLS BASE (NO MODIFICAR - APROBADAS POR SEGURIDAD CORPORATIVA) ===

# URL primaria: Rimage Ripley PERÚ (descarga principal)
RIMAGE_BASE_URL_PATTERN = "https://rimage.ripley.com.pe/home.ripley/Attachment/WOP/1/{sku_cl}/{tipo}-{sku_cl}.{ext}"

# URL secundaria: Store Ripley PERÚ (descarga fallback - WOP_5 sin CODDEPTO en ruta)
STORE_BASE_URL_PATTERN = "https://home.ripley.com.pe/Attachment/WOP_5/{sku_cl}/{sku_cl}"

# === TIPOS DE DESCARGA DISPONIBLES ===

# Definición de los tipos de descarga que el usuario puede seleccionar
DOWNLOAD_TYPES = {
    "rimage_only": {
        "name": "Rimage Ripley",
        "description": "Descarga desde rimage.ripley.cl",
        "url_pattern": RIMAGE_BASE_URL_PATTERN,
        "requires_coddepto": False,
        "image_types": ["full_image"] + [f"image{i}" for i in range(1, 16)],
        "extensions": ["webp", "jpg", ".", ""],
        "icon": "🎯"
    },
    "store_only": {
        "name": "Store Ripley (Tienda) PERÚ",
        "description": "Descarga desde WOP_5 (Perú) - No requiere CODDEPTO",
        "url_pattern": STORE_BASE_URL_PATTERN,
        "requires_coddepto": False,
        "image_types": ["_2", "-1", "-2", "-3", "-4", "-5", "-6", "-7", "-8", "-9", "-10", "-11", "-12", "-13", "-14", "-15", "-16", "-17", "-18"],
        "extensions": ["jpg"],
        "icon": "🏪"
    },
    "both_fallback": {
        "name": "Rimage + WOP_5 (Perú)",
        "description": "Intenta Rimage primero, si no encuentra imágenes usa WOP_5 como respaldo",
        "url_pattern": None,  # Usa ambos patrones
        "requires_coddepto": False,  # Perú no requiere CODDEPTO (WOP_5 es directo)
        "image_types": None,  # Usa ambos conjuntos
        "extensions": None,  # Usa ambos conjuntos
        "icon": "🔄"
    }
}

# === CONFIGURACIÓN DE TIPOS DE IMAGEN ===

# Tipos de imagen a descargar (primaria)
# - "full_image": Imagen principal del producto
# - "image1" a "image15": Imágenes adicionales del producto
IMAGE_TYPES_PRIMARY = ["full_image"] + [f"image{i}" for i in range(1, 16)]

# Extensiones de imagen a probar (en orden de prioridad)
# - "webp": Formato moderno comprimido
# - "jpg": Formato estándar
# - ".": Solo punto (sin extensión explícita)
# - "": Sin punto ni extensión
IMAGE_EXTENSIONS = ["webp", "jpg", ".", ""]

# === CONFIGURACIÓN DE APLICACIÓN ===

# Nombre de la carpeta de proceso (relativa al proyecto)
PROCESS_FOLDER_NAME = 'Proceso'

# Extensiones de archivo Excel permitidas
ALLOWED_EXCEL_EXTENSIONS = {'xlsx', 'xls'}

# === CONFIGURACIÓN DE EVENTOS Y MEMORIA ===

# Límite máximo de eventos de procesamiento en memoria
# (para evitar consumo excesivo de RAM en descargas largas)
MAX_PROCESSING_EVENTS = 50

# === CONFIGURACIÓN DE ARCHIVOS ===

# Sufijo para archivos Excel procesados temporalmente
PROCESSED_EXCEL_SUFFIX = '_processed.xlsx'

# === CONFIGURACIÓN DE BÚSQUEDA EXHAUSTIVA CODDEPTO ===

# Rango por defecto para búsqueda exhaustiva de CODDEPTO (cuando no se especifica rango personalizado)
# PERÚ: Rango D100 - D503
DEFAULT_CODDEPTO_RANGE_START = 100
DEFAULT_CODDEPTO_RANGE_END = 503

# === NOTAS DE CONFIGURACIÓN ===
"""
DELAYS Y RATE LIMITING:
- Los delays están calibrados para evitar bloqueos por rate limiting de Ripley
- DELAY_BETWEEN_SKUS (2.0s): Evita sobrecarga del servidor
- DELAY_BETWEEN_IMAGES (0.5s): Balance entre velocidad y estabilidad
- DELAY_ON_429_ERROR (10.0s): Tiempo de espera cuando se excede el límite

URLS Y PATRONES:
- Las URLs siguen el patrón oficial de Ripley Perú
- No modificar sin confirmar con el equipo de contenido de Ripley
- Los patterns usan f-string formatting: {sku_cl}, {tipo}, {ext}
- NOTA: Store Perú usa WOP_5 directo, sin carpetas de CODDEPTO en la ruta

EXTENSIONES Y TIPOS:
- WebP es prioritaria por menor tamaño y mejor calidad
- JPG como fallback estándar
- Variantes con/sin punto para compatibilidad con diferentes CDNs
- IMAGE_TYPES cubre hasta 15 imágenes adicionales por producto
"""
