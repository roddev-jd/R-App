# backend/utils/data_cleaning.py
"""
Utilidades para limpieza y transformación de datos Excel.

Este módulo centraliza toda la lógica de limpieza de datos para evitar
duplicación de código entre diferentes módulos.
"""

import pandas as pd
from typing import Any, Optional


def clean_excel_value(value: Any) -> Optional[str]:
    """
    Limpia un valor individual de Excel.

    Proceso de limpieza:
    1. Verifica si el valor es NaN o None
    2. Convierte a string y elimina espacios
    3. Verifica si es un valor vacío o 'nan' como string
    4. Elimina '.0' de números float (ej: "123456.0" -> "123456")
    5. Convierte a mayúsculas para consistencia

    Args:
        value: Valor a limpiar (puede ser int, float, str, None, NaN)

    Returns:
        String limpio y en mayúsculas, o None si el valor es vacío/inválido

    Examples:
        >>> clean_excel_value(123456.0)
        '123456'
        >>> clean_excel_value("  ABC123  ")
        'ABC123'
        >>> clean_excel_value(pd.NA)
        None
        >>> clean_excel_value("nan")
        None
        >>> clean_excel_value("")
        None
    """
    # Verificar NaN/None
    if pd.isna(value):
        return None

    # Convertir a string y limpiar espacios
    s_value = str(value).strip()

    # Verificar valores vacíos o 'nan' como string
    if s_value.lower() in ('nan', '', 'none', 'null'):
        return None

    # Quitar .0 de números float (ej: "123456.0" -> "123456")
    if '.' in s_value:
        base, decimal_part = s_value.rsplit('.', 1)
        # Solo quitar si es exactamente ".0" y la base es numérica
        if decimal_part == '0' and base.replace('-', '').replace('+', '').isdigit():
            s_value = base

    # Convertir a mayúsculas para consistencia
    return s_value.upper()


def clean_excel_column(series: pd.Series) -> pd.Series:
    """
    Limpia una columna completa de DataFrame aplicando clean_excel_value a cada elemento.

    Args:
        series: Serie de pandas a limpiar

    Returns:
        Serie limpia con valores procesados

    Examples:
        >>> df = pd.DataFrame({'SKU': [123456.0, '  ABC  ', 'nan', None, 'xyz789']})
        >>> clean_excel_column(df['SKU'])
        0    123456
        1    ABC
        2    None
        3    None
        4    XYZ789
        Name: SKU, dtype: object
    """
    if series is None:
        return pd.Series([], dtype='object')

    return series.apply(clean_excel_value)


def validate_excel_columns(df: pd.DataFrame, required_columns: list[str]) -> tuple[bool, Optional[str]]:
    """
    Valida que un DataFrame tenga las columnas requeridas.

    Args:
        df: DataFrame a validar
        required_columns: Lista de nombres de columnas requeridas

    Returns:
        Tupla (es_valido, mensaje_error)
        - es_valido: True si todas las columnas existen, False en caso contrario
        - mensaje_error: None si es válido, mensaje descriptivo si falta alguna columna

    Examples:
        >>> df = pd.DataFrame({'SKU_CL': [1, 2], 'EAN_HIJO': [3, 4]})
        >>> validate_excel_columns(df, ['SKU_CL', 'EAN_HIJO'])
        (True, None)
        >>> validate_excel_columns(df, ['SKU_CL', 'MISSING'])
        (False, "Columna requerida 'MISSING' no encontrada en el Excel")
    """
    missing_columns = []

    for col in required_columns:
        if col not in df.columns:
            missing_columns.append(col)

    if missing_columns:
        if len(missing_columns) == 1:
            error_msg = f"Columna requerida '{missing_columns[0]}' no encontrada en el Excel."
        else:
            cols_str = "', '".join(missing_columns)
            error_msg = f"Columnas requeridas '{cols_str}' no encontradas en el Excel."

        available_cols = ", ".join(df.columns.tolist())
        error_msg += f" Columnas disponibles: {available_cols}"

        return False, error_msg

    return True, None


def clean_sku_ean_mapping(
    df: pd.DataFrame,
    sku_column: str,
    ean_column: str
) -> tuple[list[str], dict[str, str]]:
    """
    Procesa un DataFrame y extrae lista de SKUs únicos y mapeo SKU->EAN.

    Esta función:
    1. Limpia ambas columnas (SKU y EAN)
    2. Elimina filas con valores NaN/vacíos
    3. Retorna lista de SKUs únicos para verificación
    4. Retorna diccionario de mapeo SKU->EAN para renombrado

    Args:
        df: DataFrame con datos de Excel
        sku_column: Nombre de la columna de SKU (ya debe existir en df)
        ean_column: Nombre de la columna de EAN (ya debe existir en df)

    Returns:
        Tupla (sku_list, sku_ean_map):
        - sku_list: Lista de SKUs únicos y limpios
        - sku_ean_map: Diccionario {SKU: EAN} con mapeo limpio

    Examples:
        >>> df = pd.DataFrame({
        ...     'SKU_CL': [123456.0, 789012.0, 'nan'],
        ...     'EAN_HIJO': [111.0, 222.0, 333.0]
        ... })
        >>> sku_list, mapping = clean_sku_ean_mapping(df, 'SKU_CL', 'EAN_HIJO')
        >>> sku_list
        ['123456', '789012']
        >>> mapping
        {'123456': '111', '789012': '222'}
    """
    # Limpiar columnas
    df_clean = df.copy()
    df_clean[sku_column] = clean_excel_column(df[sku_column])
    df_clean[ean_column] = clean_excel_column(df[ean_column])

    # Eliminar filas con SKU o EAN vacíos
    df_clean = df_clean.dropna(subset=[sku_column, ean_column])

    # Lista de SKUs únicos
    sku_list = df_clean[sku_column].unique().tolist()

    # Crear mapeo SKU->EAN
    # Si hay múltiples EANs para un SKU, tomamos el primero
    sku_ean_map = {}
    for _, row in df_clean.iterrows():
        sku = row[sku_column]
        ean = row[ean_column]

        # Verificar que ambos valores sean válidos
        if sku and ean and str(sku).upper() != 'NAN' and str(ean).upper() != 'NAN':
            # Si el SKU aún no está en el mapa, agregarlo
            if sku not in sku_ean_map:
                sku_ean_map[sku] = ean

    return sku_list, sku_ean_map


# Mantener nombre legacy para compatibilidad durante transición
def _clean_excel_string_column(series: pd.Series) -> pd.Series:
    """
    DEPRECATED: Usar clean_excel_column() en su lugar.

    Función legacy mantenida temporalmente para compatibilidad.
    """
    return clean_excel_column(series)
