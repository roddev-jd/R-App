"""Thread-safe application state model for descargador_imagenes backend."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from threading import Lock
from typing import Any, Dict, List, Optional


ProcessingEvent = Dict[str, Any]


@dataclass
class DescargadorImagenesState:
    """State container for the descargador_imagenes processing session."""

    # Archivos y rutas
    excel_file_path: Optional[str] = None
    excel_file_name: Optional[str] = None
    download_base_path: Optional[str] = None
    
    # Modo de operación y ubicación de origen para copiado local
    operation_mode: str = "download"  # "download" o "local_copy"
    local_source_path: Optional[str] = None  # Ruta de origen para copiado local
    
    # Tipo de descarga seleccionado
    download_type: str = "both_fallback"  # "rimage_only", "store_only", "both_fallback"

    # Rango personalizado para búsqueda exhaustiva CODDEPTO (solo para store_only)
    coddepto_range_start: Optional[int] = None  # Inicio del rango (ej: 100)
    coddepto_range_end: Optional[int] = None    # Fin del rango (ej: 462)

    # Lista específica de CODDEPTOs desde planilla (prioridad sobre rango)
    coddepto_custom_list: Optional[List[str]] = None  # Lista de valores específicos (ej: ["D120", "D145", "D230"])

    # Agrupación por padre+color
    group_by_parent_color: bool = False  # Si True, agrupa SKUs por codskupadrelargo+color
    grouping_columns_available: bool = False  # Si True, existen columnas 'color' y 'codskupadrelargo'
    parent_color_groups: Dict[tuple, List[str]] = field(default_factory=dict)  # Grupos: {(parent, color): [sku1, sku2, ...]}
    representative_skus: List[str] = field(default_factory=list)  # Lista de SKUs representantes de cada grupo
    skipped_by_grouping_skus: List[str] = field(default_factory=list)  # SKUs omitidos por agrupación

    # Estado de descarga (simplificado)
    download_completed: bool = False
    download_in_progress: bool = False

    # Mensajes y errores
    last_error_message: Optional[str] = None
    current_status_message: str = "Aplicación lista. Esperando carga de archivo."

    # Datos de verificación
    sku_cl_list_for_verification: List[str] = field(default_factory=list)
    sku_ean_map_for_verification: Dict[str, str] = field(default_factory=dict)

    # Procesamiento en tiempo real
    current_processing_sku: Optional[str] = None
    current_image_type: Optional[str] = None
    current_url: Optional[str] = None
    total_skus: int = 0
    processed_skus: int = 0
    successful_downloads: int = 0
    failed_downloads: int = 0
    processing_events: List[ProcessingEvent] = field(default_factory=list)

    # Control de descarga
    should_cancel_download: bool = False
    download_error: Optional[str] = None
    download_results: Optional[Dict[str, Any]] = None

    # Thread safety
    _lock: Lock = field(default_factory=Lock, init=False, repr=False)

    def reset(self, processed_excel_suffix: Optional[str] = None) -> None:
        """Reset state to initial values, optionally removing temp excel artefacts."""
        with self._lock:
            if self.excel_file_path and processed_excel_suffix and self.excel_file_path.endswith(processed_excel_suffix):
                try:
                    import os
                    if os.path.exists(self.excel_file_path):
                        os.remove(self.excel_file_path)
                except Exception:
                    # Ignorar errores al eliminar el archivo temporal
                    pass

            self.excel_file_path = None
            self.excel_file_name = None
            self.download_base_path = None
            self.operation_mode = "download"
            self.local_source_path = None
            self.download_type = "both_fallback"
            self.coddepto_range_start = None
            self.coddepto_range_end = None
            self.coddepto_custom_list = None
            self.group_by_parent_color = False
            self.grouping_columns_available = False
            self.parent_color_groups.clear()
            self.representative_skus.clear()
            self.skipped_by_grouping_skus.clear()
            self.download_completed = False
            self.download_in_progress = False
            self.last_error_message = None
            self.current_status_message = "Estado reiniciado. Esperando nueva carga de archivo."
            self.sku_cl_list_for_verification.clear()
            self.sku_ean_map_for_verification.clear()
            self.current_processing_sku = None
            self.current_image_type = None
            self.current_url = None
            self.total_skus = 0
            self.processed_skus = 0
            self.successful_downloads = 0
            self.failed_downloads = 0
            self.processing_events.clear()
            self.should_cancel_download = False
            self.download_error = None
            self.download_results = None

    def to_dict(self) -> Dict[str, Any]:
        """Return a shallow copy of the state for JSON responses."""
        with self._lock:
            return {
                "excel_file_path": self.excel_file_path,
                "excel_file_name": self.excel_file_name,
                "download_base_path": self.download_base_path,
                "operation_mode": self.operation_mode,
                "local_source_path": self.local_source_path,
                "download_type": self.download_type,
                "coddepto_range_start": self.coddepto_range_start,
                "coddepto_range_end": self.coddepto_range_end,
                "coddepto_custom_list": list(self.coddepto_custom_list) if self.coddepto_custom_list else None,
                "group_by_parent_color": self.group_by_parent_color,
                "grouping_columns_available": self.grouping_columns_available,
                "parent_color_groups": {str(k): v for k, v in self.parent_color_groups.items()},  # Convertir tuple keys a strings para JSON
                "representative_skus": list(self.representative_skus),
                "skipped_by_grouping_skus": list(self.skipped_by_grouping_skus),
                "download_completed": self.download_completed,
                "download_in_progress": self.download_in_progress,
                "last_error_message": self.last_error_message,
                "current_status_message": self.current_status_message,
                "sku_cl_list_for_verification": list(self.sku_cl_list_for_verification),
                "sku_ean_map_for_verification": dict(self.sku_ean_map_for_verification),
                "current_processing_sku": self.current_processing_sku,
                "current_image_type": self.current_image_type,
                "current_url": self.current_url,
                "total_skus": self.total_skus,
                "processed_skus": self.processed_skus,
                "successful_downloads": self.successful_downloads,
                "failed_downloads": self.failed_downloads,
                "processing_events": [dict(event) for event in self.processing_events],
                "should_cancel_download": self.should_cancel_download,
                "download_error": self.download_error,
                "download_results": dict(self.download_results) if isinstance(self.download_results, dict) else self.download_results,
            }

    def record_processing_event(
        self,
        event_type: str,
        message: str,
        *,
        sku: Optional[str] = None,
        image_type: Optional[str] = None,
        url: Optional[str] = None,
        max_events: int = 100,
    ) -> ProcessingEvent:
        """Append a processing event with thread safety and truncate history."""
        timestamp = time.strftime("%H:%M:%S")
        event: ProcessingEvent = {
            "timestamp": timestamp,
            "type": event_type,
            "message": message,
            "sku": sku,
            "image_type": image_type,
            "url": url,
        }

        with self._lock:
            if sku is not None:
                self.current_processing_sku = sku
            if image_type is not None:
                self.current_image_type = image_type
            if url is not None:
                self.current_url = url

            self.processing_events.append(event)
            if len(self.processing_events) > max_events:
                self.processing_events = self.processing_events[-max_events:]

        return event

    def set_download_results(self, results: Optional[Dict[str, Any]]) -> None:
        with self._lock:
            self.download_results = dict(results) if isinstance(results, dict) else results

    # --- Dictionary-style helpers for backwards compatibility ---
    def _ensure_known_field(self, key: str) -> None:
        if not hasattr(self, key):
            raise KeyError(key)

    def __getitem__(self, key: str) -> Any:
        with self._lock:
            self._ensure_known_field(key)
            return getattr(self, key)

    def __setitem__(self, key: str, value: Any) -> None:
        with self._lock:
            self._ensure_known_field(key)
            setattr(self, key, value)

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return getattr(self, key, default)

    def update(self, values: Dict[str, Any]) -> None:
        with self._lock:
            for key, value in values.items():
                self._ensure_known_field(key)
                setattr(self, key, value)

    def lock(self) -> Lock:
        """Expose lock for advanced use within context managers."""
        return self._lock
