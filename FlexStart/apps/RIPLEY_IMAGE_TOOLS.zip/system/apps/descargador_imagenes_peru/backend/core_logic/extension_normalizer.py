# backend/core_logic/extension_normalizer.py
"""
Módulo para normalización de extensiones de archivos de imagen.

Este módulo se encarga de:
1. Detectar archivos sin extensión o con extensión incompleta
2. Agregar la extensión .webp a archivos sin extensión
3. Convertir archivos .jpg/.jpeg a .webp
4. Mantener integridad de otros formatos válidos
"""

import os
import logging
from pathlib import Path
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)


def _get_file_extension(filename: str) -> str:
    """
    Obtiene la extensión de un archivo, manejando casos especiales.
    
    Args:
        filename: Nombre del archivo
        
    Returns:
        Extensión del archivo (con punto) o cadena vacía si no tiene
        
    Examples:
        >>> _get_file_extension("imagen.jpg")
        ".jpg"
        >>> _get_file_extension("imagen.")
        "."
        >>> _get_file_extension("imagen")
        ""
    """
    if '.' not in filename:
        return ""
    
    # Obtener todo después del último punto
    ext = filename[filename.rfind('.'):]
    return ext


def _should_normalize_to_webp(filename: str) -> bool:
    """
    Determina si un archivo debe normalizarse a .webp.
    
    Args:
        filename: Nombre del archivo
        
    Returns:
        True si debe normalizarse, False en caso contrario
    """
    ext = _get_file_extension(filename).lower()
    
    # Casos que requieren normalización:
    # 1. Sin extensión
    # 2. Solo punto
    # 3. Extensión .jpg o .jpeg
    if ext == "":
        return True
    if ext == ".":
        return True
    if ext in [".jpg", ".jpeg"]:
        return True
    
    return False


def _normalize_filename(filename: str) -> str:
    """
    Normaliza el nombre de archivo agregando o corrigiendo la extensión.
    
    Args:
        filename: Nombre original del archivo
        
    Returns:
        Nombre normalizado con extensión .webp
        
    Examples:
        >>> _normalize_filename("imagen")
        "imagen.webp"
        >>> _normalize_filename("imagen.")
        "imagen.webp"
        >>> _normalize_filename("imagen.jpg")
        "imagen.webp"
        >>> _normalize_filename("imagen.png")
        "imagen.png"
    """
    ext = _get_file_extension(filename)
    
    if ext == "":
        # Sin extensión: agregar .webp
        return f"{filename}.webp"
    elif ext == ".":
        # Solo punto: reemplazar por .webp
        return f"{filename[:-1]}.webp"
    elif ext.lower() in [".jpg", ".jpeg"]:
        # JPG/JPEG: cambiar a .webp
        base = filename[:filename.rfind('.')]
        return f"{base}.webp"
    else:
        # Mantener otras extensiones (.png, .gif, .webp, etc.)
        return filename


def normalize_extensions_in_folder(
    folder_path: str,
    dry_run: bool = False
) -> Dict[str, any]:
    """
    Normaliza las extensiones de todos los archivos de imagen en una carpeta.
    
    Args:
        folder_path: Ruta de la carpeta a procesar
        dry_run: Si True, solo simula sin hacer cambios reales
        
    Returns:
        Diccionario con resultados:
        {
            "success": bool,
            "normalized_count": int,
            "skipped_count": int,
            "error_count": int,
            "details": list[dict],
            "message": str
        }
    """
    if not os.path.exists(folder_path):
        return {
            "success": False,
            "normalized_count": 0,
            "skipped_count": 0,
            "error_count": 0,
            "details": [],
            "message": f"La carpeta no existe: {folder_path}"
        }
    
    if not os.path.isdir(folder_path):
        return {
            "success": False,
            "normalized_count": 0,
            "skipped_count": 0,
            "error_count": 0,
            "details": [],
            "message": f"La ruta no es una carpeta: {folder_path}"
        }
    
    normalized_count = 0
    skipped_count = 0
    error_count = 0
    details = []
    
    try:
        # Listar todos los archivos en la carpeta
        files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
        
        for filename in files:
            file_path = os.path.join(folder_path, filename)
            
            # Determinar si necesita normalización
            if _should_normalize_to_webp(filename):
                new_filename = _normalize_filename(filename)
                new_file_path = os.path.join(folder_path, new_filename)
                
                # Verificar si el archivo de destino ya existe
                if os.path.exists(new_file_path) and new_file_path != file_path:
                    error_count += 1
                    details.append({
                        "original": filename,
                        "normalized": new_filename,
                        "status": "error",
                        "reason": "El archivo de destino ya existe"
                    })
                    logger.warning(f"No se puede renombrar '{filename}' a '{new_filename}': destino ya existe")
                    continue
                
                # Realizar el renombrado
                if not dry_run:
                    try:
                        os.rename(file_path, new_file_path)
                        normalized_count += 1
                        details.append({
                            "original": filename,
                            "normalized": new_filename,
                            "status": "normalized",
                            "reason": f"Extensión normalizada a .webp"
                        })
                        logger.info(f"Normalizado: '{filename}' → '{new_filename}'")
                    except Exception as e:
                        error_count += 1
                        details.append({
                            "original": filename,
                            "normalized": new_filename,
                            "status": "error",
                            "reason": str(e)
                        })
                        logger.error(f"Error al renombrar '{filename}': {e}")
                else:
                    # Modo dry-run: solo contar
                    normalized_count += 1
                    details.append({
                        "original": filename,
                        "normalized": new_filename,
                        "status": "would_normalize",
                        "reason": "Simulación: se normalizaría a .webp"
                    })
            else:
                # Archivo no requiere normalización
                skipped_count += 1
                details.append({
                    "original": filename,
                    "normalized": filename,
                    "status": "skipped",
                    "reason": "Extensión válida, no requiere cambios"
                })
        
        # Construir mensaje de resultado
        if dry_run:
            message = f"Simulación: {normalized_count} archivos se normalizarían, {skipped_count} se mantendrían igual"
        else:
            message = f"Normalización completada: {normalized_count} archivos normalizados, {skipped_count} sin cambios"
            
            if error_count > 0:
                message += f", {error_count} errores"
        
        return {
            "success": error_count == 0,
            "normalized_count": normalized_count,
            "skipped_count": skipped_count,
            "error_count": error_count,
            "details": details,
            "message": message
        }
        
    except Exception as e:
        logger.exception(f"Error al procesar carpeta '{folder_path}': {e}")
        return {
            "success": False,
            "normalized_count": 0,
            "skipped_count": 0,
            "error_count": 1,
            "details": [],
            "message": f"Error al procesar carpeta: {str(e)}"
        }


def execute_normalization_process(
    base_folder_path: str,
    folder_list: List[str] = None
) -> Dict[str, any]:
    """
    Ejecuta el proceso de normalización en múltiples carpetas.
    
    Args:
        base_folder_path: Ruta base donde están las carpetas
        folder_list: Lista de nombres de carpetas a procesar (None = todas)
        
    Returns:
        Diccionario con resultados globales:
        {
            "success": bool,
            "total_folders": int,
            "processed_folders": int,
            "total_normalized": int,
            "total_skipped": int,
            "total_errors": int,
            "folder_results": list[dict],
            "message": str
        }
    """
    if not os.path.exists(base_folder_path):
        return {
            "success": False,
            "total_folders": 0,
            "processed_folders": 0,
            "total_normalized": 0,
            "total_skipped": 0,
            "total_errors": 0,
            "folder_results": [],
            "message": f"El directorio base no existe: {base_folder_path}"
        }
    
    # Si no se especifica lista, procesar todas las carpetas
    if folder_list is None:
        folder_list = [
            d for d in os.listdir(base_folder_path)
            if os.path.isdir(os.path.join(base_folder_path, d))
        ]
    
    total_folders = len(folder_list)
    processed_folders = 0
    total_normalized = 0
    total_skipped = 0
    total_errors = 0
    folder_results = []
    
    logger.info(f"Iniciando normalización de extensiones en {total_folders} carpetas")
    
    for folder_name in folder_list:
        folder_path = os.path.join(base_folder_path, folder_name)
        
        if not os.path.exists(folder_path):
            logger.warning(f"Carpeta no encontrada: {folder_name}")
            folder_results.append({
                "folder": folder_name,
                "success": False,
                "message": "Carpeta no encontrada"
            })
            continue
        
        # Procesar carpeta
        result = normalize_extensions_in_folder(folder_path)
        
        processed_folders += 1
        total_normalized += result["normalized_count"]
        total_skipped += result["skipped_count"]
        total_errors += result["error_count"]
        
        folder_results.append({
            "folder": folder_name,
            "success": result["success"],
            "normalized": result["normalized_count"],
            "skipped": result["skipped_count"],
            "errors": result["error_count"],
            "message": result["message"]
        })
        
        logger.info(f"Carpeta '{folder_name}': {result['message']}")
    
    # Construir mensaje final
    success = total_errors == 0
    message = (
        f"Normalización completada: {total_normalized} archivos normalizados, "
        f"{total_skipped} sin cambios en {processed_folders}/{total_folders} carpetas"
    )
    
    if total_errors > 0:
        message += f". {total_errors} errores encontrados"
    
    return {
        "success": success,
        "total_folders": total_folders,
        "processed_folders": processed_folders,
        "total_normalized": total_normalized,
        "total_skipped": total_skipped,
        "total_errors": total_errors,
        "folder_results": folder_results,
        "message": message
    }

