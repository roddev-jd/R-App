# backend/core_logic/folder_renamer.py

import os
import pandas as pd # Aunque pasemos el mapa, pandas puede ser útil para otras cosas o si decidimos leer aquí.
import logging

logger = logging.getLogger(__name__)

def execute_folder_renaming(base_folder_path: str, name_mapping: dict):
    """
    Renombra las carpetas dentro de base_folder_path según el name_mapping.

    Args:
        base_folder_path (str): La ruta al directorio que contiene las carpetas a renombrar.
                                (Ej: 'downloads/nombre_excel/')
        name_mapping (dict): Un diccionario donde las claves son los nombres actuales de las carpetas
                             (ej. SKU_CL) y los valores son los nuevos nombres (ej. EAN_HIJO).

    Returns:
        dict: Un diccionario con los resultados de la operación:
              'success' (bool),
              'message' (str),
              'renamed_count' (int),
              'not_found_count' (int),
              'error_count' (int),
              'details' (list of strings with log messages)
    """
    if not os.path.isdir(base_folder_path):
        msg = f"El directorio base especificado no existe: {base_folder_path}"
        logger.error(msg)
        return {
            "success": False, "message": msg, "renamed_count": 0,
            "not_found_count": 0, "error_count": 0, "details": [msg]
        }

    if not name_mapping:
        msg = "El mapeo de nombres está vacío. No hay nada que renombrar."
        logger.warning(msg)
        return {
            "success": True, "message": msg, "renamed_count": 0,
            "not_found_count": 0, "error_count": 0, "details": [msg]
        }

    renamed_count = 0
    not_found_count = 0
    error_count = 0
    operation_details = []
    
    total_to_rename = len(name_mapping)
    logger.info(f"Iniciando proceso de renombrado para {total_to_rename} carpetas en '{base_folder_path}'.")

    for old_name, new_name in name_mapping.items():
        if not old_name or not new_name: # Saltar si alguno es None o vacío
            detail_msg = f"Mapeo inválido: Antiguo='{old_name}', Nuevo='{new_name}'. Saltando."
            logger.warning(detail_msg)
            operation_details.append(detail_msg)
            error_count +=1 # Considerar esto un error de datos
            continue

        source_path = os.path.join(base_folder_path, str(old_name))
        destination_path = os.path.join(base_folder_path, str(new_name))

        if os.path.abspath(source_path) == os.path.abspath(destination_path):
            detail_msg = f"El nombre antiguo '{old_name}' y el nuevo nombre '{new_name}' son iguales (o resuelven a la misma ruta). No se requiere renombrado."
            logger.info(detail_msg)
            operation_details.append(detail_msg)
            # No se cuenta como renombrado, ni error, ni no encontrado si ya es el nombre correcto.
            # O podrías contarlo como "ya correcto".
            continue

        if os.path.exists(source_path):
            if os.path.isdir(source_path): # Asegurarse que es un directorio
                if os.path.exists(destination_path):
                    # Conflicto: la carpeta destino ya existe.
                    # Esto podría pasar si diferentes SKU_CL mapean al mismo EAN_HIJO,
                    # o si una carpeta EAN_HIJO ya existía por alguna otra razón.
                    detail_msg = (f"Error: La carpeta destino '{destination_path}' (para nuevo nombre '{new_name}') "
                                  f"ya existe. No se puede renombrar '{source_path}'.")
                    logger.error(detail_msg)
                    operation_details.append(detail_msg)
                    error_count += 1
                else:
                    try:
                        os.rename(source_path, destination_path)
                        renamed_count += 1
                        detail_msg = f"Éxito: Carpeta '{old_name}' renombrada a '{new_name}'."
                        logger.info(detail_msg)
                        operation_details.append(detail_msg)
                    except OSError as e:
                        detail_msg = f"Error de OS al renombrar '{source_path}' a '{destination_path}': {e}"
                        logger.exception(detail_msg) # Loguea el traceback
                        operation_details.append(detail_msg)
                        error_count += 1
            else:
                detail_msg = f"Advertencia: '{source_path}' existe pero no es un directorio. Saltando."
                logger.warning(detail_msg)
                operation_details.append(detail_msg)
                not_found_count +=1 # O considerarlo un error
        else:
            detail_msg = f"Advertencia: La carpeta fuente '{source_path}' (antiguo nombre '{old_name}') no fue encontrada. Saltando."
            logger.warning(detail_msg)
            operation_details.append(detail_msg)
            not_found_count += 1
            
    final_message = (f"Proceso de renombrado de carpetas completado. "
                     f"Renombradas: {renamed_count}, No encontradas: {not_found_count}, Errores: {error_count}."
                     f" Total de mapeos intentados: {total_to_rename}")
    logger.info(final_message)

    return {
        "success": error_count == 0, # Consideramos éxito si no hubo errores directos de renombrado
        "message": final_message,
        "renamed_count": renamed_count,
        "not_found_count": not_found_count,
        "error_count": error_count,
        "details": operation_details
    }

# Ejemplo de uso (para probar el módulo directamente)
if __name__ == "__main__":
    logger.info("Ejecutando prueba del módulo folder_renamer...")

    # Crear estructura de carpetas de prueba
    test_base_dir = "test_folders_to_rename"
    if os.path.exists(test_base_dir):
        import shutil
        shutil.rmtree(test_base_dir)
    os.makedirs(test_base_dir, exist_ok=True)

    skus_de_prueba = ["SKU001", "SKU002", "SKU003", "SKU004_NO_MAPEADO", "SKU005"]
    for sku in skus_de_prueba:
        os.makedirs(os.path.join(test_base_dir, sku), exist_ok=True)
    
    # Crear un archivo en lugar de una carpeta para probar el manejo de errores
    open(os.path.join(test_base_dir, "SOY_UN_ARCHIVO_SKU005"), 'w').close()


    # Mapeo de prueba
    test_mapping = {
        "SKU001": "EAN111",       # Caso exitoso
        "SKU002": "EAN222",       # Caso exitoso
        "SKU_NO_EXISTE": "EAN333", # Carpeta "SKU_NO_EXISTE" no está en el disco
        "SKU003": "EAN111",       # Conflicto, EAN111 ya existirá después de SKU001
        "SKU005": "EAN555"        # Intentará renombrar SOY_UN_ARCHIVO_SKU005 (que no es dir)
    }

    results = execute_folder_renaming(test_base_dir, test_mapping)
    logger.info(f"Resultados de la prueba:\n{results}")

    # Podrías querer limpiar test_base_dir después de la prueba
    # import shutil
    # shutil.rmtree(test_base_dir)