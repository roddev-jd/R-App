# backend/core_logic/image_renamer.py

import os
import re
import logging

logger = logging.getLogger(__name__)

IMAGE_RE = re.compile(r"^(image)(\d+)", re.IGNORECASE)

# NUEVO: Modificamos la firma para aceptar el SKU original
def _calculate_new_image_name(parent_folder_name: str, original_filename: str, original_sku_name: str | None) -> str | None:
    """
    Determina el nuevo nombre para un archivo de imagen.
    NUEVA LÓGICA: Primero comprueba si el nombre del archivo se basa en el SKU original.
    Si no, aplica las reglas estándar (full_image, image<NUM>).
    También renombra archivos que tienen números de producto (EAN/SKU) diferentes al de la carpeta.
    """
    base, ext = os.path.splitext(original_filename)
    ext = ext.lower()

    if ext not in {'.jpg', '.jpeg', '.png', '.webp'}:
        return None  # extensión no soportada

    # --- REGLA 1: ARCHIVOS BASADOS EN SKU ORIGINAL ---
    # Comprueba si tenemos un SKU para esta carpeta y si el nombre del archivo coincide con él.
    if original_sku_name and (original_filename.startswith(f"{original_sku_name}_") or original_filename.startswith(f"{original_sku_name}-")):
        # Reemplaza el prefijo del SKU por el prefijo del EAN (nombre de la carpeta padre)
        # ej: "SKU123_2.jpg" se convierte en "EAN456_2.jpg"
        if original_filename.startswith(f"{original_sku_name}_"):
            return original_filename.replace(f"{original_sku_name}_", f"{parent_folder_name}_", 1)
        else: # Empieza con "-"
            return original_filename.replace(f"{original_sku_name}-", f"{parent_folder_name}-", 1)

    # --- REGLA 2: ARCHIVOS CON PATRÓN "full_image" ---
    base_lc = base.lower()
    if base_lc.startswith("full_image"):
        return f"{parent_folder_name}_2{ext}"

    # --- REGLA 3: ARCHIVOS CON PATRÓN "image<NUM>" ---
    m = IMAGE_RE.match(base_lc)
    if m:
        num = m.group(2)
        return f"{parent_folder_name}-{num}{ext}"

    # --- REGLA 4: ARCHIVOS CON NÚMEROS LARGOS (EAN/SKU de otro producto) ---
    # Esto captura archivos como "2000406500171_2.webp", "2000406500171-1.webp"
    # que fueron agregados manualmente y tienen un EAN diferente al de la carpeta
    # Patrón: número largo (10+ dígitos) seguido de _ o - y luego más texto/números
    ean_pattern = re.compile(r'^(\d{10,})([_-])(.+)$')
    match_ean = ean_pattern.match(base)

    if match_ean:
        ean_number = match_ean.group(1)
        separator = match_ean.group(2)
        suffix = match_ean.group(3)

        # Si el EAN del archivo NO coincide con el nombre de la carpeta, renombrar
        if ean_number != parent_folder_name:
            return f"{parent_folder_name}{separator}{suffix}{ext}"
        else:
            # El archivo ya tiene el nombre correcto
            return None

    # --- REGLA 5: ARCHIVOS CON SOLO NÚMERO LARGO (sin sufijo) ---
    # Captura archivos como "2000406500171.webp"
    solo_number_pattern = re.compile(r'^(\d{10,})$')
    match_solo = solo_number_pattern.match(base)

    if match_solo:
        ean_number = match_solo.group(1)

        # Si el número NO coincide con el nombre de la carpeta, renombrar
        if ean_number != parent_folder_name:
            return f"{parent_folder_name}{ext}"
        else:
            # El archivo ya tiene el nombre correcto
            return None

    return None  # no coincide ninguna regla


# NUEVO: Modificamos la firma para aceptar el name_mapping de app.py
def execute_internal_image_renaming(base_directory_path: str, name_mapping: dict):
    """
    Recorre las subcarpetas y renombra los archivos de imagen.
    
    Args:
        base_directory_path (str): Ruta al directorio de sesión.
        name_mapping (dict): Mapeo de SKU_CL a EAN_HIJO.
    """
    if not os.path.isdir(base_directory_path):
        msg = f"El directorio base especificado no existe: {base_directory_path}"
        logger.error(msg)
        return {"success": False, "message": msg, "processed_files": 0, "renamed_files": 0, "omitted_files": 0, "conflict_files": 0, "details": [msg]}

    # --- NUEVO: Invertir el mapa para buscar SKU por EAN ---
    try:
        ean_sku_map = {v: k for k, v in name_mapping.items()}
    except Exception as e:
        msg = f"Error al procesar el mapeo SKU->EAN: {e}. Podría haber EANs duplicados en el Excel."
        logger.error(msg)
        return {"success": False, "message": msg, "processed_files": 0, "renamed_files": 0, "omitted_files": 0, "conflict_files": 0, "details": [msg]}

    total_files_inspected = 0
    renamed_count = 0
    omitted_count = 0
    conflict_count = 0
    operation_details = []

    logger.info(f"Iniciando renombrado interno de imágenes en '{base_directory_path}'.")

    for root_folder, _, files_in_folder in os.walk(base_directory_path):
        if os.path.abspath(root_folder) == os.path.abspath(base_directory_path):
            continue # Omitir archivos en la carpeta raíz de la sesión

        parent_folder_name = os.path.basename(root_folder)

        if not files_in_folder:
            continue

        # --- NUEVO: Obtener el SKU original para esta carpeta (que es un EAN) ---
        original_sku_name_for_folder = ean_sku_map.get(parent_folder_name)
        if not original_sku_name_for_folder:
            logger.warning(f"No se encontró un SKU original para la carpeta EAN '{parent_folder_name}'. Solo se aplicarán las reglas estándar.")

        for original_filename in files_in_folder:
            total_files_inspected += 1

            # --- NUEVO: Pasamos el SKU original a la función de cálculo ---
            new_filename_only = _calculate_new_image_name(parent_folder_name, original_filename, original_sku_name_for_folder)

            if new_filename_only is None:
                omitted_count += 1
            else:
                current_file_path = os.path.join(root_folder, original_filename)
                new_file_path = os.path.join(root_folder, new_filename_only)

                if os.path.abspath(current_file_path) == os.path.abspath(new_file_path):
                    omitted_count += 1
                    continue

                if os.path.exists(new_file_path):
                    conflict_count += 1
                    msg = (f"Conflicto: El nuevo nombre '{new_filename_only}' ya existe en la carpeta "
                           f"'{parent_folder_name}'. No se renombró '{original_filename}'.")
                    logger.warning(msg)
                    operation_details.append(msg)
                else:
                    try:
                        os.rename(current_file_path, new_file_path)
                        renamed_count += 1
                        msg = f"Éxito: En '{parent_folder_name}', '{original_filename}' renombrado a '{new_filename_only}'."
                        logger.info(msg)
                        operation_details.append(msg)
                    except OSError as e:
                        conflict_count += 1
                        msg = (f"Error OS: Al renombrar '{original_filename}' a '{new_filename_only}' "
                               f"en '{parent_folder_name}': {e}")
                        logger.exception(msg)
                        operation_details.append(msg)
    
    final_message = (f"Proceso de renombrado interno de imágenes completado. "
                     f"Archivos procesados: {total_files_inspected}, Renombrados: {renamed_count}, "
                     f"Omitidos/Ya correctos: {omitted_count}, Conflictos/Errores OS: {conflict_count}.")
    logger.info(final_message)

    return {
        "success": True,
        "message": final_message,
        "processed_files": total_files_inspected,
        "renamed_files": renamed_count,
        "omitted_files": omitted_count,
        "conflict_files": conflict_count,
        "details": operation_details
    }