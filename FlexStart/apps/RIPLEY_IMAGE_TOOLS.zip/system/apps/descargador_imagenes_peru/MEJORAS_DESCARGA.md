# 🎯 Plan de Mejoras: Descargador de Imágenes - Solución a Fallos Intermitentes

**Fecha de inicio:** 20 de Octubre, 2025
**Aplicación:** `descargador_imagenes`
**Problema:** Imágenes no encontradas en primer intento pero sí en reintentos manuales
**Estado actual:** ✅ FASE 2 COMPLETADA - Listo para pruebas

---

## 📊 Contexto del Problema

### Síntomas Reportados por el Usuario
- ✅ Algunas imágenes no se encuentran en la primera sesión de descarga
- ✅ Al hacer un segundo intento solo con los SKUs faltantes, SÍ se encuentran las imágenes
- ✅ Patrón **aleatorio** - diferentes SKUs fallan cada vez (no hay patrón consistente)
- ✅ **Más frecuente con lotes grandes** (>100 SKUs)
- ✅ Usuario reintenta **inmediatamente después** del primer intento

### Análisis de Código (Diagnóstico)
**Archivos analizados:**
- `FlexStart/apps/descargador_imagenes/backend/config.py`
- `FlexStart/apps/descargador_imagenes/backend/core_logic/downloader.py`

---

## 🔍 Causas Identificadas (5 Problemas Raíz)

### ✅ CAUSA 1: Rate Limiting y Throttling del Servidor ⭐ **MÁS PROBABLE**
**Evidencia:**
- Problema más frecuente con lotes grandes (>100 SKUs)
- Descargas exitosas al reintentar inmediatamente
- Patrón aleatorio de SKUs que fallan
- Cada SKU intenta múltiples URLs (hasta 64 intentos: 16 tipos × 4 extensiones)

**Diagnóstico técnico:**
- Delay de 2 segundos entre SKUs puede ser insuficiente para lotes grandes
- Servidor detecta patrón de peticiones y empieza a rechazar conexiones
- Los reintentos automáticos (5 intentos) no son suficientes
- Timeout de 10s conexión puede ser corto cuando servidor está saturado

---

### ✅ CAUSA 2: Pool de Conexiones Saturado
**Evidencia en código:**
```python
# downloader.py:83-98 (ANTES)
adapter = HTTPAdapter(max_retries=retry_strategy)
# NO configuraba pool_connections ni pool_maxsize
# Default: solo 10 conexiones máximas
```

**Problema:**
- Con 100+ SKUs y múltiples imágenes por SKU, el pool de 10 conexiones se satura
- Las conexiones rechazadas no se reintentan adecuadamente

---

### ✅ CAUSA 3: Timeouts Optimistas Durante Descarga Masiva
**Configuración original:**
```python
DEFAULT_REQUEST_TIMEOUT = (10, 20)  # (connect_timeout, read_timeout)
```

**Problema:**
- 10 segundos de connect timeout puede ser insuficiente cuando el servidor está bajo carga
- 20 segundos de read timeout puede cortarse si la red está congestionada
- No había diferenciación entre lotes pequeños y grandes

---

### ✅ CAUSA 4: Estrategia de Reintentos Limitada por Tipo de Error
**Código original:**
```python
RETRY_STATUS_FORCELIST = [429, 500, 502, 503, 504]
RETRY_TOTAL = 5
```

**Problema:**
- Solo reintenta códigos HTTP específicos
- NO reintenta errores de timeout/conexión después de agotar los 5 reintentos
- El código captura timeouts pero NO reintenta a nivel de ítem

---

### ✅ CAUSA 5: Optimización Prematura que Oculta Errores
**Código problemático:**
```python
# downloader.py:286-289 (ANTES)
if not full_image_found:
    logger.info(f"OPTIMIZACIÓN: full_image no existe, saltando image1-image15")
    break  # Salir del loop
```

**Problema:**
- Si `full_image` falla por timeout temporal (no porque no exista), se saltan TODAS las imágenes secundarias
- Similar problema con `_2.jpg` en Store (línea 365)
- No diferenciaba entre "no existe" (404) vs "error temporal" (timeout)

---

## 🎯 Plan de Solución (5 Fases)

### ✅ FASE 1: Diagnóstico (OPCIONAL - NO EJECUTADA)
**Estado:** ⏭️ SALTADA - No necesaria
**Razón:** El análisis de código fue suficiente para identificar las causas

---

### ✅ FASE 2: Quick Wins ✅ **COMPLETADA**
**Estado:** ✅ 100% IMPLEMENTADO
**Objetivo:** Cambios mínimos con máximo impacto (resolver 70-80% del problema)

#### ✅ 2.1 Aumentar Pool de Conexiones HTTP
**Archivo:** `config.py` + `downloader.py`

**Cambios implementados:**
```python
# config.py - NUEVO
HTTP_POOL_CONNECTIONS = 20  # Antes: 10 (default)
HTTP_POOL_MAXSIZE = 30      # Antes: 10 (default)

# downloader.py:105-109
adapter = HTTPAdapter(
    max_retries=retry_strategy,
    pool_connections=HTTP_POOL_CONNECTIONS,    # ✅ NUEVO
    pool_maxsize=HTTP_POOL_MAXSIZE,           # ✅ NUEVO
    pool_block=False                          # ✅ NUEVO
)
```

**Impacto esperado:** Eliminación de fallos por saturación del pool

---

#### ✅ 2.2 Timeouts Adaptativos según Tamaño del Lote
**Archivo:** `config.py` + `downloader.py`

**Cambios implementados:**
```python
# config.py - NUEVO
DEFAULT_REQUEST_TIMEOUT = (10, 20)              # Lotes pequeños
LARGE_BATCH_REQUEST_TIMEOUT = (15, 30)         # Lotes grandes (>100 SKUs)
LARGE_BATCH_THRESHOLD = 100

# downloader.py:115-128 - NUEVA FUNCIÓN
def _get_adaptive_timeout(total_items):
    if total_items >= LARGE_BATCH_THRESHOLD:
        return LARGE_BATCH_REQUEST_TIMEOUT
    else:
        return DEFAULT_REQUEST_TIMEOUT

# downloader.py:670
request_timeout = _get_adaptive_timeout(total_items_to_process)
```

**Impacto esperado:** Reducción del 50-60% en fallos por timeout

---

#### ✅ 2.3 Jitter Aleatorio en Delays entre SKUs
**Archivo:** `config.py` + `downloader.py`

**Cambios implementados:**
```python
# config.py - NUEVO
DELAY_BETWEEN_SKUS = 2.0                     # Base (lotes pequeños)
DELAY_BETWEEN_SKUS_LARGE_BATCH = 3.5        # Lotes grandes
DELAY_JITTER_MAX = 0.8                      # Jitter aleatorio máximo
LARGE_BATCH_THRESHOLD = 100

# downloader.py:90-113 - NUEVA FUNCIÓN
def _get_adaptive_delay(base_delay, is_large_batch=False, add_jitter=True):
    if is_large_batch:
        delay = DELAY_BETWEEN_SKUS_LARGE_BATCH
    else:
        delay = base_delay

    if add_jitter:
        jitter = random.uniform(0, DELAY_JITTER_MAX)
        delay += jitter

    return delay

# downloader.py:731
adaptive_delay = _get_adaptive_delay(DELAY_BETWEEN_SKUS, is_large_batch, add_jitter=True)
```

**Impacto esperado:** Reducción del 70-80% en fallos por rate limiting

---

#### ✅ 2.4 Logging Mejorado (Clasificación de Errores)
**Archivo:** `downloader.py`

**Cambios implementados:**
```python
# downloader.py:130-158 - NUEVA FUNCIÓN
def _classify_download_error(exception, status_code):
    """
    Clasifica errores en:
    - "not_found": 404 (imagen no existe)
    - "rate_limit": 429 (rate limit excedido)
    - "timeout": Timeout de conexión/lectura
    - "server_error": 5xx
    - "network_error": Error de red
    - "unknown": Otros
    """
    if status_code == 404:
        return ("not_found", "Imagen no existe en el servidor")
    elif status_code == 429:
        return ("rate_limit", "Rate limit excedido")
    elif status_code and 500 <= status_code < 600:
        return ("server_error", f"Error del servidor ({status_code})")
    elif isinstance(exception, (ConnectTimeout, ReadTimeout, Timeout)):
        return ("timeout", f"Timeout de conexión/lectura")
    elif isinstance(exception, RequestException):
        return ("network_error", f"Error de red: {type(exception).__name__}")
    else:
        return ("unknown", "Error no clasificado")

# downloader.py:283-351 - FUNCIÓN REFACTORIZADA
def _attempt_single_download(...):
    # Ahora retorna: (success: bool, error_type: str)
    # Logging mejorado con emojis: ✓ ✗ ⚠ ⏱
    ...
```

**Impacto esperado:** Diagnóstico más fácil y preciso de problemas residuales

---

#### ✅ 2.5 Optimización Inteligente (404 vs Timeout)
**Archivo:** `downloader.py`

**Cambios implementados:**

**Para Rimage (`_download_rimage_images`):**
```python
# downloader.py:353-461
# ANTES:
if not full_image_found:
    logger.info("OPTIMIZACIÓN: full_image no existe, saltando image1-image15")
    break

# AHORA:
if not full_image_found:
    if all_404:  # ✅ Solo si TODAS las extensiones dieron 404
        full_image_confirmed_not_found = True
        logger.info("OPTIMIZACIÓN: full_image no existe (404 confirmado), saltando image1-image15")
        break
    else:
        logger.info("full_image falló por error temporal, intentando image1-image15 por si acaso")
```

**Para Store (`_download_store_images`):**
```python
# downloader.py:464-537
# ANTES:
if not underscore_image_found:
    logger.info("OPTIMIZACIÓN: _2.jpg no existe, saltando -1 a -18")
    return images_downloaded_count, image_found

# AHORA:
if not underscore_image_found:
    if error_type_underscore == "not_found":  # ✅ Solo si fue 404
        logger.info("OPTIMIZACIÓN: _2.jpg no existe (404 confirmado), saltando -1 a -18")
        return images_downloaded_count, image_found
    else:
        logger.info("_2.jpg falló por error temporal, intentando -1 a -18 por si acaso")
```

**Impacto esperado:** Recuperación de 10-20% de imágenes que antes se saltaban incorrectamente

---

#### ✅ 2.6 Reintentos Más Agresivos
**Archivo:** `config.py`

**Cambios implementados:**
```python
# config.py
# ANTES:
RETRY_TOTAL = 5
RETRY_CONNECT = 3
RETRY_READ = 3

# AHORA:
RETRY_TOTAL = 8           # ✅ +60% más intentos
RETRY_CONNECT = 5         # ✅ +67% más intentos
RETRY_READ = 5           # ✅ +67% más intentos
```

**Impacto esperado:** Recuperación adicional del 10-15% de errores transitorios

---

### ⏳ FASE 3: Sistema de Reintentos Inteligente (NO EJECUTADA)
**Estado:** 🔲 PENDIENTE - Solo ejecutar si Fase 2 es insuficiente
**Objetivo:** Reintentos automáticos al final solo para errores temporales

**Diseño propuesto:**
1. Durante descarga, mantener lista de `failed_items_to_retry` con tipo de error
2. Al final del proceso, filtrar solo errores temporales (timeout, rate_limit, server_error)
3. Segundo pase automático SOLO para esos SKUs
4. Usuario NO necesita intervenir manualmente

**Archivos a modificar:**
- `downloader.py` - Función `execute_download_process()`
- Agregar lógica de segundo pase condicional

**Complejidad:** Media
**Tiempo estimado:** 45-60 minutos
**Riesgo:** Bajo (no afecta funcionalidad existente)

---

### ⏳ FASE 4: Optimización Conservadora (NO EJECUTADA)
**Estado:** 🔲 PENDIENTE - Posiblemente no necesaria

**Objetivo:** Ajustes finos si todavía hay problemas

**Posibles mejoras:**
- Delays aún más largos para lotes >200 SKUs
- Reintentos exponenciales a nivel de SKU completo
- Modo "ultra-conservador" configurable por usuario

---

### ⏳ FASE 5: UI/UX (NO EJECUTADA)
**Estado:** 🔲 PENDIENTE - Mejoras de experiencia de usuario

**Objetivo:** Mejor visibilidad para el usuario

**Mejoras propuestas:**
1. Mostrar en UI: "X imágenes encontradas, Y errores temporales, Z no existen"
2. Botón opcional: "Forzar reintento completo" vs "Solo reintentar errores temporales"
3. Dashboard en tiempo real con tasas de éxito/fallo
4. Clasificación de errores en el reporte final

---

## 📊 Comparativa: Antes vs Después

| Parámetro | Antes | Ahora (Lote <100) | Ahora (Lote ≥100) |
|-----------|-------|-------------------|-------------------|
| **Reintentos totales** | 5 | 8 ✅ | 8 ✅ |
| **Connect timeout** | 10s | 10s | **15s** ✅ |
| **Read timeout** | 20s | 20s | **30s** ✅ |
| **Pool conexiones** | 10 (default) | 20 ✅ | 20 ✅ |
| **Pool maxsize** | 10 (default) | 30 ✅ | 30 ✅ |
| **Delay entre SKUs** | 2.0s fijo | 2.0s + jitter (0-0.8s) ✅ | **3.5s + jitter (0-0.8s)** ✅ |
| **Jitter máximo** | 0s | 0.8s ✅ | 0.8s ✅ |
| **Clasificación errores** | ❌ No | ✅ Sí | ✅ Sí |
| **Optimización inteligente** | ❌ Salta siempre | ✅ Solo si 404 confirmado | ✅ Solo si 404 confirmado |

---

## 🚀 Próximos Pasos para Nuevo Chat

### ✅ OPCIÓN A: Probar Fase 2 (RECOMENDADO)
**Si el usuario quiere validar las mejoras implementadas:**

1. **Ejecutar prueba con lote real (>100 SKUs):**
   ```bash
   python lanzador.py
   # Navegar a descargador_imagenes
   # Cargar Excel con >100 SKUs
   # Iniciar descarga
   ```

2. **Verificar en logs:**
   - ✓ Debe aparecer: "🔧 Lote GRANDE detectado (XXX SKUs). Usando configuración optimizada"
   - ✓ Delays varían entre ~3.5s y ~4.3s (por el jitter)
   - ✓ Menos mensajes de "⏱ Timeout"
   - ✓ Mensajes clasificados con emojis: ✓ ✗ ⚠ ⏱

3. **Comparar resultados:**
   - **Antes:** X% de SKUs fallaban en primer intento
   - **Después:** Debería ser <5% de fallos

4. **Si todavía hay problemas (poco probable):**
   - Ir a OPCIÓN B

---

### 🔲 OPCIÓN B: Implementar Fase 3 (Solo si Fase 2 es insuficiente)
**Si después de probar todavía hay >5% de fallos:**

**Tarea:** Implementar sistema de reintentos automáticos inteligente

**Pseudocódigo:**
```python
# En execute_download_process(), después del loop principal:

failed_items_for_retry = []

for item in items_to_process:
    try:
        result = _download_images_for_item(...)
        if result == 0:
            # Verificar tipo de error del último intento
            if last_error_type in ["timeout", "rate_limit", "server_error"]:
                failed_items_for_retry.append(item)
    except:
        ...

# Segundo pase SOLO para errores temporales
if failed_items_for_retry:
    logger.info(f"🔄 Reintentando {len(failed_items_for_retry)} SKUs que fallaron por errores temporales...")
    for item in failed_items_for_retry:
        # Reintento con delays más largos
        _download_images_for_item(...)
```

**Archivos a modificar:**
- `downloader.py` líneas 668-736 (función `execute_download_process`)

**Tiempo estimado:** 45 minutos

---

### 🔲 OPCIÓN C: Ajustes Finos (Solo si casos muy específicos)
**Escenarios posibles:**

**C.1: Lotes MUY grandes (>300 SKUs) todavía tienen problemas**
```python
# config.py - Agregar:
VERY_LARGE_BATCH_THRESHOLD = 300
DELAY_BETWEEN_SKUS_VERY_LARGE_BATCH = 5.0
VERY_LARGE_BATCH_REQUEST_TIMEOUT = (20, 40)
```

**C.2: Hora pico del servidor (rate limiting más agresivo)**
```python
# config.py - Agregar:
DELAY_ON_RATE_LIMIT_FACTOR = 2.0  # Multiplicar delay por 2 si se detecta rate limit
```

---

## 📁 Archivos Modificados (Para Referencia)

### ✅ Archivos con cambios implementados:
1. ✅ `FlexStart/apps/descargador_imagenes/backend/config.py`
   - Líneas modificadas: ~20-70
   - Nuevas constantes agregadas: ~15

2. ✅ `FlexStart/apps/descargador_imagenes/backend/core_logic/downloader.py`
   - Líneas modificadas: ~1-15 (imports), 88-158 (nuevas funciones), 283-735 (refactorización)
   - Funciones nuevas: 3
   - Funciones modificadas: 5

### 📁 Archivos sin cambios (no requieren modificación):
- `FlexStart/apps/descargador_imagenes/backend/app.py` ✅
- `FlexStart/apps/descargador_imagenes/backend/utils/` ✅
- `FlexStart/apps/descargador_imagenes/backend/models/` ✅
- `FlexStart/apps/descargador_imagenes/frontend/` ✅

---

## 🧪 Cómo Probar

### Escenario 1: Lote Pequeño (<100 SKUs)
**Comportamiento esperado:**
- Usa configuración estándar (timeouts 10s/20s, delay 2s)
- Logs muestran: "Lote normal (XX SKUs). Usando configuración estándar."
- Sin cambios perceptibles vs versión anterior

### Escenario 2: Lote Grande (≥100 SKUs)
**Comportamiento esperado:**
- Usa configuración optimizada (timeouts 15s/30s, delay 3.5s)
- Logs muestran: "🔧 Lote GRANDE detectado (XXX SKUs). Usando configuración optimizada:"
- Delays varían entre 3.5s y 4.3s por el jitter
- Menos fallos de timeout
- Menos SKUs reportados como "no encontrados"

### Escenario 3: Reintento Manual (Comportamiento Actual)
**Comportamiento esperado:**
- Si quedan SKUs faltantes, usuario carga Excel solo con esos SKUs
- DEBE encontrar más imágenes que antes porque:
  - ✅ No salta imágenes por timeouts (solo por 404 confirmado)
  - ✅ Más reintentos (8 vs 5)
  - ✅ Timeouts más generosos

---

## 🎯 Objetivos Cumplidos vs Pendientes

### ✅ Completado (Fase 2):
- [x] Pool de conexiones aumentado (10 → 20/30)
- [x] Timeouts adaptativos (10s/20s → 15s/30s para lotes grandes)
- [x] Jitter aleatorio en delays (evita patrones detectables)
- [x] Reintentos más agresivos (5 → 8)
- [x] Clasificación inteligente de errores (404 vs timeout vs rate limit)
- [x] Optimización inteligente (no salta imágenes por timeouts)
- [x] Logging mejorado con emojis visuales
- [x] Detección automática de lotes grandes
- [x] Backward compatible (no rompe funcionalidad existente)

### 🔲 Pendiente (Solo si necesario):
- [ ] Sistema de reintentos automáticos (Fase 3)
- [ ] Delays ultra-conservadores para lotes >300 SKUs (Fase 4)
- [ ] UI mejorada con clasificación de errores (Fase 5)
- [ ] Botón "Reintentar solo errores temporales" (Fase 5)

---

## 💡 Decisiones de Diseño Clave

### ✅ Por qué NO implementamos Fase 3 inmediatamente:
1. **Enfoque incremental:** Mejor validar Fase 2 primero (70-80% de mejora esperada)
2. **Complejidad:** Fase 3 agrega lógica de segundo pase que puede complicar debugging
3. **Tiempo de desarrollo:** Fase 2 tomó ~2 horas, Fase 3 tomaría ~1 hora adicional
4. **Riesgo:** Fase 2 es muy bajo riesgo, Fase 3 introduce nueva lógica

### ✅ Por qué usamos jitter aleatorio:
- Rate limiters modernos detectan patrones regulares (peticiones cada exactamente 2s)
- Jitter aleatorio hace que las peticiones parezcan más "humanas"
- 0.8s de jitter es suficiente para romper patrones sin agregar mucho tiempo total

### ✅ Por qué timeouts adaptativos:
- Lotes pequeños no necesitan timeouts largos (desperdicia tiempo en fallos reales)
- Lotes grandes sí necesitan más tiempo porque el servidor está más saturado
- Detección automática evita que usuario tenga que configurar manualmente

### ✅ Por qué no cambiar el código de app.py:
- Los cambios en `downloader.py` son transparentes para `app.py`
- La firma de `execute_download_process()` NO cambió
- Los parámetros adicionales son opcionales (tienen defaults)

---

## 🔧 Configuración Avanzada (Para Casos Extremos)

Si después de Fase 2 todavía hay problemas muy específicos:

### Lotes MUY grandes (>500 SKUs):
```python
# En config.py, agregar:
ULTRA_LARGE_BATCH_THRESHOLD = 500
DELAY_BETWEEN_SKUS_ULTRA_LARGE_BATCH = 5.0
```

### Servidor muy restrictivo:
```python
# En config.py, modificar:
DELAY_BETWEEN_SKUS_LARGE_BATCH = 5.0  # En lugar de 3.5
DELAY_JITTER_MAX = 1.5                # En lugar de 0.8
```

### Debugging activado:
```python
# En downloader.py línea 307, descomentar:
logger.debug(f"Intentando ({item_log_prefix}): {url}")
```

---

## 📞 Información de Contacto para Continuidad

**Contexto para el nuevo chat:**
- El usuario reportó el problema: imágenes no encontradas en primer intento
- Análisis identificó 5 causas raíz
- Se implementó Fase 2 (Quick Wins) con cambios en 2 archivos
- Cambios son backward compatible y de bajo riesgo
- **Siguiente paso:** Usuario debe probar con lote real >100 SKUs
- Si todavía hay problemas, implementar Fase 3

**Preguntas clave para hacer al usuario al retomar:**
1. "¿Ya probaste las mejoras de Fase 2 con un lote real?"
2. "¿Qué porcentaje de SKUs todavía fallan en el primer intento?"
3. "¿Los logs muestran el mensaje de 'Lote GRANDE detectado'?"
4. "¿Cuántos SKUs tiene tu lote de prueba típico?"

---

## 🏁 Estado Final

**FASE 2 (QUICK WINS): ✅ 100% COMPLETADA**

**Cambios listos para producción:**
- ✅ Código sin errores de sintaxis
- ✅ Backward compatible
- ✅ Bien documentado en código
- ✅ Logging mejorado para diagnóstico
- ✅ Auto-adaptativo (no requiere configuración manual)

**Próximo hito:** Validación con lote real del usuario

**Éxito esperado:** Reducción de 70-80% en fallos de descarga

---

**Documento creado:** 20 de Octubre, 2025
**Última actualización:** 20 de Octubre, 2025
**Versión:** 1.0
**Estado:** ✅ FASE 2 COMPLETADA - LISTO PARA PRUEBAS
