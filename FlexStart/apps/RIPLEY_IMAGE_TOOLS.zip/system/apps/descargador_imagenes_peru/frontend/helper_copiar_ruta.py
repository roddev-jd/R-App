import tkinter as tk
from tkinter import filedialog, messagebox
import os
import sys

try:
    import pyperclip
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pyperclip'])
    import pyperclip

root = tk.Tk()
root.withdraw()  # Oculta la ventana principal

file_path = filedialog.askopenfilename(
    title="Selecciona tu archivo Excel",
    filetypes=[("Archivos Excel", "*.xlsx *.xls")]
)

if file_path:
    folder = os.path.dirname(file_path)
    pyperclip.copy(folder)
    messagebox.showinfo(
        "Ruta copiada",
        f"La ruta de la carpeta se ha copiado al portapapeles:\n\n{folder}\n\n¡Pega (Ctrl+V) en la web!"
    )
else:
    messagebox.showinfo("Cancelado", "No se seleccionó ningún archivo.")

root.destroy()
sys.exit(0) 