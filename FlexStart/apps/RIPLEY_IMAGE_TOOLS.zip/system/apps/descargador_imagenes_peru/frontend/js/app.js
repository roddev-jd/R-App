// frontend/js/app.js

// Variables globales
const API_BASE_URL = '/descargador_imagenes_peru/api';
let workingDirectory = null;
let currentStep = 1;
let processingEvents = [];

// Variables para control de proceso
let isDownloadRunning = false;
let totalSkusToProcess = 0;

// NUEVO: Variables para modo de operación
let operationMode = 'download';  // 'download' o 'local_copy'
let localSourcePath = null;

// NUEVO: Variables para tipo de descarga
let downloadType = 'both_fallback';  // Tipo de descarga seleccionado
let availableDownloadTypes = {};

// NUEVO: Variables para agrupación por padre+color
let groupByParentColor = false;  // Estado de agrupación
let groupingColumnsAvailable = false;  // Si existen columnas necesarias

document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const newProjectButton = document.getElementById('new-project-button');
    const workingDirectoryDisplay = document.getElementById('working-directory-display');
    const workingDirectoryInfo = document.getElementById('working-directory-info');
    const excelFileInput = document.getElementById('excel-file-input');
    const uploadStatusDiv = document.getElementById('upload-status');
    
    // Elementos de selección de columnas
    const columnSelectionSection = document.getElementById('column-selection-section');
    const skuColumnSelect = document.getElementById('sku-column-select');
    const coddeptoColumnSelect = document.getElementById('coddepto-column-select');
    const confirmColumnsButton = document.getElementById('confirm-columns-button');
    
    // NUEVO: Elementos de modo de operación
    const operationModeSelector = document.getElementById('operation-mode-selector');
    const operationModeRadios = document.querySelectorAll('input[name="operation-mode"]');
    const localSourcePathSection = document.getElementById('local-source-path-section');
    const localSourcePathInput = document.getElementById('local-source-path-input');
    const verifySourcePathButton = document.getElementById('verify-source-path-button');
    const sourcePathStatus = document.getElementById('source-path-status');
    const step1ButtonText = document.getElementById('step1-button-text');
    const stopButtonText = document.getElementById('stop-button-text');
    
    // NUEVO: Elementos de tipo de descarga
    const downloadTypeSelector = document.getElementById('download-type-selector');
    const downloadTypeOptions = document.getElementById('download-type-options');

    // NUEVO: Elementos de agrupación por padre+color
    const groupingToggleSection = document.getElementById('grouping-toggle-section');
    const groupByParentColorToggle = document.getElementById('group-by-parent-color-toggle');
    const groupingStatus = document.getElementById('grouping-status');

    const startStep1Button = document.getElementById('start-step-1-button');
    const stopStep1Button = document.getElementById('stop-step-1-button');
    const step1StatusDiv = document.getElementById('step-1-status');

    const reverifyStep1Button = document.getElementById('reverify-step-1-button');
    const reverifyStep1StatusDiv = document.getElementById('reverify-step-1-status');

    const downloadMissingReportButton = document.getElementById('download-missing-report-button');

    const logOutputPre = document.getElementById('log-output');

    let currentStep = 1;
    let uploadedExcelFile = null;
    let expectedSkuFoldersForStep1 = [];
    let workingDirectory = '';

    // --- Utility Functions ---
    function logMessage(message, type = 'info') {
        const timestamp = new Date().toLocaleTimeString();
        const currentLog = logOutputPre.textContent;
        logOutputPre.textContent = `[${timestamp}] ${type.toUpperCase()}: ${message}\n` + currentLog;

        const lines = logOutputPre.textContent.split('\n');
        if (lines.length > 150) {
            logOutputPre.textContent = lines.slice(0, 150).join('\n');
        }
    }
    
    // NUEVO: Función para cargar tipos de descarga disponibles
    async function loadDownloadTypes() {
        try {
            const response = await fetch(`${API_BASE_URL}/download_types`);
            const data = await response.json();
            
            if (data.success) {
                availableDownloadTypes = data.download_types;
                renderDownloadTypeOptions();
                logMessage('Tipos de descarga cargados correctamente');
            } else {
                logMessage('Error al cargar tipos de descarga', 'error');
            }
        } catch (error) {
            logMessage(`Error al cargar tipos de descarga: ${error.message}`, 'error');
        }
    }
    
    // NUEVO: Función para renderizar las opciones de tipo de descarga
    function renderDownloadTypeOptions() {
        if (!downloadTypeOptions || !availableDownloadTypes) return;
        
        downloadTypeOptions.innerHTML = '';
        
        Object.entries(availableDownloadTypes).forEach(([key, config]) => {
            const optionDiv = document.createElement('div');
            optionDiv.className = 'download-type-option';
            
            const requiresCodedeptoText = config.requires_coddepto ? 
                '<small style="color: #856404;">⚠️ Requiere código de departamento</small>' : '';
            
            // Crear un ID único para cada radio button
            const radioId = `download-type-${key}`;
            
            optionDiv.innerHTML = `
                <label class="mode-option" for="${radioId}">
                    <input type="radio" id="${radioId}" name="download-type" value="${key}" ${key === downloadType ? 'checked' : ''}>
                    <span>${config.icon} ${config.name}</span>
                    <p class="mode-description">${config.description}</p>
                    ${requiresCodedeptoText}
                </label>
            `;
            
            downloadTypeOptions.appendChild(optionDiv);
        });
        
        // Agregar event listeners a los radio buttons DESPUÉS de agregarlos al DOM
        setTimeout(() => {
            const downloadTypeRadios = document.querySelectorAll('input[name="download-type"]');
            downloadTypeRadios.forEach(radio => {
                radio.addEventListener('change', handleDownloadTypeChange);
            });
        }, 100);
    }
    
    // NUEVO: Función para manejar cambio de tipo de descarga
    async function handleDownloadTypeChange(event) {
        const selectedType = event.target.value;

        try {
            const response = await fetch(`${API_BASE_URL}/set_download_type`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    download_type: selectedType
                })
            });

            const data = await response.json();

            if (data.success) {
                downloadType = selectedType;
                logMessage(`Tipo de descarga cambiado a: ${data.config.name}`);

                // Mostrar advertencia si requiere CODDEPTO
                if (data.config.requires_coddepto) {
                    logMessage('⚠️ Este tipo de descarga requiere código de departamento en el Excel', 'warning');
                }

                // Mostrar/ocultar sección de rango CODDEPTO solo para store_only
                const coddeptoRangeSection = document.getElementById('coddepto-range-section');
                if (coddeptoRangeSection) {
                    if (selectedType === 'store_only') {
                        coddeptoRangeSection.style.display = 'block';
                    } else {
                        coddeptoRangeSection.style.display = 'none';
                    }
                }
            } else {
                logMessage(`Error al cambiar tipo de descarga: ${data.message}`, 'error');
                // Revertir selección
                event.target.checked = false;
                document.querySelector(`input[name="download-type"][value="${downloadType}"]`).checked = true;
            }
        } catch (error) {
            logMessage(`Error al cambiar tipo de descarga: ${error.message}`, 'error');
            // Revertir selección
            event.target.checked = false;
            document.querySelector(`input[name="download-type"][value="${downloadType}"]`).checked = true;
        }
    }

    function setStatus(element, message, type = 'info') {
        if (!element) return;
        element.textContent = message;
        element.className = 'status-area';
        if (type) {
            element.classList.add(type);
        }
    }

    function updateUIStep(targetStep, forceCompleteCurrentStep = false) {
        currentStep = targetStep;

        const hasLoadedExcel = expectedSkuFoldersForStep1.length > 0;
        const hasWorkingDirectory = workingDirectory && workingDirectory.trim();
        const isStep1Processing = step1StatusDiv.classList.contains('processing');
        const isStep1Verified = step1StatusDiv.classList.contains('success');

        // Simplificado: solo deshabilitar durante procesamiento
        excelFileInput.disabled = isStep1Processing;
        newProjectButton.disabled = isStep1Processing;

        // NUEVO: Considerar modo de operación para habilitar botón del paso 1
        const canStartStep1 = currentStep === 1 && hasLoadedExcel && !isStep1Verified && !isStep1Processing;
        const hasRequiredSourceForLocalMode = operationMode === 'download' || (operationMode === 'local_copy' && localSourcePath !== null);
        startStep1Button.disabled = !(canStartStep1 && hasRequiredSourceForLocalMode);

        // --- LÓGICA MODIFICADA PARA EL BOTÓN DE VERIFICACIÓN ---
        // El botón de verificación manual debe estar disponible tan pronto como se cargue un Excel,
        // y solo debe ocultarse si el paso 1 ya ha sido verificado con éxito.
        if (currentStep === 1 && hasLoadedExcel && !isStep1Verified) {
            reverifyStep1Button.style.display = 'inline-block';
            reverifyStep1Button.disabled = isStep1Processing; // Deshabilitar solo si la descarga está en curso.
        } else {
            reverifyStep1Button.style.display = 'none';
        }

        if(downloadMissingReportButton) {
            if (isStep1Verified || currentStep !== 1) {
                downloadMissingReportButton.style.display = 'none';
            }
        }
    }

    async function handleApiResponse(response, stepName = "Acción") {
        try {
            // Verificar primero si la respuesta puede ser parseada como JSON
            const contentType = response.headers.get("content-type");
            if (!contentType || !contentType.includes("application/json")) {
                // No es JSON válido, crear respuesta de error basada en el status
                const errorMsg = `Error en ${stepName}. Código HTTP: ${response.status} - ${response.statusText || 'Error de servidor'}`;
                logMessage(errorMsg, 'error');
                throw new Error(errorMsg);
            }

            const data = await response.json();

            if (response.ok && data.success !== false) {
                logMessage(`${stepName}: ${data.message || 'Completado exitosamente.'}`);
                return data;
            } else {
                const errorMsg = data.message || `Error en ${stepName}. Código HTTP: ${response.status}`;
                logMessage(errorMsg, 'error');
                throw new Error(errorMsg);
            }
        } catch (jsonError) {
            // Si falla el parseo de JSON, crear mensaje de error más descriptivo
            if (jsonError.message.includes('Unexpected token') || jsonError.message.includes('JSON')) {
                const errorMsg = `Error de comunicación en ${stepName}. El servidor no respondió con datos válidos. Código HTTP: ${response.status}`;
                logMessage(errorMsg, 'error');
                throw new Error(errorMsg);
            } else {
                // Re-lanzar otros errores que ya tienen mensajes descriptivos
                throw jsonError;
            }
        }
    }

    // --- Event Listeners ---

    newProjectButton.addEventListener('click', async () => {
        logMessage("Reseteando aplicación...", 'warning');
        if (!confirm("¿Estás seguro de que deseas resetear la aplicación? Se perderá todo el progreso no guardado.")) {
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/new_project`, { method: 'POST' });
            const data = await handleApiResponse(response, "Reset");
            setStatus(uploadStatusDiv, data.message, 'info');
            resetUIState();
        } catch (error) {
            setStatus(uploadStatusDiv, `Error al resetear aplicación: ${error.message}`, 'error');
        }
    });

    function resetUIState() {
        logMessage("Interfaz de usuario reseteada.");
        excelFileInput.value = ''; // Limpiar el input de archivo
        uploadedExcelFile = null;
        workingDirectory = '';
        expectedSkuFoldersForStep1 = [];

        // Ocultar carpeta de procesamiento
        workingDirectoryDisplay.style.display = 'none';
        workingDirectoryInfo.textContent = '';
        
        // NUEVO: Ocultar sección de selección de columnas
        columnSelectionSection.style.display = 'none';
        window.currentFileInfo = null;
        
        // NUEVO: Resetear modo de operación y tipo de descarga
        operationMode = 'download';
        downloadType = 'both_fallback';
        localSourcePath = null;
        operationModeSelector.style.display = 'none';
        downloadTypeSelector.style.display = 'none';
        localSourcePathSection.style.display = 'none';
        document.querySelector('input[name="operation-mode"][value="download"]').checked = true;
        localSourcePathInput.value = '';
        setStatus(sourcePathStatus, '', 'info');

        // Resetear agrupación por padre+color
        groupByParentColor = false;
        groupingColumnsAvailable = false;
        groupingToggleSection.style.display = 'none';
        if (groupByParentColorToggle) {
            groupByParentColorToggle.checked = false;
            groupByParentColorToggle.disabled = true;
        }
        setStatus(groupingStatus, '', 'info');

        // Resetear texto del botón
        step1ButtonText.textContent = 'Iniciar Descarga de Imágenes';
        stopButtonText.textContent = 'Detener Descarga';

        // Limpiar todos los estados y mensajes
        setStatus(uploadStatusDiv, 'Selecciona un archivo Excel para comenzar.', 'info');
        setStatus(step1StatusDiv, '', 'info');
        if(reverifyStep1StatusDiv) setStatus(reverifyStep1StatusDiv, '', 'info');
        if(downloadMissingReportButton) downloadMissingReportButton.style.display = 'none';
        if(reverifyStep1Button) reverifyStep1Button.style.display = 'none';

        updateUIStep(1);
    }
    
    // NUEVO: Event listeners para cambio de modo de operación
    operationModeRadios.forEach(radio => {
        radio.addEventListener('change', async (e) => {
            operationMode = e.target.value;
            logMessage(`Modo de operación cambiado a: ${operationMode === 'download' ? 'Descarga desde Internet' : 'Copiado Local'}`);

            // Mostrar/ocultar sección de ubicación de origen y tipo de descarga
            if (operationMode === 'local_copy') {
                localSourcePathSection.style.display = 'block';
                downloadTypeSelector.style.display = 'none';  // Ocultar selector de tipo para modo local
                groupingToggleSection.style.display = 'none';  // Ocultar toggle de agrupación en modo local
                step1ButtonText.textContent = 'Copiar Archivos';
                stopButtonText.textContent = 'Detener Copiado';
            } else {
                localSourcePathSection.style.display = 'none';
                downloadTypeSelector.style.display = 'block';  // Mostrar selector de tipo para descarga
                // SIEMPRE mostrar toggle en modo download (habilitado/deshabilitado según columnas)
                groupingToggleSection.style.display = 'block';
                localSourcePath = null;
                step1ButtonText.textContent = 'Iniciar Descarga de Imágenes';
                stopButtonText.textContent = 'Detener Descarga';
            }

            // Enviar modo al backend
            try {
                const response = await fetch(`${API_BASE_URL}/set_operation_mode`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ mode: operationMode })
                });

                const data = await response.json();
                if (data.success) {
                    logMessage(data.message);
                }
            } catch (error) {
                logMessage(`Error al establecer modo: ${error.message}`, 'error');
            }

            updateUIStep(currentStep);
        });
    });

    // NUEVO: Event listener para toggle de agrupación por padre+color
    if (groupByParentColorToggle) {
        groupByParentColorToggle.addEventListener('change', async (e) => {
            const enabled = e.target.checked;

            try {
                const response = await fetch(`${API_BASE_URL}/set_grouping_mode`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ enabled: enabled })
                });

                const data = await response.json();

                if (data.success) {
                    groupByParentColor = enabled;
                    setStatus(groupingStatus, data.message, 'success');
                    logMessage(data.message);
                } else {
                    // Si hubo error, revertir el toggle
                    e.target.checked = !enabled;
                    setStatus(groupingStatus, data.message, 'error');
                    logMessage(`Error al cambiar agrupación: ${data.message}`, 'error');
                }
            } catch (error) {
                // En caso de error de red, revertir el toggle
                e.target.checked = !enabled;
                setStatus(groupingStatus, `Error: ${error.message}`, 'error');
                logMessage(`Error al cambiar agrupación: ${error.message}`, 'error');
            }
        });
    }

    // NUEVO: Event listener para verificar ubicación de origen
    verifySourcePathButton.addEventListener('click', async () => {
        const sourcePath = localSourcePathInput.value.trim();
        
        if (!sourcePath) {
            setStatus(sourcePathStatus, 'Por favor ingrese una ubicación válida.', 'error');
            return;
        }
        
        setStatus(sourcePathStatus, 'Verificando ubicación...', 'info');
        logMessage(`Verificando ubicación de origen: ${sourcePath}`);
        
        try {
            const response = await fetch(`${API_BASE_URL}/set_local_source_path`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ source_path: sourcePath })
            });
            
            const data = await response.json();
            
            if (data.valid && data.success) {
                localSourcePath = data.source_path;
                setStatus(sourcePathStatus, `✅ ${data.message}`, 'success');
                logMessage(`Ubicación de origen verificada: ${localSourcePath}`);
            } else {
                localSourcePath = null;
                setStatus(sourcePathStatus, `❌ ${data.message}`, 'error');
                logMessage(data.message, 'error');
            }
            
            updateUIStep(currentStep);
        } catch (error) {
            localSourcePath = null;
            setStatus(sourcePathStatus, `Error al verificar ubicación: ${error.message}`, 'error');
            logMessage(`Error al verificar ubicación: ${error.message}`, 'error');
        }
    });

    // NUEVO: Event listener para aplicar rango CODDEPTO personalizado
    const applyCoddeptoRangeButton = document.getElementById('apply-coddepto-range-button');
    const coddeptoRangeStart = document.getElementById('coddepto-range-start');
    const coddeptoRangeEnd = document.getElementById('coddepto-range-end');
    const coddeptoRangeStatus = document.getElementById('coddepto-range-status');

    if (applyCoddeptoRangeButton) {
        applyCoddeptoRangeButton.addEventListener('click', async () => {
            const rangeStart = coddeptoRangeStart.value.trim();
            const rangeEnd = coddeptoRangeEnd.value.trim();

            // Si ambos campos están vacíos, usar valores por defecto (sin enviar al backend)
            if (!rangeStart && !rangeEnd) {
                setStatus(coddeptoRangeStatus, '✅ Usando rango por defecto (D100-D462)', 'success');
                logMessage('Rango CODDEPTO: usando rango por defecto D100-D462');
                return;
            }

            // Validar que ambos campos tengan valor si uno está lleno
            if (!rangeStart || !rangeEnd) {
                setStatus(coddeptoRangeStatus, '❌ Debe especificar tanto el inicio como el fin del rango', 'error');
                return;
            }

            setStatus(coddeptoRangeStatus, 'Aplicando rango...', 'info');

            try {
                const response = await fetch(`${API_BASE_URL}/set_coddepto_range`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        range_start: parseInt(rangeStart),
                        range_end: parseInt(rangeEnd)
                    })
                });

                const data = await response.json();

                if (data.success) {
                    setStatus(coddeptoRangeStatus, `✅ ${data.message}`, 'success');
                    logMessage(`Rango CODDEPTO personalizado: D${data.range_start}-D${data.range_end}`);
                } else {
                    setStatus(coddeptoRangeStatus, `❌ ${data.message}`, 'error');
                    logMessage(`Error al establecer rango: ${data.message}`, 'error');
                }
            } catch (error) {
                setStatus(coddeptoRangeStatus, `❌ Error al aplicar rango: ${error.message}`, 'error');
                logMessage(`Error al aplicar rango CODDEPTO: ${error.message}`, 'error');
            }
        });
    }

    // NUEVO: Event listeners para cargar planilla CODDEPTO personalizada
    const coddeptoListFileInput = document.getElementById('coddepto-list-file-input');
    const uploadCoddeptoListButton = document.getElementById('upload-coddepto-list-button');
    const clearCoddeptoListButton = document.getElementById('clear-coddepto-list-button');
    const coddeptoListStatus = document.getElementById('coddepto-list-status');

    if (uploadCoddeptoListButton && coddeptoListFileInput) {
        uploadCoddeptoListButton.addEventListener('click', async () => {
            const file = coddeptoListFileInput.files[0];

            if (!file) {
                setStatus(coddeptoListStatus, '❌ Por favor selecciona un archivo Excel', 'error');
                return;
            }

            setStatus(coddeptoListStatus, '⏳ Cargando planilla...', 'info');
            logMessage(`Cargando planilla CODDEPTO: ${file.name}`);

            try {
                const formData = new FormData();
                formData.append('file', file);

                const response = await fetch(`${API_BASE_URL}/upload_coddepto_list`, {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.success) {
                    setStatus(coddeptoListStatus, `✅ ${data.message}`, 'success');
                    logMessage(`Planilla CODDEPTO cargada: ${data.count} valores únicos`);
                    logMessage(`Primeros valores: ${data.preview.join(', ')}`);
                    logMessage(`Columna usada: ${data.column_used}`);

                    // Mostrar botón de limpiar
                    if (clearCoddeptoListButton) {
                        clearCoddeptoListButton.style.display = 'inline-block';
                    }

                    // Deshabilitar inputs de rango (la lista tiene prioridad)
                    if (coddeptoRangeStart && coddeptoRangeEnd) {
                        coddeptoRangeStart.disabled = true;
                        coddeptoRangeEnd.disabled = true;
                        if (applyCoddeptoRangeButton) {
                            applyCoddeptoRangeButton.disabled = true;
                        }
                    }
                } else {
                    setStatus(coddeptoListStatus, `❌ ${data.message}`, 'error');
                    logMessage(`Error al cargar planilla CODDEPTO: ${data.message}`, 'error');
                }
            } catch (error) {
                setStatus(coddeptoListStatus, `❌ Error al cargar planilla: ${error.message}`, 'error');
                logMessage(`Error al cargar planilla CODDEPTO: ${error.message}`, 'error');
            }
        });
    }

    if (clearCoddeptoListButton) {
        clearCoddeptoListButton.addEventListener('click', async () => {
            try {
                const response = await fetch(`${API_BASE_URL}/clear_coddepto_list`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });

                const data = await response.json();

                if (data.success) {
                    setStatus(coddeptoListStatus, data.message, 'success');
                    logMessage('Lista CODDEPTO personalizada limpiada');

                    // Limpiar input de archivo
                    if (coddeptoListFileInput) {
                        coddeptoListFileInput.value = '';
                    }

                    // Ocultar botón de limpiar
                    clearCoddeptoListButton.style.display = 'none';

                    // Rehabilitar inputs de rango
                    if (coddeptoRangeStart && coddeptoRangeEnd) {
                        coddeptoRangeStart.disabled = false;
                        coddeptoRangeEnd.disabled = false;
                        if (applyCoddeptoRangeButton) {
                            applyCoddeptoRangeButton.disabled = false;
                        }
                    }
                } else {
                    setStatus(coddeptoListStatus, `❌ ${data.message}`, 'error');
                    logMessage(`Error al limpiar lista: ${data.message}`, 'error');
                }
            } catch (error) {
                setStatus(coddeptoListStatus, `❌ Error: ${error.message}`, 'error');
                logMessage(`Error al limpiar lista CODDEPTO: ${error.message}`, 'error');
            }
        });
    }

    // Función para obtener la carpeta de un archivo (simulada - el navegador no permite acceso real al path)
    function getFileDirectory(file) {
        // En un navegador no podemos obtener la ruta real por seguridad
        // Retornamos un placeholder que indicará al backend usar la ubicación del archivo
        return "EXCEL_FILE_DIRECTORY";
    }

    excelFileInput.addEventListener('change', async (event) => {
        uploadedExcelFile = event.target.files[0];
        if (uploadedExcelFile) {
            setStatus(uploadStatusDiv, `Archivo seleccionado: ${uploadedExcelFile.name}`, 'info');
            logMessage(`Archivo seleccionado: ${uploadedExcelFile.name}`);

            // Solicitar al usuario la carpeta donde está el archivo Excel
            const userPath = prompt(
                `Por favor, ingresa la ruta donde está ubicado el archivo "${uploadedExcelFile.name}":\n\n` +
                `Puedes ingresar:\n` +
                `• Solo la carpeta: /Users/rjarad/Desktop/TEMP/test\n` +
                `• O la ruta completa: /Users/rjarad/Desktop/TEMP/test/archivo.xlsx\n\n` +
                `El sistema detectará automáticamente la carpeta.`
            );
            
            if (userPath && userPath.trim()) {
                let finalDirectory = userPath.trim();
                
                // Si la ruta incluye el nombre del archivo, extraer solo la carpeta
                if (finalDirectory.includes('.xlsx') || finalDirectory.includes('.xls')) {
                    // Extraer el directorio de la ruta completa del archivo
                    const lastSlash = finalDirectory.lastIndexOf('/');
                    if (lastSlash !== -1) {
                        finalDirectory = finalDirectory.substring(0, lastSlash);
                    }
                }
                
                workingDirectory = finalDirectory;
                
                // Mostrar información de carpeta
                workingDirectoryDisplay.style.display = 'block';
                workingDirectoryInfo.textContent = `Carpeta de procesamiento: ${workingDirectory}`;
                
                // Procesar automáticamente el archivo
                await processExcelFile();
            } else {
                // Usuario canceló o no ingresó carpeta
                excelFileInput.value = '';
                uploadedExcelFile = null;
                workingDirectory = '';
                setStatus(uploadStatusDiv, 'Debes especificar la carpeta donde está el archivo Excel.', 'warning');
            }
        } else {
            // Resetear cuando no hay archivo
            uploadedExcelFile = null;
            workingDirectory = '';
            expectedSkuFoldersForStep1 = [];
            workingDirectoryDisplay.style.display = 'none';
            workingDirectoryInfo.textContent = '';
            setStatus(uploadStatusDiv, 'Ningún archivo seleccionado.', 'info');
        }
        updateUIStep(currentStep);
    });

    // Función simplificada - solo verifica paso 1 para descargador de imagenes
    async function autoVerifyAllSteps() {
        logMessage('Verificando si hay descargas previas...', 'info');

        try {
            // Verificar Paso 1
            logMessage('Verificando Paso 1...', 'info');
            const step1Response = await fetch(`${API_BASE_URL}/verify_step1`);
            const step1Data = await step1Response.json();

            if (!step1Data.verified) {
                logMessage('Paso 1 no completado. Listo para iniciar descarga.', 'info');
                updateUIStep(1);
                return;
            }

            logMessage('✓ Paso 1 verificado - Imágenes ya descargadas', 'info');
            setStatus(step1StatusDiv, 'Paso 1 verificado: Todas las carpetas presentes', 'success');
            updateUIStep(1);

        } catch (error) {
            logMessage(`Error durante verificación: ${error.message}`, 'error');
            updateUIStep(1);
        }
    }

    // Nueva función para procesar automáticamente el archivo Excel
    async function processExcelFile() {
        if (!uploadedExcelFile) {
            setStatus(uploadStatusDiv, 'Error: No hay archivo seleccionado.', 'error');
            return;
        }

        const formData = new FormData();
        formData.append('file', uploadedExcelFile);

        // Enviar la carpeta real donde está el archivo Excel
        formData.append('working_directory', workingDirectory);
        logMessage(`Procesando archivo en: ${workingDirectory}`);

        setStatus(uploadStatusDiv, 'Procesando archivo Excel...', 'info');
        logMessage('Iniciando procesamiento automático de archivo Excel...');

        // Deshabilitar input durante procesamiento
        excelFileInput.disabled = true;
        if(reverifyStep1Button) reverifyStep1Button.disabled = true;

        try {
            const response = await fetch(`${API_BASE_URL}/upload_excel`, { method: 'POST', body: formData });
            const data = await response.json();

            if (data.success) {
                // Archivo procesado exitosamente
                setStatus(uploadStatusDiv, `${data.message} ✓ Listo para descargar imágenes.`, 'success');

                if (data.expected_sku_folders && Array.isArray(data.expected_sku_folders)) {
                    expectedSkuFoldersForStep1 = data.expected_sku_folders;
                    logMessage(`Se encontraron ${expectedSkuFoldersForStep1.length} SKUs para procesar.`);
                } else {
                    logMessage("Advertencia: No se recibió la lista de carpetas SKU esperadas del backend.", "warning");
                    expectedSkuFoldersForStep1 = [];
                }

                // Actualizar información de carpeta de trabajo
                if (data.working_directory) {
                    workingDirectoryInfo.textContent = `Carpeta de procesamiento: ${data.working_directory}`;
                    logMessage(`Procesamiento configurado en: ${data.working_directory}`);
                }

                // Ocultar sección de selección de columnas si estaba visible
                columnSelectionSection.style.display = 'none';
                
                // Mostrar selector de modo de operación
                operationModeSelector.style.display = 'block';
                
                // Cargar tipos de descarga disponibles
                await loadDownloadTypes();
                
                // Mostrar selector de tipo de descarga por defecto (modo download)
                if (operationMode === 'download') {
                    downloadTypeSelector.style.display = 'block';
                }
                
                logMessage('Seleccione el modo de operación y tipo de descarga para iniciar.');

                // Ejecutar verificación si hay descargas previas
                logMessage('Verificando estado actual...', 'info');
                await autoVerifyAllSteps();

            } else if (data.needs_column_selection) {
                // Necesita selección de columnas
                setStatus(uploadStatusDiv, data.message, 'warning');
                logMessage('Se requiere selección manual de columnas.', 'warning');

                // Mostrar sección de selección de columnas
                columnSelectionSection.style.display = 'block';

                // Poblar el dropdown con las columnas disponibles y preseleccionar por defecto
                populateColumnSelectors(data.available_columns, data.default_sku_column);

                // Guardar información para usar después
                window.currentFileInfo = {
                    filename: data.filename,
                    working_directory: data.working_directory
                };

            } else {
                // Error normal
                throw new Error(data.message);
            }
        } catch (error) {
            setStatus(uploadStatusDiv, `Error en procesamiento: ${error.message}`, 'error');
            expectedSkuFoldersForStep1 = [];

            // Si hay error de carpeta, resetear para permitir reintento
            if (error.message.includes('carpeta') || error.message.includes('directorio')) {
                excelFileInput.disabled = false;
                workingDirectoryDisplay.style.display = 'none';
                workingDirectoryInfo.textContent = '';
                logMessage('Error de carpeta: puedes intentar seleccionar el archivo nuevamente.', 'warning');
            }
        } finally {
            // No llamar updateUIStep aquí porque autoVerifyAllSteps ya lo hace
        }
    }

    startStep1Button.addEventListener('click', async () => {
        // Primero verificar si hay carpetas existentes
        setStatus(step1StatusDiv, 'Verificando carpetas existentes...', 'info');
        logMessage('Verificando carpetas pre-existentes en la ubicación de destino...');
        
        try {
            // Llamar al endpoint de verificación previa
            const verifyResponse = await fetch(`${API_BASE_URL}/verify_existing_folders`, { method: 'POST' });
            const verifyData = await verifyResponse.json();
            
            if (verifyData.has_existing) {
                // Hay carpetas existentes - mostrar popup de confirmación
                const existingCount = verifyData.existing_count || 0;
                const newCount = verifyData.new_count || 0;
                const totalCount = verifyData.total_count || 0;
                const existingList = verifyData.existing_folders || [];
                
                // Crear mensaje del popup
                let message = `Se encontraron ${existingCount} carpeta(s) que ya existen en la ubicación de destino.\n\n`;
                message += `📊 Resumen:\n`;
                message += `• Total de productos en Excel: ${totalCount}\n`;
                message += `• Ya descargados (se omitirán): ${existingCount}\n`;
                message += `• Por descargar (nuevos): ${newCount}\n\n`;
                
                if (existingList.length > 0 && existingList.length <= 10) {
                    message += `Carpetas que se omitirán:\n${existingList.join(', ')}\n\n`;
                } else if (existingList.length > 10) {
                    message += `Carpetas que se omitirán (primeras 10):\n${existingList.slice(0, 10).join(', ')}... y ${existingList.length - 10} más\n\n`;
                }
                
                message += `⚠️ Las carpetas existentes NO se sobrescribirán.\n\n`;
                message += `¿Desea continuar con la descarga de las ${newCount} carpeta(s) faltantes?`;
                
                // Mostrar confirmación
                if (!confirm(message)) {
                    logMessage('Descarga cancelada por el usuario.', 'warning');
                    setStatus(step1StatusDiv, 'Descarga cancelada por el usuario.', 'warning');
                    return; // Usuario canceló
                }
            }
            
            // Usuario confirmó o no hay carpetas existentes - continuar con la descarga
            logMessage('Iniciando proceso de descarga...');
            
        } catch (error) {
            logMessage(`Error al verificar carpetas existentes: ${error.message}. Continuando con la descarga...`, 'warning');
            // Si falla la verificación, continuar de todos modos
        }
        
        // Marcar que la descarga está en proceso
        isDownloadRunning = true;
        totalSkusToProcess = expectedSkuFoldersForStep1.length;

        // Actualizar UI
        setStatus(step1StatusDiv, 'Paso 1: Descargando imágenes...', 'info');
        step1StatusDiv.classList.add('processing');
        logMessage('Paso 1: Iniciando descarga de imágenes...');
        
        // Mostrar botón de detener, ocultar botón de iniciar
        startStep1Button.style.display = 'none';
        stopStep1Button.style.display = 'inline-block';
        
        if(downloadMissingReportButton) downloadMissingReportButton.style.display = 'none';
        if(reverifyStep1StatusDiv) setStatus(reverifyStep1StatusDiv, '', 'info');

        // Mostrar barra de progreso simple
        document.getElementById('progress-container').style.display = 'block';
        document.getElementById('progress-text').textContent = 'Iniciando descarga...';
        document.getElementById('progress-percentage').textContent = '0%';
        document.getElementById('progress-bar').style.width = '0%';
        
        // Iniciar polling de progreso
        startEventsPolling();

        updateUIStep(currentStep);

        try {
            // Iniciar descarga asíncrona
            const response = await fetch(`${API_BASE_URL}/start_step1_download`, { method: 'POST' });
            const data = await handleApiResponse(response, "Iniciar Descarga");

            if (data.success && data.details && data.details.background_process) {
                // Descarga iniciada en background exitosamente
                setStatus(step1StatusDiv, data.message, 'info');
                logMessage('Descarga iniciada en segundo plano. Monitoreando progreso...');

                // Iniciar monitoreo del progreso de la descarga asíncrona
                await monitorAsyncDownload();
            } else {
                // Error al iniciar la descarga
                setStatus(step1StatusDiv, data.message || 'Error al iniciar descarga', 'error');
                logMessage(`Error al iniciar descarga: ${data.message}`, 'error');
                throw new Error(data.message || 'Error al iniciar descarga');
            }

        } catch (error) {
            // Mejorar el manejo de errores de fetch/red
            let errorMessage = error.message;
            if (error.message === 'Failed to fetch' || error.message.includes('NetworkError') || error.message.includes('fetch')) {
                errorMessage = 'Error de conexión con el servidor. Verifique su conexión a internet y que el servidor esté funcionando.';
            } else if (error.message.includes('timeout')) {
                errorMessage = 'La solicitud tardó demasiado tiempo. El servidor puede estar ocupado, intente nuevamente.';
            }

            setStatus(step1StatusDiv, `Error al iniciar descarga: ${errorMessage}`, 'error');
            logMessage(`Error al iniciar descarga: ${errorMessage}`, 'error');

            // Limpiar estado de descarga en caso de error
            isDownloadRunning = false;
            step1StatusDiv.classList.remove('processing');
            startStep1Button.style.display = 'inline-block';
            stopStep1Button.style.display = 'none';
            stopEventsPolling();
            document.getElementById('progress-container').style.display = 'none';
            updateUIStep(currentStep);
        }
    });

    // NUEVO: Función para monitorear descarga asíncrona
    async function monitorAsyncDownload() {
        let downloadCompleted = false;
        let downloadWasSuccessful = false;

        // Asegurar que la barra de progreso se muestre desde el inicio
        document.getElementById('progress-container').style.display = 'block';
        document.getElementById('progress-text').textContent = 'Iniciando descarga...';
        document.getElementById('progress-percentage').textContent = '0%';
        document.getElementById('progress-bar').style.width = '0%';

        logMessage('Iniciando monitoreo de descarga asíncrona...', 'info');

        while (!downloadCompleted) {
            try {
                const response = await fetch(`${API_BASE_URL}/status`);
                if (!response.ok) {
                    await new Promise(resolve => setTimeout(resolve, 2000)); // Esperar 2 segundos antes de reintentar
                    continue;
                }

                const data = await response.json();

                // Actualizar progreso visual
                const processed = data.processed_skus || 0;
                const total = data.total_skus || totalSkusToProcess || 1; // Evitar división por 0

                const percentage = Math.round((processed / total) * 100);
                document.getElementById('progress-percentage').textContent = `${percentage}%`;
                document.getElementById('progress-bar').style.width = `${percentage}%`;

                // Actualizar texto de progreso basado en el estado
                if (data.download_completed) {
                    document.getElementById('progress-text').textContent = `Descarga completada: ${processed} productos procesados`;
                } else if (data.download_in_progress) {
                    document.getElementById('progress-text').textContent = `Procesando: ${processed} de ${total} productos`;
                } else if (data.total_skus > 0) {
                    document.getElementById('progress-text').textContent = `Preparando descarga de ${data.total_skus} productos...`;
                } else {
                    document.getElementById('progress-text').textContent = 'Iniciando descarga...';
                }

                // Log de progreso para debugging
                if (processed > 0 || data.download_in_progress) {
                    logMessage(`Progreso: ${processed}/${total} productos (${percentage}%)`, 'info');
                }

                // Verificar si la descarga ha terminado
                if (data.download_completed) {
                    downloadCompleted = true;

                    // DEBUG: Log para verificar que tenemos download_results
                    console.log("DEBUG - download_completed=true, download_results:", data.download_results);

                    // Procesar resultados
                    if (data.download_results) {
                        const results = data.download_results;

                        if (results.cancelled) {
                            const totalImages = results.details?.total_images_downloaded || 0;
                            const totalProducts = results.details?.total_items_processed || 0;
                            let message = results.message || 'Descarga cancelada';
                            if (totalImages > 0 && totalProducts > 0) {
                                message += ` (${totalImages} imágenes descargadas de ${totalProducts} productos antes de cancelar)`;
                            }
                            setStatus(step1StatusDiv, message, 'warning');
                            logMessage(`Descarga cancelada exitosamente. ${totalImages} imágenes descargadas.`, 'warning');
                            downloadWasSuccessful = false;
                        } else if (results.success) {
                            // Buscar en ambos lugares: nivel superior y details (para compatibilidad)
                            const totalImages = results.total_images_downloaded || results.details?.total_images_downloaded || 0;
                            const totalProducts = results.total_items_processed || results.details?.total_items_processed || 0;
                            const skippedCount = results.skipped_count || 0;
                            
                            if (totalImages > 0 || skippedCount > 0) {
                                let message = `Descarga completada: ${totalImages} imágenes descargadas de ${totalProducts} productos`;
                                if (skippedCount > 0) {
                                    message += `. ${skippedCount} carpetas omitidas (ya existían)`;
                                }
                                setStatus(step1StatusDiv, message, 'success');
                                downloadWasSuccessful = true;
                            } else {
                                setStatus(step1StatusDiv, `Descarga completada pero no se descargaron imágenes. Se procesaron ${totalProducts} productos. Revise que los SKUs sean válidos.`, 'warning');
                                downloadWasSuccessful = false;
                            }
                        } else {
                            setStatus(step1StatusDiv, `Error en descarga: ${results.message || 'Error desconocido'}`, 'error');
                            downloadWasSuccessful = false;
                        }
                    } else if (data.download_error) {
                        setStatus(step1StatusDiv, `Error en descarga: ${data.download_error}`, 'error');
                        downloadWasSuccessful = false;
                    } else {
                        // DEBUG: Fallback - no hay download_results ni download_error
                        console.log("DEBUG - Fallback: download_results=", data.download_results, "download_error=", data.download_error);

                        // Fallback si no hay resultados específicos
                        setStatus(step1StatusDiv, 'Descarga completada', 'info');
                        downloadWasSuccessful = false; // Conservador: no verificar automáticamente sin datos
                    }
                } else if (data.download_error && !data.download_in_progress) {
                    // Error sin que la descarga esté en progreso
                    downloadCompleted = true;
                    setStatus(step1StatusDiv, `Error en descarga: ${data.download_error}`, 'error');
                    downloadWasSuccessful = false;
                }

                // Si no ha terminado, esperar antes del siguiente chequeo
                if (!downloadCompleted) {
                    await new Promise(resolve => setTimeout(resolve, 2000)); // Esperar 2 segundos
                }

            } catch (error) {
                console.error('Error monitoreando descarga:', error);
                await new Promise(resolve => setTimeout(resolve, 3000)); // Esperar más tiempo en caso de error
            }
        }

        // Limpiar estado después de que la descarga termine
        isDownloadRunning = false;
        step1StatusDiv.classList.remove('processing');
        startStep1Button.style.display = 'inline-block';
        stopStep1Button.style.display = 'none';
        stopEventsPolling();
        document.getElementById('progress-container').style.display = 'none';

        // Ejecutar verificación si la descarga fue exitosa
        if (downloadWasSuccessful) {
            logMessage('Descarga exitosa. Verificando estado de verificación automática...');

            // Esperar un momento para que el backend complete la verificación automática
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Verificar si el backend ya completó la verificación automática
            try {
                const statusResponse = await fetch(`${API_BASE_URL}/status`);
                const statusData = await statusResponse.json();

                if (statusData.step1_verified) {
                    // El backend ya verificó automáticamente - actualizar UI
                    setStatus(step1StatusDiv, '✅ Verificación automática completada. Todas las carpetas verificadas. Paso 2 habilitado.', 'success');
                    logMessage('Verificación automática exitosa detectada.');
                    updateUIStep(2); // Habilitar paso 2
                } else {
                    // Ejecutar verificación manual si la automática no fue exitosa
                    logMessage('Verificación automática no completada. Ejecutando verificación manual...');
                    await verifyStep(1);
                }
            } catch (error) {
                // Si hay error al verificar el estado, ejecutar verificación manual
                logMessage('Error verificando estado. Ejecutando verificación manual...');
                await verifyStep(1);
            }
        } else {
            logMessage('Descarga no exitosa. Saltando verificación automática.', 'warning');
            updateUIStep(currentStep);
        }
    }

    // MEJORADO: Función para actualizar el visor de eventos con feedback detallado
    async function updateProgressBar() {
        try {
            const response = await fetch(`${API_BASE_URL}/processing_events`);
            
            if (!response.ok) {
                return; // Silently fail for progress updates
            }
            
            const data = await response.json();
            
            // Actualizar progreso simple
            const processed = data.processed_skus || 0;
            const total = data.total_skus || totalSkusToProcess;
            
            if (total > 0) {
                const percentage = Math.round((processed / total) * 100);
                document.getElementById('progress-percentage').textContent = `${percentage}%`;
                document.getElementById('progress-bar').style.width = `${percentage}%`;
                
                if (processed >= total) {
                    document.getElementById('progress-text').textContent = `Descarga completada: ${processed} productos procesados`;
                } else {
                    document.getElementById('progress-text').textContent = `Procesando: ${processed} de ${total} productos`;
                }
            }
            
        } catch (error) {
            // Silent fail for progress updates
            console.log('Progress update error:', error);
        }
    }

    // NUEVO: Actualizar eventos cada 2 segundos durante el procesamiento
    let eventsInterval = null;
    
    function startEventsPolling() {
        // Limpiar cualquier polling anterior
        if (eventsInterval) {
            clearInterval(eventsInterval);
        }
        eventsInterval = setInterval(updateProgressBar, 2000); // Actualizar cada 2 segundos
    }
    
    function stopEventsPolling() {
        if (eventsInterval) {
            clearInterval(eventsInterval);
            eventsInterval = null;
        }
    }

    // NUEVO: Event listener para botón de detener - Mejorado
    stopStep1Button.addEventListener('click', async () => {
        if (confirm('¿Estás seguro de que deseas detener la descarga? El progreso actual se perderá.')) {
            
            // NUEVO: Deshabilitar botón inmediatamente para evitar clics múltiples
            stopStep1Button.disabled = true;
            stopStep1Button.textContent = 'Cancelando...';
            
            logMessage('Usuario solicitó detener la descarga. Enviando señal de cancelación...', 'warning');
            setStatus(step1StatusDiv, 'Cancelando descarga, por favor espere...', 'warning');
            
            try {
                // Llamar al endpoint de cancelación
                const response = await fetch(`${API_BASE_URL}/cancel_download`, { method: 'POST' });
                const data = await response.json();
                
                if (data.success) {
                    setStatus(step1StatusDiv, 'Descarga cancelada por el usuario.', 'warning');
                    logMessage('Descarga cancelada exitosamente.', 'warning');
                    
                    // NUEVO: Esperar un poco para que el backend procese la cancelación
                    setTimeout(() => {
                        updateProgressBar(); // Actualización final del progreso
                    }, 1000);
                    
                } else {
                    setStatus(step1StatusDiv, 'Error al cancelar la descarga.', 'error');
                    
                    // Reactivar botón si falló la cancelación
                    stopStep1Button.disabled = false;
                    stopStep1Button.textContent = 'Detener Descarga';
                    return; // No continuar con la limpieza si falló
                }
            } catch (error) {
                setStatus(step1StatusDiv, 'Error de conexión al cancelar la descarga.', 'error');
                logMessage(`Error de conexión al cancelar descarga: ${error.message}`, 'error');
                
                // Reactivar botón si hubo error de conexión
                stopStep1Button.disabled = false;
                stopStep1Button.textContent = 'Detener Descarga';
                return; // No continuar con la limpieza si hubo error
            }
            
            // Limpiar estado SOLO si la cancelación fue exitosa
            isDownloadRunning = false;
            step1StatusDiv.classList.remove('processing');
            stopEventsPolling();
            startStep1Button.style.display = 'inline-block';
            stopStep1Button.style.display = 'none';
            stopStep1Button.disabled = false;
            stopStep1Button.textContent = 'Detener Descarga';
            
            // Ocultar barra de progreso al cancelar
            document.getElementById('progress-container').style.display = 'none';
            
            updateUIStep(currentStep);
        }
    });


    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function verifyStep(stepToVerify) {
        let verifyUrl = '';
        let statusDiv = null;
        let liveFeedbackDiv = (stepToVerify === 1) ? reverifyStep1StatusDiv : null;
        let stepName = '';

        if (stepToVerify === 1) {
            verifyUrl = `${API_BASE_URL}/verify_step1`;
            statusDiv = step1StatusDiv;
            stepName = 'Verificación Paso 1';
            if (reverifyStep1Button) reverifyStep1Button.disabled = true;
            if (downloadMissingReportButton) downloadMissingReportButton.style.display = 'none';

            // La barra de progreso se mantiene visible durante verificación
        } else {
            return;
        }

        if (liveFeedbackDiv) setStatus(liveFeedbackDiv, 'Iniciando verificación...', 'info');
        const mainStatusMsgPrefix = statusDiv.textContent.split(" :: ")[0];
        setStatus(statusDiv, `${mainStatusMsgPrefix} :: ${stepName}: Verificando...`, 'info');
        logMessage(`${stepName}: Iniciando...`);

        // Simulación visual de la verificación para el feedback del usuario
        if (stepToVerify === 1 && expectedSkuFoldersForStep1 && expectedSkuFoldersForStep1.length > 0) {
            if (liveFeedbackDiv) liveFeedbackDiv.innerHTML = '';
            for (let i = 0; i < expectedSkuFoldersForStep1.length; i++) {
                const sku = expectedSkuFoldersForStep1[i];
                if (i % 10 === 0) { // Actualiza el DOM no tan frecuentemente para no ralentizar
                    const checkingMsg = `Verificando carpeta para SKU: ${sku} (${i + 1} de ${expectedSkuFoldersForStep1.length})...`;
                    if (liveFeedbackDiv) {
                        const p = document.createElement('p');
                        p.textContent = checkingMsg;
                        liveFeedbackDiv.prepend(p);
                        while (liveFeedbackDiv.childElementCount > 10) {
                            liveFeedbackDiv.removeChild(liveFeedbackDiv.lastChild);
                        }
                    }
                    await sleep(1); // Pequeña pausa para permitir que la UI se actualice
                }
            }
            if (liveFeedbackDiv) {
                const allSkusCheckedMsg = `Revisión frontend completada. Esperando respuesta final del backend...`;
                const p = document.createElement('p');
                p.innerHTML = `<strong>${allSkusCheckedMsg}</strong>`;
                liveFeedbackDiv.prepend(p);
            }
        }

        try {
            const response = await fetch(verifyUrl);
            const data = await response.json();

            if (!response.ok && !data.message) {
                 throw new Error(`Error en ${stepName}. Código HTTP: ${response.status}`);
            }

            if (data.verified) {
                setStatus(statusDiv, `${data.message || stepName + ' verificada exitosamente.'}`, 'success');
                if(liveFeedbackDiv) setStatus(liveFeedbackDiv, 'Verificación completada con éxito por el backend.', 'success');
                logMessage(`${stepName} exitosa.`);
                if (downloadMissingReportButton && stepToVerify === 1) {
                    downloadMissingReportButton.style.display = 'none';
                }
                updateUIStep(currentStep + 1);
            } else {
                setStatus(statusDiv, `${data.message || stepName + ' falló la verificación.'}`, 'error');
                if(liveFeedbackDiv) setStatus(liveFeedbackDiv, 'Verificación backend reportó problemas.', 'error');
                logMessage(`${stepName} fallida: ${data.message}`, 'error');

                if (stepToVerify === 1 && data.report_available === true) {
                    if (downloadMissingReportButton) {
                        downloadMissingReportButton.style.display = 'inline-block';
                        downloadMissingReportButton.disabled = false;
                    }
                    logMessage(`Reporte de SKUs faltantes disponible (Faltantes: ${data.missing_count || 'N/A'}).`);
                } else if (downloadMissingReportButton && stepToVerify === 1) {
                    downloadMissingReportButton.style.display = 'none';
                }
            }
        } catch (error) {
            setStatus(statusDiv, `Error en ${stepName}: ${error.message}`, 'error');
            if(liveFeedbackDiv) setStatus(liveFeedbackDiv, `Error durante la verificación: ${error.message}`, 'error');
            logMessage(`Error en ${stepName}: ${error.message}`, 'error');
            if (downloadMissingReportButton && stepToVerify === 1) {
                 downloadMissingReportButton.style.display = 'none';
            }
        } finally {
            // NUEVO: Hacer una actualización final del visor de eventos para mostrar estado final
            if (stepToVerify === 1) {
                setTimeout(async () => {
                    await updateProgressBar();
                }, 500); // Pequeño delay para permitir que el backend procese
            }
            updateUIStep(currentStep);
        }
    }

    reverifyStep1Button.addEventListener('click', async () => {
        logMessage("Iniciando verificación manual del Paso 1...");
        if(reverifyStep1StatusDiv) {
            setStatus(reverifyStep1StatusDiv, 'Iniciando verificación de carpetas...', 'info');
            reverifyStep1StatusDiv.innerHTML = '';
        }
        if(downloadMissingReportButton) downloadMissingReportButton.style.display = 'none';
        await verifyStep(1);
    });

    if (downloadMissingReportButton) {
        downloadMissingReportButton.addEventListener('click', () => {
            logMessage("Solicitando descarga del reporte de SKUs faltantes...");
            window.location.href = `${API_BASE_URL}/download_missing_sku_report`;
        });
    }


    // Mostrar instrucciones del script helper (solo si el elemento existe)
    const runHelperScriptButton = document.getElementById('run-helper-script');
    const helperInstructionsDiv = document.getElementById('helper-instructions');
    if (runHelperScriptButton && helperInstructionsDiv) {
        runHelperScriptButton.addEventListener('click', function() {
            helperInstructionsDiv.style.display = 'block';
            setStatus(uploadStatusDiv, 'Sigue las instrucciones para autocompletar la ruta usando el script.', 'info');
        });
    }

    // Initial UI setup
    resetUIState();

    // Función para poblar el dropdown de selección de columna
    function populateColumnSelectors(columns, defaultSkuColumn = null) {
        // Limpiar opciones existentes para SKU
        skuColumnSelect.innerHTML = '<option value="">-- Seleccione una columna --</option>';
        
        // Limpiar opciones existentes para CODDEPTO
        coddeptoColumnSelect.innerHTML = '<option value="">-- Sin código de departamento --</option>';

        // Agregar opciones de columnas para ambos selectores
        columns.forEach(column => {
            // Opción para SKU
            const skuOption = document.createElement('option');
            skuOption.value = column;
            skuOption.textContent = column;
            skuColumnSelect.appendChild(skuOption);
            
            // Opción para CODDEPTO
            const coddeptoOption = document.createElement('option');
            coddeptoOption.value = column;
            coddeptoOption.textContent = column;
            coddeptoColumnSelect.appendChild(coddeptoOption);
        });

        // Preseleccionar columna por defecto si existe
        if (defaultSkuColumn && columns.includes(defaultSkuColumn)) {
            skuColumnSelect.value = defaultSkuColumn;
            logMessage(`Columna SKU preseleccionada: ${defaultSkuColumn}`, 'info');
        } else if (columns.length === 1) {
            // Si solo hay una columna disponible, seleccionarla automáticamente
            skuColumnSelect.value = columns[0];
            logMessage(`Columna SKU única seleccionada automáticamente: ${columns[0]}`, 'info');
        }
        
        // Intentar preseleccionar CODDEPTO si hay una columna que lo sugiera
        const possibleCoddeptoColumns = columns.filter(col => 
            col.toLowerCase().includes('depto') || 
            col.toLowerCase().includes('departamento') ||
            col.toLowerCase().includes('coddepto')
        );
        
        if (possibleCoddeptoColumns.length === 1) {
            coddeptoColumnSelect.value = possibleCoddeptoColumns[0];
            logMessage(`Columna CODDEPTO detectada automáticamente: ${possibleCoddeptoColumns[0]}`, 'info');
        }

        // Validar selección después de preseleccionar
        validateColumnSelection();

        logMessage(`Columnas disponibles en el Excel: ${columns.join(', ')}`);
    }

    // Función para validar selección de columna
    function validateColumnSelection() {
        if (!skuColumnSelect || !confirmColumnsButton || !coddeptoColumnSelect) {
            console.error('Error: Elementos de selección de columna no encontrados');
            return;
        }
        
        const skuColumn = skuColumnSelect.value;
        const coddeptoColumn = coddeptoColumnSelect.value;
        const isValid = skuColumn && skuColumn.trim() !== '';
        
        confirmColumnsButton.disabled = !isValid;
        
        if (isValid) {
            let message = `Columna SKU seleccionada: "${skuColumn}"`;
            if (coddeptoColumn && coddeptoColumn.trim() !== '') {
                message += `, CODDEPTO: "${coddeptoColumn}"`;
            }
            message += '. Haga clic en "Confirmar Selección" para continuar.';
            setStatus(uploadStatusDiv, message, 'info');
        }
    }

    // Event listeners para la selección de columnas
    skuColumnSelect.addEventListener('change', validateColumnSelection);
    coddeptoColumnSelect.addEventListener('change', validateColumnSelection);

    // Event listener para confirmar selección de columna
    confirmColumnsButton.addEventListener('click', async () => {
        const skuColumn = skuColumnSelect.value;
        const coddeptoColumn = coddeptoColumnSelect.value;
        const fileInfo = window.currentFileInfo;
        
        if (!fileInfo) {
            setStatus(uploadStatusDiv, 'Error: Información del archivo no disponible. Intente cargar el archivo nuevamente.', 'error');
            return;
        }
        
        let logMsg = `Confirmando selección - SKU: "${skuColumn}"`;
        if (coddeptoColumn && coddeptoColumn.trim() !== '') {
            logMsg += `, CODDEPTO: "${coddeptoColumn}"`;
        }
        logMessage(logMsg);
        setStatus(uploadStatusDiv, 'Procesando selección de columnas...', 'info');
        confirmColumnsButton.disabled = true;
        
        try {
            const formData = new FormData();
            formData.append('sku_column', skuColumn);
            formData.append('filename', fileInfo.filename);
            
            // Agregar columna CODDEPTO si está seleccionada
            if (coddeptoColumn && coddeptoColumn.trim() !== '') {
                formData.append('coddepto_column', coddeptoColumn);
            }
            
            const response = await fetch(`${API_BASE_URL}/confirm_column_selection`, {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.detail || `Error HTTP ${response.status}`);
            }
            
            if (data.success) {
                setStatus(uploadStatusDiv, `${data.message} ✓ Listo para descargar imágenes.`, 'success');

                // Actualizar datos para el procesamiento
                expectedSkuFoldersForStep1 = data.expected_sku_folders || [];
                logMessage(`Columna confirmada. Se encontraron ${expectedSkuFoldersForStep1.length} identificadores para procesar.`);

                // Actualizar información de carpeta de trabajo
                if (data.working_directory) {
                    workingDirectoryDisplay.style.display = 'block';
                    workingDirectoryInfo.textContent = `Carpeta de procesamiento: ${data.working_directory}`;
                    logMessage(`Procesamiento configurado en: ${data.working_directory}`);
                }

                // Ocultar sección de selección de columna
                columnSelectionSection.style.display = 'none';

                // Mostrar selector de modo de operación
                operationModeSelector.style.display = 'block';

                // Cargar tipos de descarga disponibles
                await loadDownloadTypes();

                // Mostrar selector de tipo de descarga por defecto (modo download)
                if (operationMode === 'download') {
                    downloadTypeSelector.style.display = 'block';
                }

                // DEBUG: Log de valores recibidos
                console.log('DEBUG - Respuesta de confirmación de columnas:', {
                    grouping_columns_available: data.grouping_columns_available,
                    grouping_message: data.grouping_message,
                    operation_mode: operationMode
                });

                // Guardar disponibilidad de columnas
                groupingColumnsAvailable = data.grouping_columns_available || false;

                // SIEMPRE mostrar toggle en modo download (independiente de columnas)
                if (operationMode === 'download') {
                    if (groupingToggleSection) {
                        groupingToggleSection.style.display = 'block';
                        console.log('DEBUG - Toggle de agrupación MOSTRADO (modo download)');
                    } else {
                        console.error('ERROR - Elemento groupingToggleSection no encontrado');
                    }
                } else {
                    // Ocultar en modo local_copy
                    if (groupingToggleSection) {
                        groupingToggleSection.style.display = 'none';
                    }
                    console.log('DEBUG - Toggle OCULTO (modo local_copy)');
                }

                // Habilitar/deshabilitar según disponibilidad de columnas
                if (groupByParentColorToggle) {
                    if (groupingColumnsAvailable) {
                        groupByParentColorToggle.disabled = false;
                        console.log('DEBUG - Toggle HABILITADO (columnas disponibles)');

                        // Mensaje de éxito
                        if (data.grouping_message) {
                            setStatus(groupingStatus, data.grouping_message, 'success');
                            logMessage(data.grouping_message);
                        }
                    } else {
                        groupByParentColorToggle.disabled = true;
                        groupByParentColorToggle.checked = false;
                        console.log('DEBUG - Toggle DESHABILITADO (columnas faltantes)');

                        // Mensaje de advertencia explicando por qué está deshabilitado
                        const warningMsg = data.grouping_message || "⚠️ Agrupación no disponible: requiere columnas 'color' y 'codskupadrelargo'";
                        setStatus(groupingStatus, warningMsg, 'warning');
                        logMessage(warningMsg, 'warning');
                    }
                }

                logMessage('Seleccione el modo de operación y tipo de descarga para iniciar.');

                // Ejecutar verificación si hay descargas previas
                logMessage('Verificando estado actual...', 'info');
                await autoVerifyAllSteps();

            } else {
                throw new Error(data.message || 'Error desconocido al confirmar columna');
            }
            
        } catch (error) {
            setStatus(uploadStatusDiv, `Error al confirmar selección: ${error.message}`, 'error');
            logMessage(`Error al confirmar columna: ${error.message}`, 'error');
        } finally {
            confirmColumnsButton.disabled = false;
            updateUIStep(currentStep);
        }
    });

    // Los event listeners para workingDirectoryInput se han eliminado ya que ahora
    // la carpeta se establece automáticamente al seleccionar el archivo Excel
});