# 🔧 PASO 3: NORMALIZACIÓN DE EXTENSIONES

## 📋 Descripción

El **Paso 3: Normalización de Extensiones** es una nueva etapa introducida en el flujo productivo para resolver el problema de archivos sin extensión descargados desde URLs que terminan con punto (`.`) o sin extensión.

### Problema Resuelto

Cuando se descargan imágenes de URLs como:
- `https://rimage.ripley.cl/home.ripley/Attachment/WOP/1/123456/full_image-123456.`
- `https://rimage.ripley.cl/home.ripley/Attachment/WOP/1/123456/full_image-123456`

Los archivos se guardan sin extensión válida, lo que causa que el **Paso 4 (Renombrado de Imágenes)** los ignore, ya que solo procesa archivos con extensiones reconocidas.

---

## 🔄 Nuevo Flujo de Pasos

### Estructura Actualizada

1. **Paso 1:** Descarga de Imágenes ✅
2. **Paso 2:** Renombrar Carpetas (SKU → EAN) ✅
3. **Paso 3:** **Normalización de Extensiones** 🆕
4. **Paso 4:** Renombrar Imágenes ✅ (antes Paso 3)

---

## ⚙️ Lógica de Normalización

El módulo `extension_normalizer.py` aplica las siguientes reglas:

### Archivos que SE Normalizan a `.webp`:

| Tipo Original | Ejemplo | Resultado |
|---------------|---------|-----------|
| Sin extensión | `full_image-123456` | `full_image-123456.webp` |
| Solo punto | `full_image-123456.` | `full_image-123456.webp` |
| Extensión `.jpg` | `image1-123456.jpg` | `image1-123456.webp` |
| Extensión `.jpeg` | `image2-123456.jpeg` | `image2-123456.webp` |

### Archivos que NO se Modifican:

| Extensión | Razón |
|-----------|-------|
| `.webp` | Ya tiene el formato deseado |
| `.png` | Formato válido, se mantiene |
| `.gif` | Formato válido, se mantiene |
| Otras extensiones válidas | Se mantienen sin cambios |

---

## 🔌 API Endpoints

### POST `/api/start_step3_normalize_extensions`

Ejecuta el proceso de normalización de extensiones.

#### Prerrequisitos:
- ✅ `step2_verified === true` (Paso 2 completado y verificado)
- ✅ `download_base_path` existe

#### Respuesta Exitosa:
```json
{
  "success": true,
  "message": "Paso 3 (Normalización) completado. 45 archivos normalizados, 12 sin cambios en 15/15 carpetas",
  "details": {
    "success": true,
    "total_folders": 15,
    "processed_folders": 15,
    "total_normalized": 45,
    "total_skipped": 12,
    "total_errors": 0,
    "folder_results": [
      {
        "folder": "7801234567890",
        "success": true,
        "normalized": 3,
        "skipped": 1,
        "errors": 0,
        "message": "Normalización completada: 3 archivos normalizados, 1 sin cambios"
      }
    ]
  }
}
```

#### Respuesta con Error:
```json
{
  "success": false,
  "message": "Error en Paso 3 (Normalización): [detalles del error]"
}
```

---

## 📊 Estado de la Aplicación

### Nuevos Campos en `app_state`:

```python
{
  "step3_completed": bool,      # True si normalización completada
  "step3_verified": bool,       # True si normalización verificada (auto-verificado)
  "step4_completed": bool,      # True si renombrado de imágenes completado (antes step3)
}
```

### Flujo de Estados:

```
step1_completed & step1_verified → Habilita Paso 2
step2_completed & step2_verified → Habilita Paso 3
step3_completed & step3_verified → Habilita Paso 4
step4_completed                  → Proceso Completo
```

---

## 📁 Estructura de Archivos

### Nuevo Módulo:
```
FlexStart/apps/flujo_productivo/backend/
└── core_logic/
    └── extension_normalizer.py  🆕 (Nuevo)
```

### Funciones Principales:

#### `normalize_extensions_in_folder(folder_path, dry_run=False)`
Normaliza extensiones de archivos en una carpeta específica.

**Parámetros:**
- `folder_path` (str): Ruta de la carpeta
- `dry_run` (bool): Si True, simula sin hacer cambios

**Retorna:**
```python
{
  "success": bool,
  "normalized_count": int,
  "skipped_count": int,
  "error_count": int,
  "details": list[dict],
  "message": str
}
```

#### `execute_normalization_process(base_folder_path, folder_list=None)`
Ejecuta normalización en múltiples carpetas.

**Parámetros:**
- `base_folder_path` (str): Ruta base donde están las carpetas
- `folder_list` (list[str], opcional): Lista de carpetas específicas (None = todas)

**Retorna:**
```python
{
  "success": bool,
  "total_folders": int,
  "processed_folders": int,
  "total_normalized": int,
  "total_skipped": int,
  "total_errors": int,
  "folder_results": list[dict],
  "message": str
}
```

---

## 🧪 Ejemplos de Uso

### Ejemplo 1: Normalización Exitosa

**Antes:**
```
/Proceso/MiExcel/7801234567890/
├── full_image-123456           (sin extensión)
├── full_image-123456.          (solo punto)
├── image1-123456.jpg           (jpg)
├── image2-123456.webp          (ya normalizado)
└── image3-123456.png           (otro formato)
```

**Después:**
```
/Proceso/MiExcel/7801234567890/
├── full_image-123456.webp      ✅ Agregada extensión
├── full_image-123456.webp      ✅ Reemplazado punto
├── image1-123456.webp          ✅ Convertido de jpg
├── image2-123456.webp          ✅ Sin cambios
└── image3-123456.png           ✅ Mantenido png
```

### Ejemplo 2: Archivo con Conflicto

Si un archivo `imagen` y `imagen.webp` coexisten:
- ❌ No se renombra `imagen`
- ⚠️ Se registra error: "El archivo de destino ya existe"
- ℹ️ Se mantiene `imagen.webp` original

---

## 🔍 Logging y Debugging

### Logs Generados:

```python
# Inicio de proceso
INFO: "Paso 3: Iniciando normalización de extensiones..."
INFO: "Iniciando normalización de extensiones en 15 carpetas"

# Por carpeta
INFO: "Carpeta '7801234567890': Normalización completada: 3 archivos normalizados, 1 sin cambios"

# Por archivo normalizado
INFO: "Normalizado: 'full_image-123456' → 'full_image-123456.webp'"

# Errores
WARNING: "No se puede renombrar 'imagen' a 'imagen.webp': destino ya existe"
ERROR: "Error al renombrar 'archivo.': [OSError details]"

# Finalización
INFO: "Paso 3 (Normalización) completado. 45 archivos normalizados..."
```

---

## ⚠️ Consideraciones Importantes

### 1. **Conversión vs Renombrado**
- ⚠️ Este módulo **NO convierte formatos** de imagen
- ✅ Solo **renombra extensiones** para uniformidad
- ℹ️ JPG renombrados a WEBP siguen siendo JPG internamente

### 2. **Archivos Especiales**
- ✅ Archivos ocultos (`.filename`) se ignoran automáticamente
- ✅ Archivos sin punto se consideran sin extensión
- ✅ Archivos con múltiples puntos (`imagen.min.js`) se procesan correctamente

### 3. **Thread Safety**
- ✅ El proceso es thread-safe a nivel de `app_state`
- ⚠️ No ejecutar normalización simultánea en la misma carpeta

### 4. **Rollback**
- ❌ No hay rollback automático
- 💡 Recomendación: Hacer backup antes de ejecutar en producción

---

## 🔄 Migración desde Versión Anterior

Si estabas usando la versión anterior (sin Paso 3):

### Cambios en Frontend:

```javascript
// ANTES
const paso3Endpoint = '/api/start_step3_rename_images';

// AHORA
const paso3Endpoint = '/api/start_step3_normalize_extensions';
const paso4Endpoint = '/api/start_step4_rename_images';
```

### Cambios en Estado:

```javascript
// ANTES
if (state.step2_verified) {
  // Habilitar Paso 3 (Renombrar Imágenes)
}

// AHORA
if (state.step2_verified) {
  // Habilitar Paso 3 (Normalizar Extensiones)
}
if (state.step3_verified) {
  // Habilitar Paso 4 (Renombrar Imágenes)
}
```

---

## 📝 Testing

### Test Manual:

1. Crear archivos de prueba:
```bash
cd /tmp/test_normalization
mkdir test_folder
cd test_folder

# Crear archivos de prueba
touch "imagen"                    # Sin extensión
touch "imagen."                   # Solo punto
touch "foto.jpg"                  # JPG
touch "logo.webp"                 # Ya normalizado
touch "icon.png"                  # Otro formato
```

2. Ejecutar normalización desde Python:
```python
from core_logic.extension_normalizer import normalize_extensions_in_folder

result = normalize_extensions_in_folder("/tmp/test_normalization/test_folder")
print(result)
```

3. Verificar resultados:
```bash
ls -la /tmp/test_normalization/test_folder
# Debería mostrar archivos normalizados
```

---

## 🐛 Troubleshooting

### Error: "Paso 2 no verificado"
**Causa:** Se intentó ejecutar Paso 3 sin completar Paso 2
**Solución:** Completar y verificar Paso 2 primero

### Error: "El archivo de destino ya existe"
**Causa:** Ya existe un archivo con la extensión normalizada
**Solución:** Revisar archivos duplicados manualmente

### Error: "La carpeta no existe"
**Causa:** Alguna carpeta del mapeo no se encuentra en el directorio
**Solución:** Verificar que todas las carpetas EAN_HIJO existan

---

## 📈 Métricas y Performance

### Performance Esperado:
- **1 carpeta con 10 archivos:** ~50ms
- **100 carpetas con 500 archivos:** ~2-5 segundos
- **1000+ archivos:** ~20-30 segundos

### Optimizaciones:
- ✅ Sin lectura de contenido de archivos (solo metadatos)
- ✅ Operación OS-level (rename) muy eficiente
- ✅ Sin bloqueo del thread principal (async endpoint)

---

## 🔐 Seguridad

### Validaciones Implementadas:
- ✅ Path traversal prevention (no permite `..`)
- ✅ Solo archivos en carpetas especificadas
- ✅ No elimina archivos, solo renombra
- ✅ Logging de todas las operaciones

---

## 📞 Soporte

Para problemas o preguntas:
1. Revisar logs en `app_state["last_error_message"]`
2. Verificar estado de pasos en `/api/status`
3. Revisar documentación de troubleshooting arriba

---

**Última Actualización:** 2025-10-01  
**Versión:** 1.0.0  
**Autor:** Sistema de Flujo Productivo

