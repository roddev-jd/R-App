# backend/core_logic/local_copier.py
"""
Módulo para copiar carpetas de imágenes desde ubicación local.

Este módulo busca carpetas en una ubicación local del sistema de archivos
y las copia a la ubicación de destino. Es una alternativa al downloader.py
para cuando las imágenes ya están disponibles localmente.
"""

import os
import shutil
import logging
from pathlib import Path
from typing import Dict, List, Optional, Callable, Any

logger = logging.getLogger(__name__)


class LocalCopyException(Exception):
    """Excepción base para errores de copiado local."""
    pass


class LocalCopyCancelledException(Exception):
    """Excepción lanzada cuando el usuario cancela el copiado."""
    pass


def _check_cancellation(app_state):
    """Verifica si se solicitó cancelación y lanza excepción si es necesario."""
    if app_state and app_state.get("should_cancel_download", False):
        logger.info("Copiado cancelado por el usuario. Interrumpiendo proceso.")
        raise LocalCopyCancelledException("Copiado cancelado por el usuario")


def _find_folder_in_tree(
    base_path: str,
    folder_name: str,
    max_depth: int = 10
) -> Optional[str]:
    """
    Busca una carpeta en el árbol de directorios de forma recursiva.
    
    Args:
        base_path: Ruta base donde buscar
        folder_name: Nombre de la carpeta a buscar
        max_depth: Profundidad máxima de búsqueda (previene búsquedas infinitas)
        
    Returns:
        Ruta completa de la carpeta encontrada, o None si no se encuentra
    """
    base_path = Path(base_path)
    
    if not base_path.exists() or not base_path.is_dir():
        logger.warning(f"La ruta base no existe o no es un directorio: {base_path}")
        return None
    
    # Buscar en la raíz primero
    direct_path = base_path / folder_name
    if direct_path.exists() and direct_path.is_dir():
        logger.info(f"Carpeta encontrada directamente: {direct_path}")
        return str(direct_path)
    
    # Buscar recursivamente
    try:
        for root, dirs, _ in os.walk(base_path):
            # Calcular profundidad actual
            current_depth = len(Path(root).relative_to(base_path).parts)
            if current_depth >= max_depth:
                dirs[:] = []  # No seguir bajando en este branch
                continue
            
            if folder_name in dirs:
                found_path = Path(root) / folder_name
                logger.info(f"Carpeta encontrada en: {found_path}")
                return str(found_path)
    except Exception as e:
        logger.error(f"Error durante búsqueda recursiva de '{folder_name}': {e}")
    
    return None


def _copy_folder_contents(
    source_folder: str,
    destination_folder: str,
    preserve_name: bool = True
) -> Dict[str, Any]:
    """
    Copia el contenido de una carpeta a otra ubicación.
    
    Args:
        source_folder: Carpeta origen
        destination_folder: Carpeta destino
        preserve_name: Si True, copia dentro de una subcarpeta con el mismo nombre
        
    Returns:
        Diccionario con resultados de la copia:
        {
            "success": bool,
            "files_copied": int,
            "source": str,
            "destination": str,
            "error": str (opcional)
        }
    """
    source_path = Path(source_folder)
    dest_path = Path(destination_folder)
    
    if not source_path.exists():
        return {
            "success": False,
            "files_copied": 0,
            "source": str(source_path),
            "destination": str(dest_path),
            "error": "Carpeta origen no existe"
        }
    
    try:
        # Crear carpeta destino si no existe
        dest_path.mkdir(parents=True, exist_ok=True)
        
        files_copied = 0
        
        # Copiar todos los archivos de la carpeta origen
        for item in source_path.iterdir():
            if item.is_file():
                dest_file = dest_path / item.name
                shutil.copy2(item, dest_file)
                files_copied += 1
                logger.debug(f"Archivo copiado: {item.name}")
        
        logger.info(f"Copiados {files_copied} archivos desde '{source_path}' a '{dest_path}'")
        
        return {
            "success": True,
            "files_copied": files_copied,
            "source": str(source_path),
            "destination": str(dest_path)
        }
        
    except Exception as e:
        error_msg = f"Error al copiar carpeta: {e}"
        logger.error(error_msg, exc_info=True)
        return {
            "success": False,
            "files_copied": 0,
            "source": str(source_path),
            "destination": str(dest_path),
            "error": error_msg
        }


def execute_local_copy_process(
    sku_list: List[str],
    source_base_path: str,
    destination_base_path: str,
    app_state=None,
    add_processing_event: Optional[Callable] = None
) -> Dict[str, Any]:
    """
    Ejecuta el proceso completo de copiado de carpetas locales.
    
    Args:
        sku_list: Lista de nombres de carpetas a buscar (SKUs)
        source_base_path: Ruta base donde buscar las carpetas
        destination_base_path: Ruta base donde copiar las carpetas
        app_state: Estado de la aplicación (para cancelación)
        add_processing_event: Función para registrar eventos
        
    Returns:
        Diccionario con resultados:
        {
            "success": bool,
            "message": str,
            "total_items_processed": int,
            "total_folders_found": int,
            "total_folders_copied": int,
            "total_files_copied": int,
            "missing_folders": list[str],
            "details": list[dict]
        }
    """
    if not sku_list:
        msg = "No se proporcionó lista de SKUs para copiar."
        logger.warning(msg)
        return {
            "success": False,
            "message": msg,
            "total_items_processed": 0,
            "total_folders_found": 0,
            "total_folders_copied": 0,
            "total_files_copied": 0,
            "missing_folders": [],
            "details": []
        }
    
    if not os.path.exists(source_base_path):
        msg = f"La ubicación de origen no existe: {source_base_path}"
        logger.error(msg)
        return {
            "success": False,
            "message": msg,
            "total_items_processed": 0,
            "total_folders_found": 0,
            "total_folders_copied": 0,
            "total_files_copied": 0,
            "missing_folders": list(sku_list),
            "details": []
        }
    
    # Crear carpeta destino si no existe
    try:
        os.makedirs(destination_base_path, exist_ok=True)
    except OSError as e:
        msg = f"No se pudo crear la carpeta de destino {destination_base_path}: {e}"
        logger.error(msg)
        return {
            "success": False,
            "message": msg,
            "total_items_processed": 0,
            "total_folders_found": 0,
            "total_folders_copied": 0,
            "total_files_copied": 0,
            "missing_folders": list(sku_list),
            "details": []
        }
    
    # Inicializar contadores y resultados
    total_items = len(sku_list)
    folders_found = 0
    folders_copied = 0
    total_files_copied = 0
    missing_folders = []
    copy_details = []
    
    logger.info(f"Iniciando copiado local para {total_items} carpetas")
    logger.info(f"Origen: {source_base_path}")
    logger.info(f"Destino: {destination_base_path}")
    
    if add_processing_event:
        add_processing_event("info", f"Iniciando copiado local de {total_items} carpetas...")
    
    try:
        for index, sku in enumerate(sku_list):
            # Verificar cancelación
            _check_cancellation(app_state)
            
            logger.info(f"--- Procesando {index + 1}/{total_items}: {sku} ---")
            
            # Actualizar progreso
            if app_state:
                app_state["processed_skus"] = index + 1
            
            if add_processing_event:
                add_processing_event("info", f"Buscando carpeta: {sku}", sku=sku)
            
            # Buscar carpeta en el árbol de directorios
            found_path = _find_folder_in_tree(source_base_path, sku)
            
            if found_path:
                folders_found += 1
                logger.info(f"Carpeta encontrada: {found_path}")
                
                if add_processing_event:
                    add_processing_event("success", f"Carpeta encontrada: {sku}", sku=sku)
                
                # Copiar carpeta a destino
                dest_folder = os.path.join(destination_base_path, sku)
                copy_result = _copy_folder_contents(found_path, dest_folder)
                
                if copy_result["success"]:
                    folders_copied += 1
                    files_copied = copy_result["files_copied"]
                    total_files_copied += files_copied
                    
                    if app_state:
                        app_state["successful_downloads"] += files_copied
                    
                    if add_processing_event:
                        add_processing_event(
                            "success",
                            f"Carpeta copiada: {sku} ({files_copied} archivos)",
                            sku=sku
                        )
                    
                    copy_details.append({
                        "sku": sku,
                        "found": True,
                        "copied": True,
                        "files_copied": files_copied,
                        "source": found_path,
                        "destination": dest_folder
                    })
                else:
                    error_msg = copy_result.get("error", "Error desconocido")
                    logger.error(f"Error al copiar {sku}: {error_msg}")
                    
                    if app_state:
                        app_state["failed_downloads"] += 1
                    
                    if add_processing_event:
                        add_processing_event("error", f"Error al copiar {sku}: {error_msg}", sku=sku)
                    
                    copy_details.append({
                        "sku": sku,
                        "found": True,
                        "copied": False,
                        "files_copied": 0,
                        "error": error_msg
                    })
            else:
                # Carpeta no encontrada
                missing_folders.append(sku)
                logger.warning(f"Carpeta no encontrada: {sku}")
                
                if app_state:
                    app_state["failed_downloads"] += 1
                
                if add_processing_event:
                    add_processing_event("warning", f"Carpeta no encontrada: {sku}", sku=sku)
                
                copy_details.append({
                    "sku": sku,
                    "found": False,
                    "copied": False,
                    "files_copied": 0
                })
    
    except LocalCopyCancelledException:
        logger.info(f"Copiado cancelado. Se procesaron {index + 1} de {total_items} carpetas.")
        if add_processing_event:
            add_processing_event(
                "warning",
                f"Copiado cancelado: {folders_copied} carpetas copiadas antes de la cancelación"
            )
        raise
    
    # Construir mensaje final
    if missing_folders:
        msg = (f"Copiado completado con advertencias: {folders_copied}/{total_items} carpetas copiadas "
               f"({total_files_copied} archivos). {len(missing_folders)} carpetas no encontradas.")
    else:
        msg = (f"Copiado completado exitosamente: {folders_copied}/{total_items} carpetas copiadas "
               f"({total_files_copied} archivos).")
    
    logger.info(msg)
    
    if add_processing_event:
        add_processing_event("info", msg)
    
    return {
        "success": True,
        "message": msg,
        "total_items_processed": total_items,
        "total_folders_found": folders_found,
        "total_folders_copied": folders_copied,
        "total_files_copied": total_files_copied,
        "missing_folders": missing_folders,
        "details": copy_details
    }


# Ejemplo de uso para testing
if __name__ == "__main__":
    import sys
    
    # Configurar logging para testing
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Parámetros de prueba
    test_skus = ["2000379090900", "2000377528168", "SKU_NO_EXISTE"]
    test_source = "/Users/rjarad/Desktop/TEMP/imagenes_origen"  # Cambiar por ruta real
    test_dest = "/Users/rjarad/Desktop/TEMP/imagenes_destino"
    
    print("=" * 80)
    print("PRUEBA DEL MÓDULO LOCAL COPIER")
    print("=" * 80)
    print(f"SKUs a buscar: {test_skus}")
    print(f"Origen: {test_source}")
    print(f"Destino: {test_dest}")
    print("=" * 80)
    
    # Ejecutar copiado
    results = execute_local_copy_process(
        sku_list=test_skus,
        source_base_path=test_source,
        destination_base_path=test_dest
    )
    
    # Mostrar resultados
    print("\nRESULTADOS:")
    print(f"Éxito: {results['success']}")
    print(f"Mensaje: {results['message']}")
    print(f"Carpetas encontradas: {results['total_folders_found']}/{results['total_items_processed']}")
    print(f"Carpetas copiadas: {results['total_folders_copied']}")
    print(f"Archivos copiados: {results['total_files_copied']}")
    print(f"Carpetas faltantes: {results['missing_folders']}")
    print("\nDetalles por carpeta:")
    for detail in results['details']:
        print(f"  - {detail['sku']}: Encontrada={detail['found']}, Copiada={detail['copied']}, "
              f"Archivos={detail['files_copied']}")


