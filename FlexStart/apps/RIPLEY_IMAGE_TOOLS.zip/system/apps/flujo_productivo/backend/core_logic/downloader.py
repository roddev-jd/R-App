# backend/core_logic/downloader.py

import os
import pandas as pd
import requests
import urllib3
import time
import logging
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests.exceptions import ConnectTimeout, ReadTimeout, Timeout, RequestException

# Importar configuración centralizada
from ..config import (
    USER_AGENT,
    DEFAULT_REQUEST_TIMEOUT,
    RETRY_TOTAL,
    RETRY_BACKOFF_FACTOR,
    RETRY_STATUS_FORCELIST,
    RETRY_CONNECT,
    RETRY_READ,
    DELAY_BETWEEN_SKUS,
    DELAY_BETWEEN_IMAGES,
    DELAY_ON_429_ERROR,
    RIMAGE_BASE_URL_PATTERN,
    STORE_BASE_URL_PATTERN,
    IMAGE_TYPES_PRIMARY,
    IMAGE_EXTENSIONS
)

# Importar utilidades de limpieza de datos
from ..utils.data_cleaning import clean_excel_value, clean_excel_column

# --- Configuración del Logger ---
logger = logging.getLogger(__name__)

# NUEVO: Excepción personalizada para cancelación
class DownloadCancelledException(Exception):
    """Excepción lanzada cuando el usuario cancela la descarga."""
    pass

def _check_cancellation(APP_STATE):
    """Verifica si se solicitó cancelación y lanza excepción si es necesario."""
    if APP_STATE and APP_STATE.get("should_cancel_download", False):
        logger.info("Descarga cancelada por el usuario. Interrumpiendo proceso.")
        raise DownloadCancelledException("Descarga cancelada por el usuario")

def _interruptible_sleep(seconds, APP_STATE):
    """Sleep que puede ser interrumpido por cancelación.
    Divide el sleep en chunks de 0.1 segundos para poder responder rápidamente a cancelación."""
    chunks = int(seconds / 0.1)
    remainder = seconds % 0.1

    for _ in range(chunks):
        _check_cancellation(APP_STATE)
        time.sleep(0.1)

    if remainder > 0:
        _check_cancellation(APP_STATE)
        time.sleep(remainder)

# Deshabilitar advertencias por conexiones inseguras (SSL)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- Funciones Auxiliares ---

def _initialize_session():
    """Configura y retorna una sesión de requests con reintentos."""
    session = requests.Session()
    retry_strategy = Retry(
        total=RETRY_TOTAL,
        backoff_factor=RETRY_BACKOFF_FACTOR,
        status_forcelist=RETRY_STATUS_FORCELIST,
        allowed_methods=["GET"],
        connect=RETRY_CONNECT,
        read=RETRY_READ
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update({"User-Agent": USER_AGENT})
    return session

def _read_and_validate_excel(excel_path, sku_column_name, coddepto_column_name=None):
    """
    Lee el archivo Excel y valida las columnas requeridas.
    Usa las funciones centralizadas de limpieza de datos.
    """
    try:
        df = pd.read_excel(excel_path, dtype=str) # Leer todas las columnas como string inicialmente
        logger.info(f"Archivo Excel '{excel_path}' leído. Columnas encontradas: {list(df.columns)}")
    except Exception as e:
        logger.error(f"Error crítico: No se pudo leer el archivo Excel en {excel_path}: {e}")
        raise ValueError(f"No se pudo leer el archivo Excel: {e}")

    # Validar existencia de sku_column_name
    if sku_column_name not in df.columns:
        error_msg = f"Error: Columna SKU requerida '{sku_column_name}' no encontrada en el Excel."
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Limpiar la columna SKU_CL usando función centralizada
    df[sku_column_name] = clean_excel_column(df[sku_column_name])
    df.dropna(subset=[sku_column_name], inplace=True) # Eliminar filas donde SKU_CL es NaN o vacío después de limpiar
    if df.empty:
        error_msg = f"No hay datos válidos en la columna SKU '{sku_column_name}' después de la limpieza."
        logger.warning(error_msg) # Puede no ser un error fatal si el archivo está intencionalmente vacío.
        # raise ValueError(error_msg) # Opcional: hacerlo un error fatal

    # Validar y limpiar coddepto_column_name si se proporcionó y existe
    if coddepto_column_name:
        if coddepto_column_name not in df.columns:
            logger.warning(f"Advertencia: Columna CODDEPTO opcional '{coddepto_column_name}' no encontrada. "
                           "La descarga secundaria podría no funcionar.")
            # No es un error fatal, la descarga primaria aún puede funcionar.
        else:
            df[coddepto_column_name] = clean_excel_column(df[coddepto_column_name])
            # No eliminamos filas si CODDEPTO es NaN, ya que es opcional para el ítem.

    return df

def _prepare_items_for_processing(df, sku_column_name, coddepto_column_name=None):
    """Prepara la lista de ítems a procesar (SKU_CL únicos) desde el DataFrame."""
    items_to_process = []
    logger.info(f"Preparando ítems para procesar desde la columna SKU: '{sku_column_name}'.")
    
    # Obtener SKU_CL únicos para procesar
    unique_sku_cls = df[sku_column_name].unique() # Ya están limpios y sin NaNs por _read_and_validate_excel

    for sku_val in unique_sku_cls:
        item_data = {'sku_cl': sku_val, 'log_name': sku_val}
        
        # Si se usa CODDEPTO, encontrar el primer CODDEPTO no nulo para este SKU_CL
        # Esto es una simplificación; si un SKU_CL puede tener múltiples CODDEPTOS válidos
        # y se necesita procesar cada combinación, la lógica sería más compleja.
        if coddepto_column_name and coddepto_column_name in df.columns:
            # Tomar la primera fila del DataFrame original que coincide con este SKU_CL único
            first_matching_row = df[df[sku_column_name] == sku_val].iloc[0]
            coddepto_val = first_matching_row.get(coddepto_column_name) # Ya limpio
            item_data['coddepto'] = coddepto_val # Puede ser None si el valor era NaN o vacío
        else:
            item_data['coddepto'] = None
            
        items_to_process.append(item_data)
        
    logger.info(f"Se procesarán {len(items_to_process)} SKU_CL únicos.")
    return items_to_process

def _attempt_single_download(url, save_path, session, item_log_prefix, APP_STATE=None):
    """Intenta descargar una única URL y la guarda."""
    
    # NUEVO: Verificar cancelación antes de cada descarga HTTP
    _check_cancellation(APP_STATE)
    
    try:
        # logger.debug(f"Intentando ({item_log_prefix}): {url}") # Descomentar para logs muy detallados
        resp = session.get(url, timeout=DEFAULT_REQUEST_TIMEOUT, verify=False)
        if resp.status_code == 200:
            # Asegurar que el directorio de la subcarpeta (SKU_CL) exista
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            with open(save_path, 'wb') as f:
                f.write(resp.content)
            logger.info(f"Descargado ({item_log_prefix}): '{os.path.basename(save_path)}' desde {url}")
            return True
        elif resp.status_code == 404:
            logger.debug(f"No encontrado (404) ({item_log_prefix}): {url}")
        elif resp.status_code == 429:
            logger.warning(f"Rate limit excedido (429) ({item_log_prefix}) para {url}. Esperando {DELAY_ON_429_ERROR} segundos...")
            _interruptible_sleep(DELAY_ON_429_ERROR, APP_STATE)
        else:
            logger.warning(f"Respuesta no exitosa ({item_log_prefix}) para {url} (Status: {resp.status_code})")
    except ConnectTimeout:
        logger.warning(f"Timeout de Conexión ({item_log_prefix}) para: {url}")
    except ReadTimeout:
        logger.warning(f"Timeout de Lectura ({item_log_prefix}) para: {url}")
    except Timeout: # Timeout genérico
        logger.warning(f"Timeout General ({item_log_prefix}) para: {url}")
    except RequestException as e_req:
        logger.warning(f"Error de Request ({item_log_prefix}) en {url}: {e_req}")
    except Exception as e: # Otros errores inesperados (ej. OSError al guardar)
        logger.error(f"Error Inesperado ({item_log_prefix}) en {url} o al guardar {save_path}: {e} (Tipo: {type(e).__name__})")
    return False

def _download_images_for_item(item_data, session, base_destination_folder, item_log_prefix, APP_STATE=None, _add_processing_event=None):
    """Maneja la lógica de descarga para un solo ítem (SKU_CL)."""
    sku_cl = item_data['sku_cl']
    coddepto = item_data.get('coddepto') # Puede ser None
    
    # Las subcarpetas se nombran directamente con el valor de SKU_CL
    subfolder_path = os.path.join(base_destination_folder, str(sku_cl))
    # La creación de la subcarpeta se maneja en _attempt_single_download o aquí si es preferible
    # os.makedirs(subfolder_path, exist_ok=True) # Se puede hacer aquí también

    images_downloaded_count = 0
    primary_image_found_for_this_item = False # Renombrada para claridad

    # NUEVO: Verificar cancelación antes de procesar el item
    _check_cancellation(APP_STATE)

    # 1. Intento de Descarga Primario (rimage.ripley.cl)
    logger.info(f"Procesando descarga primaria para {item_log_prefix}...")
    for tipo in IMAGE_TYPES_PRIMARY:
        # NUEVO: Verificar cancelación en cada iteración de tipo
        _check_cancellation(APP_STATE)
            
        for ext in IMAGE_EXTENSIONS:
            # Construir URL y filename correctamente para casos con y sin extensión
            if ext == "":
                # Caso: sin punto ni extensión
                url = f"https://rimage.ripley.cl/home.ripley/Attachment/WOP/1/{sku_cl}/{tipo}-{sku_cl}"
                filename = f"{tipo}-{sku_cl}"
                display_ext = "sin_ext"
            elif ext == ".":
                # Caso: solo punto sin extensión
                url = f"https://rimage.ripley.cl/home.ripley/Attachment/WOP/1/{sku_cl}/{tipo}-{sku_cl}."
                filename = f"{tipo}-{sku_cl}."
                display_ext = "punto"
            else:
                # Caso: con extensión normal (.webp, .jpg)
                url = RIMAGE_BASE_URL_PATTERN.format(sku_cl=sku_cl, tipo=tipo, ext=ext)
                filename = f"{tipo}-{sku_cl}.{ext}"
                display_ext = ext

            save_path = os.path.join(subfolder_path, filename)

            # NUEVO: Actualizar estado de procesamiento con URL actual
            if _add_processing_event:
                _add_processing_event("info", f"Descargando {tipo}.{display_ext}", sku=sku_cl, image_type=f"{tipo}.{display_ext}", url=url)
            
            if _attempt_single_download(url, save_path, session, f"{item_log_prefix}, {tipo}.{display_ext}", APP_STATE):
                images_downloaded_count += 1
                primary_image_found_for_this_item = True
                # NUEVO: Actualizar contador de éxitos
                if APP_STATE:
                    APP_STATE["successful_downloads"] += 1
                # No rompemos el bucle aquí para intentar todas las combinaciones tipo/extensión.
            else:
                # NUEVO: Actualizar contador de fallos
                if APP_STATE:
                    APP_STATE["failed_downloads"] += 1

            # Delay entre descargas de imágenes para evitar rate limiting
            _interruptible_sleep(DELAY_BETWEEN_IMAGES, APP_STATE)
    
    # 2. Intento de Descarga Secundario (home.ripley.cl/store)
    #    Solo si se proporcionó un coddepto válido y no se encontraron imágenes primarias.
    if coddepto and not primary_image_found_for_this_item:
        # NUEVO: Verificar cancelación antes de descarga secundaria
        _check_cancellation(APP_STATE)
            
        logger.info(f"Descarga primaria no encontró imágenes para {item_log_prefix}. "
                    f"Intentando descarga secundaria con CODDEPTO: {coddepto}...")
        base_store_url = STORE_BASE_URL_PATTERN.format(coddepto=coddepto, sku_cl=sku_cl)

        # Intento con guion bajo (_2.jpg)
        url_underscore = f"{base_store_url}{sku_cl}_2.jpg"
        filename_underscore = f"{sku_cl}_2.jpg" # Nombre de archivo consistente
        save_path_underscore = os.path.join(subfolder_path, filename_underscore)
        
        # NUEVO: Actualizar estado con URL actual
        if _add_processing_event:
            _add_processing_event("info", f"Descargando tienda _2.jpg", sku=sku_cl, image_type="tienda_2.jpg", url=url_underscore)
            
        if _attempt_single_download(url_underscore, save_path_underscore, session, f"{item_log_prefix}, tienda_u_2.jpg", APP_STATE):
            images_downloaded_count += 1
            primary_image_found_for_this_item = True # Marcar como encontrado si esta variante funciona
            if APP_STATE:
                APP_STATE["successful_downloads"] += 1
        else:
            if APP_STATE:
                APP_STATE["failed_downloads"] += 1

        _interruptible_sleep(DELAY_BETWEEN_IMAGES, APP_STATE)

        # Intento con guiones (-i.jpg), solo si aún no se encontró nada en la tienda (_2.jpg)
        if not primary_image_found_for_this_item: 
            for i in range(1, 19): # El script original iba hasta 18 (range 1,19)
                # NUEVO: Verificar cancelación en cada iteración
                _check_cancellation(APP_STATE)
                    
                url_hyphen = f"{base_store_url}{sku_cl}-{i}.jpg"
                filename_hyphen = f"{sku_cl}-{i}.jpg" # Nombre de archivo consistente
                save_path_hyphen = os.path.join(subfolder_path, filename_hyphen)
                
                # NUEVO: Actualizar estado con URL actual
                if _add_processing_event:
                    _add_processing_event("info", f"Descargando tienda -{i}.jpg", sku=sku_cl, image_type=f"tienda_{i}.jpg", url=url_hyphen)
                    
                if _attempt_single_download(url_hyphen, save_path_hyphen, session, f"{item_log_prefix}, tienda_h{i}.jpg", APP_STATE):
                    images_downloaded_count += 1
                    if APP_STATE:
                        APP_STATE["successful_downloads"] += 1
                    # No actualizamos primary_image_found_for_this_item aquí para intentar descargar todas las variantes -i.jpg.
                else:
                    if APP_STATE:
                        APP_STATE["failed_downloads"] += 1

                _interruptible_sleep(DELAY_BETWEEN_IMAGES, APP_STATE)
    
    if images_downloaded_count == 0:
        logger.warning(f"No se descargaron imágenes para {item_log_prefix} (SKU_CL: {sku_cl}).")
    else:
        logger.info(f"Total imágenes descargadas para {item_log_prefix}: {images_downloaded_count}.")
        
    return images_downloaded_count

# --- Función Principal para ser Llamada por la App Flask ---

def execute_download_process(excel_file_path: str, sku_column_name: str, 
                             destination_folder: str, coddepto_column_name: str = None,
                             APP_STATE=None, _add_processing_event=None):
    """
    Orquesta el proceso completo de descarga de imágenes.
    """
    if not excel_file_path or not os.path.exists(excel_file_path):
        msg = f"Ruta del archivo Excel no proporcionada o el archivo '{excel_file_path}' no existe."
        logger.error(msg)
        return {"success": False, "message": msg, "total_items_processed": 0, "total_images_downloaded": 0}
    if not destination_folder:
        msg = "Carpeta de destino no proporcionada."
        logger.error(msg)
        return {"success": False, "message": msg, "total_items_processed": 0, "total_images_downloaded": 0}

    try:
        # La carpeta base de sesión (destination_folder) ya debería estar creada por app.py
        # os.makedirs(destination_folder, exist_ok=True) # No es estrictamente necesario si app.py lo hace
        pass
    except OSError as e:
        msg = f"No se pudo asegurar la creación de la carpeta de destino {destination_folder}: {e}"
        logger.error(msg)
        return {"success": False, "message": msg, "total_items_processed": 0, "total_images_downloaded": 0}

    try:
        df = _read_and_validate_excel(excel_file_path, sku_column_name, coddepto_column_name)
    except ValueError as e: # Error ya logueado en la función helper
        return {"success": False, "message": str(e), "total_items_processed": 0, "total_images_downloaded": 0}

    items_to_process = _prepare_items_for_processing(df, sku_column_name, coddepto_column_name)
    if not items_to_process:
        msg = "No hay ítems SKU_CL válidos para procesar después de leer y limpiar el Excel."
        logger.warning(msg)
        # Esto no es necesariamente un fallo de la función, podría ser un Excel vacío/inválido.
        return {"success": True, "message": msg, "total_items_processed": 0, "total_images_downloaded": 0}
        
    total_items_to_process = len(items_to_process)
    logger.info(f"Iniciando descarga para {total_items_to_process} SKU_CL únicos.")

    # NUEVO: Usar las funciones de eventos pasadas como parámetros
    if _add_processing_event:
        _add_processing_event("info", f"Iniciando descarga de imágenes para {total_items_to_process} productos...")
        logger.info("Iniciando proceso con monitoreo de eventos")

    http_session = _initialize_session()
    total_images_downloaded_overall = 0
    items_processed_count = 0 # Ítems (SKU_CL únicos) para los que se intentó la descarga

    try:
        for index, item_data in enumerate(items_to_process):
            # NUEVO: Verificar cancelación antes de procesar cada SKU
            _check_cancellation(APP_STATE)
                
            item_log_name = item_data.get('log_name', item_data.get('sku_cl', 'SKU_DESCONOCIDO'))
            item_log_prefix = f"Ítem {index + 1}/{total_items_to_process} (SKU_CL: {item_log_name})"
            
            logger.info(f"--- {item_log_prefix} ---")
            
            # NUEVO: Actualizar progreso y registrar evento de inicio de procesamiento de SKU
            if APP_STATE:
                APP_STATE["processed_skus"] = index
            if _add_processing_event:
                _add_processing_event("info", f"Procesando SKU: {item_log_name}", sku=item_log_name)
            
            try:
                # La carpeta de destino para este ítem es destination_folder (la base de sesión)
                # _download_images_for_item creará la subcarpeta SKU_CL dentro de destination_folder
                images_for_this_item = _download_images_for_item(item_data, http_session, destination_folder, item_log_prefix, APP_STATE, _add_processing_event)
                total_images_downloaded_overall += images_for_this_item
                
                # NUEVO: Registrar resultado del procesamiento
                if _add_processing_event:
                    if images_for_this_item > 0:
                        _add_processing_event("success", f"SKU {item_log_name}: {images_for_this_item} imágenes descargadas", sku=item_log_name)
                    else:
                        _add_processing_event("warning", f"SKU {item_log_name}: No se encontraron imágenes", sku=item_log_name)
                    
            except Exception as e_item_processing:
                # Capturar cualquier error inesperado durante el procesamiento de un ítem
                # para que el bucle pueda continuar con los siguientes ítems.
                logger.error(f"Error crítico procesando el {item_log_prefix}: {e_item_processing}", exc_info=True)
                
                # NUEVO: Registrar error
                if _add_processing_event:
                    _add_processing_event("error", f"Error procesando SKU {item_log_name}: {str(e_item_processing)}", sku=item_log_name)
            
            items_processed_count += 1
            
            # Actualizar progreso final para este SKU
            if APP_STATE:
                APP_STATE["processed_skus"] = index + 1
            
            # DELAY ENTRE SKUS para evitar rate limiting
            if index < total_items_to_process - 1:  # No hacer delay después del último item
                # NUEVO: Verificar cancelación durante el delay
                _check_cancellation(APP_STATE)

                logger.info(f"Esperando {DELAY_BETWEEN_SKUS} segundos antes del siguiente SKU...")
                # MEJORADO: Hacer el sleep interrompible dividiendo en chunks pequeños
                _interruptible_sleep(DELAY_BETWEEN_SKUS, APP_STATE)
            
    except DownloadCancelledException:
        # Re-lanzar la excepción para que sea manejada por el nivel superior
        logger.info(f"Descarga cancelada. Se procesaron {items_processed_count} de {total_items_to_process} SKUs.")
        if _add_processing_event:
            _add_processing_event("warning", f"Descarga cancelada: {total_images_downloaded_overall} imágenes descargadas de {items_processed_count} productos antes de la cancelación")
        raise

    # NUEVO: Registrar resumen final
    if _add_processing_event:
        if APP_STATE and APP_STATE.get("should_cancel_download", False):
            _add_processing_event("warning", f"Descarga cancelada: {total_images_downloaded_overall} imágenes descargadas de {items_processed_count} productos antes de la cancelación")
        else:
            _add_processing_event("info", f"Descarga completada: {total_images_downloaded_overall} imágenes descargadas de {items_processed_count} productos")

    final_message = (f"Proceso de descarga completado. "
                     f"Ítems procesados: {items_processed_count}/{total_items_to_process}, "
                     f"Imágenes descargadas: {total_images_downloaded_overall}.")
    logger.info(final_message)

    return {
        "success": True,
        "message": final_message,
        "total_items_processed": items_processed_count,
        "total_images_downloaded": total_images_downloaded_overall
    }

# --- Bloque de prueba para ejecutar el módulo directamente (opcional) ---
if __name__ == "__main__":
    print("Ejecutando prueba del módulo downloader...")
    
    # Crear un DataFrame de prueba y guardarlo como Excel
    # Asegúrate de que los SKU_CL sean strings si pandas los puede interpretar como números.
    test_data = {
        'SKU_CL': ['2000379090900', '2000377528168', 'MPM0000000001', '2000379090900.0', 'INVALID_SKU_TEST', None, ' ', '2000404905015'],
        'CODDEPTO': ['2010', '2030', None, '2010.0', '2040', '2050', '2060', ''], # CODDEPTO es opcional
        'OtroDato': ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
    }
    test_df = pd.DataFrame(test_data)
    test_excel_filename = "test_skus_downloader_temp.xlsx"
    test_df.to_excel(test_excel_filename, index=False)

    # Definir una carpeta de destino para las pruebas (se creará y limpiará)
    test_output_destination_folder = os.path.join(os.path.dirname(__file__), "test_download_output")

    if os.path.exists(test_output_destination_folder):
        import shutil
        shutil.rmtree(test_output_destination_folder) # Limpiar ejecuciones anteriores
    os.makedirs(test_output_destination_folder, exist_ok=True)
    
    logger.info(f"Excel de prueba: '{os.path.abspath(test_excel_filename)}'")
    logger.info(f"Carpeta de destino para pruebas: '{os.path.abspath(test_output_destination_folder)}'")

    # Probar sin CODDEPTO (solo descarga primaria)
    # results = execute_download_process(test_excel_filename, "SKU_CL", test_output_destination_folder)
    
    # Probar con CODDEPTO (intenta descarga primaria y luego secundaria si es necesario)
    results = execute_download_process(test_excel_filename, "SKU_CL", test_output_destination_folder, coddepto_column_name="CODDEPTO")
    
    print(f"\nResultados finales de la prueba:\n{results}")

    # Opcional: limpiar el archivo Excel de prueba
    # os.remove(test_excel_filename)
    # La carpeta test_download_output permanece para inspección.