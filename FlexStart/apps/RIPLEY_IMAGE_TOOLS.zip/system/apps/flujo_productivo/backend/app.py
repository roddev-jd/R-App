# backend/app.py - Router para integración con FlexStart

import os
import io
import asyncio
from fastapi import APIRouter, HTTPException, UploadFile, File, Form, BackgroundTasks
from fastapi.responses import FileResponse, StreamingResponse, JSONResponse
from pydantic import BaseModel
from typing import Optional
import pandas as pd
import logging

# --- Configuración del Logger ---
logger = logging.getLogger(__name__)

# --- Importación de Configuración ---
from .config import (
    PROCESS_FOLDER_NAME,
    ALLOWED_EXCEL_EXTENSIONS,
    MAX_PROCESSING_EVENTS,
    PROCESSED_EXCEL_SUFFIX
)

from .models.app_state import FlujoProcesamiento

# --- Importación de Utilidades de Limpieza de Datos ---
from .utils.data_cleaning import clean_excel_column, clean_sku_ean_mapping

# --- Importación de la Lógica de Negocio desde core_logic ---
try:
    from .core_logic.downloader import execute_download_process
    from .core_logic.folder_renamer import execute_folder_renaming
    from .core_logic.image_renamer import execute_internal_image_renaming
    from .core_logic.local_copier import execute_local_copy_process, LocalCopyCancelledException
    logger.info("Módulos de core_logic importados correctamente.")
except ImportError as e:
    logging.basicConfig(level=logging.ERROR)
    logger_init = logging.getLogger(__name__)
    logger_init.error(f"Error CRÍTICO al importar módulos de core_logic: {e}. "
                      "Asegúrate de que la carpeta 'core_logic' sea un subdirectorio de 'backend', "
                      "contenga un __init__.py (puede estar vacío), y que los módulos .py no tengan errores internos.")
    raise e

# --- Creación del Router para FlexStart ---
router = APIRouter(prefix="/flujo_productivo", tags=["flujo_productivo"])
logger.info("Router de Flujo Productivo creado para integración con FlexStart.")


# --- Configuración de Carpetas de la Aplicación ---
APP_PY_DIR = os.path.dirname(os.path.abspath(__file__)) # Directorio 'backend'
PROJECT_ROOT_DIR = os.path.dirname(APP_PY_DIR) # Raíz del proyecto
# Cambio #1: Usar la carpeta "Proceso" en la raíz del proyecto
PROCESS_FOLDER = os.path.join(PROJECT_ROOT_DIR, PROCESS_FOLDER_NAME)
ALLOWED_EXTENSIONS = ALLOWED_EXCEL_EXTENSIONS

try:
    os.makedirs(PROCESS_FOLDER, exist_ok=True)
    logger.info(f"Carpeta de proceso (base para cargas y descargas): {PROCESS_FOLDER}")
except OSError as e:
    logger.error(f"No se pudo crear la carpeta de proceso en {PROCESS_FOLDER}: {e}")


# --- Estado Global de la Aplicación ---
app_state = FlujoProcesamiento()


def _reset_app_state():
    """Resetea el estado de la aplicación a sus valores iniciales."""
    app_state.reset(PROCESSED_EXCEL_SUFFIX)
    logger.info("Estado de la aplicación reseteado.")


def _add_processing_event(event_type, message, sku=None, image_type=None, url=None):
    """Agrega un evento de procesamiento para mostrar en la UI con información detallada."""
    event = app_state.record_processing_event(
        event_type,
        message,
        sku=sku,
        image_type=image_type,
        url=url,
        max_events=MAX_PROCESSING_EVENTS
    )

    total_events = len(app_state.processing_events)
    logger.info(f"[EVENTO] {event['timestamp']} - {message}")
    logger.debug(f"[EVENTO DEBUG] Total eventos en memoria: {total_events}")


# === SUBFUNCIONES PARA VERIFICACIÓN DE CARPETAS (FASE 5) ===

def _validate_verification_preconditions() -> tuple[bool, Optional[str], set]:
    """
    Valida que existan los datos necesarios para verificar carpetas.
    
    Returns:
        Tupla (es_valido, mensaje_error, expected_folders_set)
    """
    if not app_state.get("download_base_path") or not app_state.get("sku_cl_list_for_verification"):
        return False, "No se puede verificar: faltan datos del Excel cargado", set()
    
    expected_folders = set(app_state["sku_cl_list_for_verification"])
    
    if not os.path.exists(app_state["download_base_path"]):
        error_msg = f"El directorio de trabajo '{app_state['download_base_path']}' no existe."
        logger.error(error_msg)
        return False, error_msg, expected_folders
    
    return True, None, expected_folders


def _get_actual_folders_from_path(base_path: str) -> set:
    """
    Obtiene el conjunto de carpetas que realmente existen en el directorio base.
    
    Args:
        base_path: Ruta del directorio a escanear
        
    Returns:
        Set con los nombres de las carpetas encontradas
    """
    actual_folders_list = [
        d for d in os.listdir(base_path)
        if os.path.isdir(os.path.join(base_path, d))
    ]
    return set(actual_folders_list)


def _count_images_in_folders(base_path: str, folder_names: set) -> int:
    """
    Cuenta el total de imágenes en las carpetas especificadas.
    
    Args:
        base_path: Directorio base donde están las carpetas
        folder_names: Nombres de las carpetas a revisar
        
    Returns:
        Número total de imágenes encontradas
    """
    total_images = 0
    for folder_name in folder_names:
        folder_path = os.path.join(base_path, folder_name)
        if os.path.isdir(folder_path):
            image_files = [
                f for f in os.listdir(folder_path)
                if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp', '.gif'))
            ]
            total_images += len(image_files)
    return total_images


def _build_verification_success_message(
    mode: str, 
    found_count: int, 
    total_images: int,
    count_images: bool
) -> str:
    """
    Construye mensaje de éxito cuando todas las carpetas están presentes.
    
    Args:
        mode: 'auto' o 'manual'
        found_count: Número de carpetas encontradas
        total_images: Total de imágenes contadas (si count_images=True)
        count_images: Si se contaron imágenes
        
    Returns:
        Mensaje descriptivo del éxito
    """
    if mode == 'auto':
        download_results = app_state.get("download_results", {})
        reported_images = download_results.get('total_images_downloaded', 0)
        reported_items = download_results.get('total_items_processed', 0)
        
        actual_items = found_count if reported_items == 0 else reported_items
        actual_images = total_images if reported_images == 0 else reported_images
        
        return f"¡Descarga exitosa! {actual_images} imágenes descargadas de {actual_items} productos. Todas las carpetas creadas. Paso 2 habilitado."
    else:  # manual
        return f"✅ Reverificación exitosa! Todas las {found_count} carpetas encontradas. Paso 2 habilitado."


def _build_verification_failure_message(
    mode: str,
    found_count: int,
    missing_count: int,
    missing_folders: list,
    total_expected: int,
    actual_folders_count: int
) -> str:
    """
    Construye mensaje cuando faltan carpetas.
    
    Args:
        mode: 'auto' o 'manual'
        found_count: Carpetas encontradas
        missing_count: Carpetas faltantes
        missing_folders: Lista de nombres de carpetas faltantes
        total_expected: Total de carpetas esperadas
        actual_folders_count: Carpetas reales en el directorio
        
    Returns:
        Mensaje descriptivo de la falla
    """
    if mode == 'auto':
        download_results = app_state.get("download_results", {})
        total_images_dl = download_results.get('total_images_downloaded', 0)
        total_items_dl = download_results.get('total_items_processed', 0)
        
        if found_count > 0:
            return f"Descarga parcial: {total_images_dl} imágenes descargadas de {total_items_dl} productos procesados. {found_count} carpetas creadas, {missing_count} productos sin imágenes. Reporte disponible."
        else:
            return f"No se encontraron imágenes: {total_items_dl} productos procesados, pero no se crearon carpetas. {missing_count} productos fallidos. Reporte disponible."
    else:  # manual
        if found_count > 0:
            sample_missing = ', '.join(sorted(missing_folders)[:5])
            if missing_count > 5:
                sample_missing += '...'
            return f"⚠️ Aún faltan imágenes: {found_count}/{total_expected} carpetas encontradas. Faltan {missing_count} productos: {sample_missing}. Agregue las imágenes manualmente y verifique nuevamente."
        else:
            if actual_folders_count > 0:
                return f"❌ Error de nombres: Se encontraron {actual_folders_count} carpetas, pero no coinciden con los SKUs del Excel. Verifique que los nombres de las carpetas coincidan exactamente con los SKUs."
            else:
                return f"❌ Sin imágenes: No se encontraron carpetas en '{app_state['download_base_path']}'. Agregue manualmente las carpetas con imágenes y verifique nuevamente."


def _unified_folder_verification(mode: str = 'manual', count_images: bool = False) -> dict:
    """
    Función unificada para verificar carpetas creadas vs SKUs esperados del Excel.

    Elimina la duplicación entre verificación automática (post-descarga)
    y verificación manual (usuario solicita).

    Args:
        mode: 'auto' (post-descarga) o 'manual' (usuario solicita explícitamente)
        count_images: Si True, cuenta imágenes reales en carpetas (solo para modo 'auto')

    Returns:
        dict con estructura:
        {
            "success": bool,  # True si la verificación se pudo ejecutar
            "verified": bool,  # True si todas las carpetas están presentes
            "found_count": int,
            "missing_count": int,
            "missing_list": list[str],
            "message": str,
            "report_available": bool,
            "total_images": int (solo si count_images=True)
        }
    """
    try:
        # Validar precondiciones
        is_valid, error_msg, expected_folders = _validate_verification_preconditions()
        
        if not is_valid:
            logger.warning(error_msg)
            if mode == 'auto':
                _add_processing_event("warning" if "faltan datos" in error_msg else "error", error_msg)
            
            return {
                "success": False,
                "verified": False,
                "found_count": 0,
                "missing_count": len(expected_folders),
                "missing_list": list(expected_folders),
                "message": error_msg,
                "report_available": False
            }

        # Obtener carpetas actuales del sistema de archivos
        base_path = app_state["download_base_path"]
        actual_folders = _get_actual_folders_from_path(base_path)

        # Calcular coincidencias y faltantes
        matching_folders = expected_folders.intersection(actual_folders)
        missing_folders = list(expected_folders - actual_folders)
        
        found_count = len(matching_folders)
        missing_count = len(missing_folders)
        total_expected = len(expected_folders)

        logger.info(f"Verificación {mode}: {found_count} encontradas, {missing_count} faltantes de {total_expected} totales")

        # Contar imágenes si se solicita
        total_images = 0
        if count_images and found_count > 0:
            total_images = _count_images_in_folders(base_path, matching_folders)

        # Determinar si verificación fue exitosa
        all_folders_present = missing_count == 0

        # Construir respuesta según resultado
        if all_folders_present:
            message = _build_verification_success_message(mode, found_count, total_images, count_images)
            
            return {
                "success": True,
                "verified": True,
                "found_count": found_count,
                "missing_count": 0,
                "missing_list": [],
                "message": message,
                "report_available": False,
                "total_images": total_images if count_images else 0
            }
        else:
            actual_folders_count = len(actual_folders)
            message = _build_verification_failure_message(
                mode, found_count, missing_count, missing_folders, 
                total_expected, actual_folders_count
            )
            
            return {
                "success": True,
                "verified": False,
                "found_count": found_count,
                "missing_count": missing_count,
                "missing_list": sorted(missing_folders),
                "message": message,
                "report_available": True,
                "total_images": total_images if count_images else 0
            }

    except Exception as e:
        error_msg = f"Error durante la verificación del Paso 1: {str(e)}"
        logger.exception(f"Excepción en _unified_folder_verification (mode={mode}): {e}")
        if mode == 'auto':
            _add_processing_event("error", f"Error en verificación automática: {str(e)}")

        return {
            "success": False,
            "verified": False,
            "found_count": 0,
            "missing_count": 0,
            "missing_list": [],
            "message": error_msg,
            "report_available": False
        }

# === SUBFUNCIONES PARA PROCESO DE DESCARGA (FASE 5) ===

def _handle_download_success(download_results: dict) -> None:
    """
    Maneja el estado después de una descarga exitosa.
    
    Args:
        download_results: Diccionario con resultados de la descarga
    """
    app_state["download_completed"] = True
    app_state.set_download_results(download_results)
    app_state["step1_completed"] = True
    
    # Registrar resultados detallados para diagnóstico
    total_images = download_results.get('total_images_downloaded', 0)
    total_items = download_results.get('total_items_processed', 0)
    download_success = download_results.get("success", False)
    
    logger.info(f"Descarga completada - Success: {download_success}, Items: {total_items}, Images: {total_images}")
    logger.info(f"Download results completos: {download_results}")
    
    _add_processing_event("info", f"Descarga terminada: {total_images} imágenes de {total_items} productos. Ejecutando verificación automática...")
    
    # Ejecutar verificación automática
    logger.info("FORZANDO verificación automática inmediatamente...")
    try:
        _perform_automatic_verification()
    except Exception as e:
        logger.error(f"Error en verificación automática forzada: {e}")
        _add_processing_event("error", f"Error en verificación automática: {str(e)}")


def _handle_download_cancellation() -> None:
    """Maneja el estado después de una cancelación de descarga por el usuario."""
    app_state["download_completed"] = True
    app_state.set_download_results({
        "success": True,
        "message": "Descarga cancelada por el usuario.",
        "details": {
            "total_items_processed": app_state.get("processed_skus", 0),
            "total_images_downloaded": app_state.get("successful_downloads", 0)
        },
        "cancelled": True
    })
    app_state["current_status_message"] = "Descarga cancelada por el usuario."
    _add_processing_event("warning", app_state["current_status_message"])
    logger.info("Descarga en background cancelada por el usuario")


def _handle_download_error(error: Exception) -> None:
    """
    Maneja el estado después de un error en la descarga.
    
    Args:
        error: Excepción capturada durante la descarga
    """
    app_state["download_completed"] = True
    app_state["download_error"] = str(error)
    app_state["current_status_message"] = f"Error en descarga: {str(error)}"
    _add_processing_event("error", app_state["current_status_message"])
    logger.error(f"Error en descarga background: {error}", exc_info=True)


def _perform_automatic_verification():
    """
    Realiza verificación automática después de completar la descarga.
    Refactorizada para usar _unified_folder_verification().
    """
    _add_processing_event("info", "Ejecutando verificación automática de carpetas...")
    logger.info("Iniciando verificación automática post-descarga")

    # Llamar a la función unificada en modo automático con conteo de imágenes
    result = _unified_folder_verification(mode='auto', count_images=True)

    # Actualizar estado basado en resultado
    if result["success"]:
        if result["verified"]:
            # ✅ Todas las carpetas presentes - Habilitar Paso 2
            app_state["step1_verified"] = True
            app_state["last_error_message"] = None
            app_state["current_status_message"] = result["message"]
            _add_processing_event("success", result["message"])
            logger.info(f"Verificación automática exitosa - Paso 2 habilitado")
        else:
            # ⚠️ Faltan carpetas - Generar reporte
            app_state["step1_verified"] = False
            app_state["last_missing_sku_report_data"] = result["missing_list"]
            app_state["current_status_message"] = result["message"]
            app_state["last_error_message"] = result["message"]
            _add_processing_event("warning", result["message"])
            logger.warning(f"Verificación automática: descarga parcial - {result['missing_count']} productos faltantes")
    else:
        # ❌ Error en verificación
        app_state["step1_verified"] = False
        app_state["last_error_message"] = result["message"]
        logger.error(f"Error en verificación automática: {result['message']}")

async def _background_download_process():
    """
    Ejecuta el proceso de descarga en background y actualiza el estado.
    
    Refactorizada en FASE 5 para mejor manejo de errores y legibilidad.
    """
    # Importar la excepción de cancelación
    try:
        from .core_logic.downloader import DownloadCancelledException
    except ImportError:
        from core_logic.downloader import DownloadCancelledException
    
    try:
        # Marcar que la descarga está en progreso
        app_state["download_in_progress"] = True
        app_state["download_completed"] = False
        app_state["download_error"] = None
        app_state.set_download_results(None)

        _add_processing_event("info", f"Iniciando descarga en background para {app_state['total_skus']} productos...")
        logger.info("Iniciando proceso de descarga en background")

        # Ejecutar el proceso de descarga sincrónicamente en un hilo separado
        # para no bloquear el loop de eventos de asyncio
        loop = asyncio.get_event_loop()
        download_results = await loop.run_in_executor(
            None,  # Usar el default ThreadPoolExecutor
            execute_download_process,
            app_state["excel_file_path"],
            "SKU_CL",
            app_state["download_base_path"],
            "CODDEPTO",
            "both_fallback",  # download_type parameter
            app_state,
            _add_processing_event
        )

        # Manejar éxito de la descarga (usando subfunción)
        _handle_download_success(download_results)

    except DownloadCancelledException:
        # Descarga cancelada por el usuario (usando subfunción)
        _handle_download_cancellation()

    except Exception as e:
        # Error en la descarga (usando subfunción)
        _handle_download_error(e)

    finally:
        # Limpiar estado de progreso
        app_state["download_in_progress"] = False
        logger.info("Proceso de descarga background finalizado")


async def _background_local_copy_process():
    """
    Ejecuta el proceso de copiado local en background y actualiza el estado.
    """
    try:
        # Marcar que el copiado está en progreso
        app_state["download_in_progress"] = True
        app_state["download_completed"] = False
        app_state["download_error"] = None
        app_state.set_download_results(None)

        _add_processing_event("info", f"Iniciando copiado local para {app_state['total_skus']} carpetas...")
        logger.info("Iniciando proceso de copiado local en background")

        # Ejecutar el proceso de copiado sincrónicamente en un hilo separado
        loop = asyncio.get_event_loop()
        copy_results = await loop.run_in_executor(
            None,  # Usar el default ThreadPoolExecutor
            execute_local_copy_process,
            app_state["sku_cl_list_for_verification"],
            app_state["local_source_path"],
            app_state["download_base_path"],
            app_state,
            _add_processing_event
        )

        # Procesar resultados del copiado
        app_state["download_completed"] = True
        
        # Adaptar resultados al formato esperado por el frontend
        adapted_results = {
            "success": copy_results["success"],
            "message": copy_results["message"],
            "total_items_processed": copy_results["total_items_processed"],
            "total_images_downloaded": copy_results["total_files_copied"],
            "folders_found": copy_results["total_folders_found"],
            "folders_copied": copy_results["total_folders_copied"],
            "missing_folders": copy_results["missing_folders"]
        }
        
        app_state.set_download_results(adapted_results)
        app_state["step1_completed"] = True
        
        # Registrar resultados
        logger.info(f"Copiado completado - Carpetas: {copy_results['total_folders_copied']}/{copy_results['total_items_processed']}, "
                   f"Archivos: {copy_results['total_files_copied']}")
        
        _add_processing_event("info", f"Copiado terminado: {copy_results['total_files_copied']} archivos de "
                            f"{copy_results['total_folders_copied']} carpetas. Ejecutando verificación automática...")
        
        # Ejecutar verificación automática
        logger.info("FORZANDO verificación automática inmediatamente...")
        try:
            _perform_automatic_verification()
        except Exception as e:
            logger.error(f"Error en verificación automática forzada: {e}")
            _add_processing_event("error", f"Error en verificación automática: {str(e)}")

    except LocalCopyCancelledException:
        # Copiado cancelado por el usuario
        app_state["download_completed"] = True
        app_state.set_download_results({
            "success": True,
            "message": "Copiado cancelado por el usuario.",
            "details": {
                "total_items_processed": app_state.get("processed_skus", 0),
                "total_images_downloaded": app_state.get("successful_downloads", 0)
            },
            "cancelled": True
        })
        app_state["current_status_message"] = "Copiado cancelado por el usuario."
        _add_processing_event("warning", app_state["current_status_message"])
        logger.info("Copiado en background cancelado por el usuario")

    except Exception as e:
        # Error en el copiado
        app_state["download_completed"] = True
        app_state["download_error"] = str(e)
        app_state["current_status_message"] = f"Error en copiado: {str(e)}"
        _add_processing_event("error", app_state["current_status_message"])
        logger.error(f"Error en copiado background: {e}", exc_info=True)

    finally:
        # Limpiar estado de progreso
        app_state["download_in_progress"] = False
        logger.info("Proceso de copiado local background finalizado")

# --- Modelos Pydantic ---
class WorkingDirectoryRequest(BaseModel):
    directory: str

class StatusResponse(BaseModel):
    success: bool
    message: str
    valid: Optional[bool] = None
    directory: Optional[str] = None

def _secure_filename(filename):
    """Versión simplificada de secure_filename sin dependencia de werkzeug"""
    import re
    filename = str(filename).strip().replace(' ', '_')
    return re.sub(r'[^\w\-_\.]', '', filename)

def _is_allowed_file(filename):
    """Verifica si la extensión del archivo está permitida."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Función _clean_excel_string_column removida - ahora se usa clean_excel_column de utils.data_cleaning


# === SUBFUNCIONES PARA CARGA DE EXCEL (FASE 5) ===

def _validate_uploaded_file(file: UploadFile) -> tuple[bool, Optional[str]]:
    """
    Valida el archivo subido.
    
    Returns:
        Tupla (es_valido, mensaje_error)
    """
    if not file:
        return False, "No se encontró el archivo en la solicitud."
    
    if file.filename == '' or not file.filename:
        return False, "Ningún archivo seleccionado."
    
    if not _is_allowed_file(file.filename):
        return False, "Tipo de archivo no permitido. Solo se aceptan .xlsx o .xls."
    
    return True, None


async def _determine_and_save_excel_file(
    file: UploadFile, 
    working_directory: Optional[str],
    original_filename: str
) -> tuple[str, str]:
    """
    Determina el directorio de trabajo y guarda el archivo Excel si es necesario.
    
    Args:
        file: Archivo subido
        working_directory: Directorio especificado por el usuario (opcional)
        original_filename: Nombre del archivo seguro
        
    Returns:
        Tupla (excel_file_path, excel_directory)
        
    Raises:
        HTTPException: Si hay error al guardar o el directorio es inválido
    """
    working_directory = working_directory.strip() if working_directory else ''
    
    if working_directory:
        # Si la ruta incluye un archivo, extraer solo el directorio
        if working_directory.endswith(('.xlsx', '.xls')):
            working_directory = os.path.dirname(working_directory)
        
        # Verificar que el directorio existe y es válido
        if os.path.isdir(working_directory):
            excel_directory = working_directory
            excel_file_path = os.path.join(working_directory, original_filename)
            logger.info(f"Usando carpeta real del archivo Excel: {working_directory}")
            
            # Verificar si el archivo Excel ya existe en esa carpeta
            if os.path.exists(excel_file_path):
                logger.info(f"Archivo Excel ya existe en la carpeta: {excel_file_path}. Usando archivo existente.")
            else:
                # Solo guardar el archivo si NO existe en la carpeta especificada
                try:
                    contents = await file.read()
                    with open(excel_file_path, 'wb') as f:
                        f.write(contents)
                    logger.info(f"Archivo Excel guardado en carpeta especificada: {excel_file_path}")
                except Exception as e:
                    error_msg = f"Error al guardar el archivo Excel en la carpeta especificada: {e}"
                    logger.error(error_msg)
                    raise HTTPException(status_code=500, detail=error_msg)
        else:
            # La carpeta especificada no es válida
            logger.warning(f"Carpeta especificada no es válida: {working_directory}")
            raise HTTPException(
                status_code=400, 
                detail=f"La carpeta especificada no existe o no es válida: {working_directory}"
            )
    else:
        # Fallback: usar PROCESS_FOLDER cuando no se especifica carpeta
        excel_directory = os.path.join(PROCESS_FOLDER, os.path.splitext(original_filename)[0])
        os.makedirs(excel_directory, exist_ok=True)
        excel_file_path = os.path.join(excel_directory, original_filename)
        logger.info(f"Fallback: usando carpeta de proceso: {excel_directory}")
        
        # Guardar el archivo en la carpeta de proceso
        try:
            contents = await file.read()
            with open(excel_file_path, 'wb') as f:
                f.write(contents)
            logger.info(f"Archivo Excel guardado en fallback: {excel_file_path}")
        except Exception as e:
            error_msg = f"Error al guardar el archivo Excel: {e}"
            logger.error(error_msg)
            raise HTTPException(status_code=500, detail=error_msg)
    
    return excel_file_path, excel_directory


def _detect_default_columns(df: pd.DataFrame) -> tuple[Optional[str], Optional[str]]:
    """
    Detecta columnas por defecto si existen (para preseleccionar en UI).
    
    Args:
        df: DataFrame de pandas con datos del Excel
        
    Returns:
        Tupla (default_sku_column, default_ean_column)
    """
    default_sku_column = "SKU_CL" if "SKU_CL" in df.columns else None
    default_ean_column = "EAN_HIJO" if "EAN_HIJO" in df.columns else None
    return default_sku_column, default_ean_column


# --- Endpoint para servir el frontend ---
@router.get("/")
async def serve_index():
    frontend_dir = os.path.join(PROJECT_ROOT_DIR, 'frontend')
    index_path = os.path.join(frontend_dir, 'index.html')
    logger.info(f"Intentando servir index.html desde: {index_path}")
    if not os.path.exists(index_path):
        logger.error(f"index.html NO ENCONTRADO en {frontend_dir}")
        raise HTTPException(status_code=404, detail="Frontend index.html no encontrado.")
    return FileResponse(index_path)

@router.get("")
async def serve_index_without_slash():
    """Endpoint alternativo sin barra final para compatibilidad."""
    frontend_dir = os.path.join(PROJECT_ROOT_DIR, 'frontend')
    index_path = os.path.join(frontend_dir, 'index.html')
    logger.info(f"Intentando servir index.html (sin barra) desde: {index_path}")
    if not os.path.exists(index_path):
        logger.error(f"index.html NO ENCONTRADO en {frontend_dir}")
        raise HTTPException(status_code=404, detail="Frontend index.html no encontrado.")
    return FileResponse(index_path)


# --- Rutas API de la aplicación ---
@router.get('/api/status')
async def get_application_status():
    logger.debug("Solicitud de estado recibida para /api/status")
    return JSONResponse(content=app_state.to_dict())

@router.get('/api/processing_events')
async def get_processing_events():
    """Obtiene los eventos de procesamiento en tiempo real con información detallada."""
    try:
        state_snapshot = app_state.to_dict()
        events = state_snapshot.get("processing_events", [])
        current_sku = state_snapshot.get("current_processing_sku")
        current_image_type = state_snapshot.get("current_image_type")
        current_url = state_snapshot.get("current_url")
        total_skus = state_snapshot.get("total_skus", 0)
        processed_skus = state_snapshot.get("processed_skus", 0)
        successful_downloads = state_snapshot.get("successful_downloads", 0)
        failed_downloads = state_snapshot.get("failed_downloads", 0)
        download_in_progress = state_snapshot.get("download_in_progress", False)
        download_completed = state_snapshot.get("download_completed", False)
        download_error = state_snapshot.get("download_error")
        download_results = state_snapshot.get("download_results")

        logger.debug(
            "Processing events request - events=%s current_sku=%s processed=%s/%s",
            len(events),
            current_sku,
            processed_skus,
            total_skus,
        )

        return JSONResponse(content={
            "events": events,
            "current_processing_sku": current_sku,
            "current_image_type": current_image_type,
            "current_url": current_url,
            "total_skus": total_skus,
            "processed_skus": processed_skus,
            "successful_downloads": successful_downloads,
            "failed_downloads": failed_downloads,
            "download_in_progress": download_in_progress,
            "download_completed": download_completed,
            "download_error": download_error,
            "download_results": download_results,
        })

    except Exception as e:
        logger.error(f"Error en get_processing_events: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "events": [],
                "current_processing_sku": None,
                "current_image_type": None,
                "current_url": None,
                "total_skus": 0,
                "processed_skus": 0,
                "successful_downloads": 0,
                "failed_downloads": 0,
                "error": f"Error del servidor: {str(e)}"
            })

@router.post('/api/cancel_download')
async def cancel_download():
    """Endpoint para cancelar la descarga en progreso inmediatamente."""
    app_state["should_cancel_download"] = True
    _add_processing_event("warning", "Cancelación solicitada por el usuario. Deteniendo descarga inmediatamente...")
    logger.info("Usuario solicitó cancelar la descarga. Flag de cancelación activado.")
    
    # NUEVO: Forzar cancelación inmediata cambiando el estado
    app_state["step1_completed"] = True  # Marcar como "completado" para detener el proceso
    app_state["current_status_message"] = "Descarga cancelada por el usuario."
    
    return JSONResponse(content={
        "success": True,
        "message": "Descarga cancelada. Deteniendo proceso inmediatamente..."
    })

# --- NUEVO ENDPOINT PARA INICIAR UN NUEVO PROYECTO ---
@router.post('/api/new_project')
async def new_project():
    _reset_app_state()
    logger.info("Se ha iniciado un nuevo proyecto. El estado ha sido reseteado.")
    return JSONResponse(content={"success": True, "message": "Nuevo proyecto iniciado. Puede cargar un nuevo archivo Excel."})


# --- NUEVO ENDPOINT PARA ESTABLECER EL MODO DE OPERACIÓN ---
@router.post('/api/set_operation_mode')
async def set_operation_mode(request_data: dict):
    """Establece el modo de operación (download o local_copy)."""
    mode = request_data.get("mode", "download")
    
    if mode not in ["download", "local_copy"]:
        raise HTTPException(status_code=400, detail="Modo inválido. Debe ser 'download' o 'local_copy'.")
    
    app_state["operation_mode"] = mode
    logger.info(f"Modo de operación establecido: {mode}")
    
    return JSONResponse(content={
        "success": True,
        "message": f"Modo establecido: {'Descargar desde Internet' if mode == 'download' else 'Copiar desde Equipo Local'}",
        "mode": mode
    })


# --- NUEVO ENDPOINT PARA ESTABLECER UBICACIÓN DE ORIGEN (MODO LOCAL) ---
@router.post('/api/set_local_source_path')
async def set_local_source_path(request_data: dict):
    """Establece la ubicación de origen para el modo de copiado local."""
    source_path = request_data.get("source_path", "").strip()
    
    if not source_path:
        raise HTTPException(status_code=400, detail="La ruta de origen no puede estar vacía.")
    
    if not os.path.exists(source_path):
        return JSONResponse(content={
            "success": False,
            "message": f"La carpeta de origen no existe: {source_path}",
            "valid": False
        })
    
    if not os.path.isdir(source_path):
        return JSONResponse(content={
            "success": False,
            "message": f"La ruta especificada no es una carpeta válida: {source_path}",
            "valid": False
        })
    
    app_state["local_source_path"] = source_path
    logger.info(f"Ubicación de origen establecida: {source_path}")
    
    return JSONResponse(content={
        "success": True,
        "message": f"Ubicación de origen establecida: {source_path}",
        "valid": True,
        "source_path": source_path
    })


# --- NUEVO ENDPOINT PARA VERIFICAR CARPETA DE TRABAJO ---
@router.post('/api/verify_working_directory')
async def verify_working_directory(request_data: WorkingDirectoryRequest):
    """Verifica si una carpeta de trabajo es válida y tiene permisos de escritura."""
    directory = request_data.directory.strip()
    
    if not directory:
        raise HTTPException(status_code=400, detail="La carpeta de trabajo no puede estar vacía.")
    
    try:
        # Verificar si la carpeta existe
        if not os.path.exists(directory):
            return JSONResponse(content={
                "success": False, 
                "message": f"La carpeta '{directory}' no existe.",
                "valid": False
            })
        
        # Verificar si es un directorio
        if not os.path.isdir(directory):
            return JSONResponse(content={
                "success": False, 
                "message": f"'{directory}' no es una carpeta válida.",
                "valid": False
            })
        
        # Verificar permisos de escritura
        test_file = os.path.join(directory, '.test_write_permission')
        try:
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            writable = True
        except (OSError, IOError):
            writable = False
        
        if not writable:
            return JSONResponse(content={
                "success": False, 
                "message": f"No tienes permisos de escritura en la carpeta '{directory}'.",
                "valid": False
            })
        
        return JSONResponse(content={
            "success": True, 
            "message": f"Carpeta de trabajo válida: {directory}",
            "valid": True,
            "directory": directory
        })
        
    except Exception as e:
        logger.error(f"Error al verificar carpeta de trabajo '{directory}': {e}")
        raise HTTPException(status_code=500, detail=f"Error al verificar la carpeta de trabajo: {str(e)}")


@router.post('/api/confirm_column_selection')
async def confirm_column_selection(
    sku_column: str = Form(...),
    ean_column: str = Form(...),
    filename: str = Form(...)
):
    """Endpoint para confirmar la selección de columnas por parte del usuario."""
    if not app_state["excel_file_path"]:
        raise HTTPException(status_code=400, detail="No hay archivo Excel cargado")
    
    try:
        df = pd.read_excel(app_state["excel_file_path"])
        
        # Verificar que las columnas seleccionadas existan
        if sku_column not in df.columns:
            raise HTTPException(status_code=400, detail=f"La columna seleccionada '{sku_column}' no existe en el Excel")
        if ean_column not in df.columns:
            raise HTTPException(status_code=400, detail=f"La columna seleccionada '{ean_column}' no existe en el Excel")
        
        # Renombrar las columnas para que el resto del sistema funcione
        df = df.rename(columns={sku_column: "SKU_CL", ean_column: "EAN_HIJO"})
        
        # Procesar las columnas renombradas usando función centralizada
        df["SKU_CL"] = clean_excel_column(df["SKU_CL"])
        df["EAN_HIJO"] = clean_excel_column(df["EAN_HIJO"])

        # NUEVO: Guardar el DataFrame procesado como archivo temporal para el downloader
        processed_excel_path = app_state["excel_file_path"].replace('.xlsx', PROCESSED_EXCEL_SUFFIX)
        df.to_excel(processed_excel_path, index=False)
        logger.info(f"DataFrame procesado guardado en: {processed_excel_path}")

        # Actualizar la ruta del Excel para usar el archivo procesado
        app_state["excel_file_path"] = processed_excel_path

        # Actualizar el estado con los datos procesados usando función centralizada
        sku_list, sku_ean_map = clean_sku_ean_mapping(df, "SKU_CL", "EAN_HIJO")
        app_state["sku_cl_list_for_verification"] = sku_list
        app_state["sku_ean_map_for_verification"] = sku_ean_map

        logger.info(f"Columnas confirmadas - SKU: '{sku_column}' -> SKU_CL, EAN: '{ean_column}' -> EAN_HIJO")
        logger.info(f"SKUs únicos procesados: {len(app_state['sku_cl_list_for_verification'])}. Mapeo SKU-EAN: {len(app_state['sku_ean_map_for_verification'])} entradas.")
        
        app_state["current_status_message"] = f"Archivo '{filename}' procesado exitosamente con columnas seleccionadas. SKU: '{sku_column}', EAN: '{ean_column}'. Listo para iniciar descarga."

        return JSONResponse(content={
            "success": True,
            "message": app_state["current_status_message"],
            "filename": filename,
            "expected_sku_folders": app_state["sku_cl_list_for_verification"],
            "working_directory": app_state["download_base_path"],
            "selected_columns": {"sku_column": sku_column, "ean_column": ean_column}
        })

    except Exception as e:
        error_msg = f"Error al procesar las columnas seleccionadas: {str(e)}"
        app_state["last_error_message"] = error_msg
        logger.error(error_msg)
        raise HTTPException(status_code=500, detail=error_msg)


@router.post('/api/upload_excel')
async def handle_excel_upload(
    file: UploadFile = File(...), 
    working_directory: Optional[str] = Form(None)
):
    """
    Maneja la carga de archivos Excel.
    
    Refactorizada en FASE 5 para mejor legibilidad usando subfunciones.
    """
    # Validar archivo subido
    is_valid, error_msg = _validate_uploaded_file(file)
    if not is_valid:
        app_state["last_error_message"] = error_msg
        logger.warning(error_msg)
        raise HTTPException(status_code=400, detail=error_msg)

    # Obtener nombre de archivo seguro
    original_filename = _secure_filename(file.filename)
    
    # Determinar directorio y guardar archivo
    try:
        excel_file_path, excel_directory = await _determine_and_save_excel_file(
            file, working_directory, original_filename
        )
    except HTTPException:
        raise  # Re-raise para que FastAPI lo maneje
    
    # Procesar Excel y preparar respuesta
    try:
        # Actualizar estado de la aplicación
        app_state["excel_file_path"] = excel_file_path
        app_state["excel_file_name"] = original_filename
        app_state["download_base_path"] = excel_directory
        
        logger.info(f"Archivo Excel '{original_filename}' procesado desde '{excel_file_path}'.")
        logger.info(f"Directorio de trabajo para esta sesión: '{excel_directory}'. Todo el procesamiento ocurrirá en esta carpeta.")

        # Leer Excel y obtener columnas disponibles
        df = pd.read_excel(excel_file_path)
        available_columns = df.columns.tolist()
        logger.info(f"Columnas disponibles en el Excel: {available_columns}")

        # Detectar columnas por defecto para preseleccionar
        default_sku_column, default_ean_column = _detect_default_columns(df)

        # Retornar respuesta para selección de columnas
        selection_message = "Archivo Excel cargado exitosamente. Por favor seleccione las columnas para procesamiento."
        logger.info("Mostrando selección de columnas al usuario")

        return JSONResponse(
            status_code=200,
            content={
                "success": False,  # False para activar la UI de selección
                "message": selection_message,
                "available_columns": available_columns,
                "needs_column_selection": True,
                "filename": original_filename,
                "working_directory": excel_directory,
                "default_sku_column": default_sku_column,
                "default_ean_column": default_ean_column
            }
        )

    except Exception as e:
        error_msg = f"Error al procesar el archivo Excel '{original_filename}': {e}"
        app_state["last_error_message"] = error_msg
        logger.exception("Excepción en handle_excel_upload:")
        raise HTTPException(status_code=500, detail=error_msg)


# --- PASO 1: Descarga de Imágenes / Copiado Local (VERSIÓN ASÍNCRONA) ---
@router.post('/api/start_step1_download')
async def start_step1_image_download(background_tasks: BackgroundTasks):
    # Validaciones previas
    if not app_state["excel_file_path"] or not app_state["download_base_path"]:
        msg = "Error: No se ha cargado un archivo Excel o la configuración de sesión es inválida."
        logger.error(msg)
        raise HTTPException(status_code=400, detail=msg)

    # Verificar que hay SKUs para procesar
    if not app_state["sku_cl_list_for_verification"] or len(app_state["sku_cl_list_for_verification"]) == 0:
        msg = "Error: El archivo Excel no contiene SKUs válidos para procesar. Verifique que la columna 'SKU_CL' tenga datos."
        logger.warning(msg)
        return JSONResponse(content={
            "success": False,
            "message": msg,
            "details": {"total_items_processed": 0, "total_images_downloaded": 0}
        })
    
    # Validación específica para modo local_copy
    operation_mode = app_state.get("operation_mode", "download")
    if operation_mode == "local_copy":
        if not app_state.get("local_source_path"):
            msg = "Error: Debe especificar la ubicación de origen para el modo de copiado local."
            logger.error(msg)
            raise HTTPException(status_code=400, detail=msg)
        
        if not os.path.exists(app_state["local_source_path"]):
            msg = f"Error: La ubicación de origen no existe: {app_state['local_source_path']}"
            logger.error(msg)
            raise HTTPException(status_code=400, detail=msg)

    # Verificar que no hay otra descarga/copiado en progreso
    if app_state["download_in_progress"]:
        action_name = "copiado" if operation_mode == "local_copy" else "descarga"
        msg = f"Ya hay un {action_name} en progreso. Espere a que termine o cancélelo antes de iniciar uno nuevo."
        logger.warning(msg)
        return JSONResponse(content={
            "success": False,
            "message": msg,
            "details": {"download_in_progress": True}
        })

    # Resetear estado para la nueva descarga/copiado
    app_state["should_cancel_download"] = False
    app_state["total_skus"] = len(app_state["sku_cl_list_for_verification"])
    app_state["processed_skus"] = 0
    app_state["successful_downloads"] = 0
    app_state["failed_downloads"] = 0
    app_state["processing_events"] = []
    app_state["download_in_progress"] = False
    app_state["download_completed"] = False
    app_state["download_error"] = None
    app_state.set_download_results(None)

    # Mensaje y proceso según el modo
    if operation_mode == "local_copy":
        app_state["current_status_message"] = f"Iniciando copiado local para {app_state['total_skus']} carpetas..."
        logger.info(app_state["current_status_message"])
        
        # Marcar que el copiado va a comenzar
        app_state["download_in_progress"] = True
        
        # Iniciar el proceso de copiado en background
        background_tasks.add_task(_background_local_copy_process)
        
        return JSONResponse(content={
            "success": True,
            "message": f"Copiado local iniciado para {app_state['total_skus']} carpetas. El progreso se mostrará automáticamente en pantalla.",
            "details": {
                "total_skus": app_state["total_skus"],
                "download_started": True,
                "background_process": True,
                "operation_mode": "local_copy"
            }
        })
    else:
        # Modo download (comportamiento original)
        app_state["current_status_message"] = f"Iniciando descarga de imágenes para {app_state['total_skus']} productos..."
        logger.info(app_state["current_status_message"])
        
        # Marcar que la descarga va a comenzar
        app_state["download_in_progress"] = True
        
        # Iniciar el proceso de descarga en background
        background_tasks.add_task(_background_download_process)
        
        return JSONResponse(content={
            "success": True,
            "message": f"Descarga iniciada exitosamente para {app_state['total_skus']} productos. El progreso se mostrará automáticamente en pantalla.",
            "details": {
                "total_skus": app_state["total_skus"],
                "download_started": True,
                "background_process": True,
                "operation_mode": "download"
            }
        })


@router.get('/api/verify_step1')
async def verify_step1_folder_creation():
    """
    Endpoint para verificación manual de carpetas (usuario hace clic en botón).
    Refactorizada para usar _unified_folder_verification().
    """
    # Verificar si tenemos la información necesaria (cargada desde el Excel)
    if not app_state["download_base_path"] or app_state["sku_cl_list_for_verification"] is None or not app_state["sku_cl_list_for_verification"]:
        msg = "No se ha cargado un archivo Excel o no contiene SKUs válidos para verificar."
        logger.warning(msg)
        raise HTTPException(status_code=400, detail={"success": False, "verified": False, "message": msg, "report_available": False})

    # Marcar paso como completado y preparar para verificación
    app_state["step1_completed"] = True
    app_state["current_status_message"] = "Reverificando carpetas manualmente..."
    logger.info("Usuario solicitó reverificación manual de carpetas")
    _add_processing_event("info", "Ejecutando reverificación manual de carpetas...")
    app_state["last_missing_sku_report_data"] = []  # Limpiar datos de reporte anterior

    # Llamar a la función unificada en modo manual (sin conteo de imágenes)
    result = _unified_folder_verification(mode='manual', count_images=False)

    # Actualizar estado basado en resultado
    if result["success"]:
        if result["verified"]:
            # ✅ Todas las carpetas presentes - Habilitar Paso 2
            app_state["step1_completed"] = True  # Marcar como completado si la verificación es exitosa
            app_state["step1_verified"] = True
            app_state["last_error_message"] = None
            app_state["current_status_message"] = result["message"]
            _add_processing_event("success", result["message"])
            logger.info(f"Reverificación manual exitosa: {result['found_count']} carpetas - Paso 2 habilitado")

            return JSONResponse(content={
                "success": True,
                "verified": True,
                "message": result["message"],
                "found_folders": result["found_count"],
                "total_expected": result["found_count"]  # Si verified=True, found == expected
            })
        else:
            # ⚠️ Faltan carpetas - Generar reporte
            app_state["step1_verified"] = False
            app_state["last_missing_sku_report_data"] = result["missing_list"]
            app_state["last_error_message"] = result["message"]
            app_state["current_status_message"] = result["message"]
            _add_processing_event("warning", result["message"])
            logger.warning(f"Reverificación manual: {result['message']}")

            return JSONResponse(content={
                "success": True,
                "verified": False,
                "message": result["message"],
                "report_available": result["report_available"],
                "missing_count": result["missing_count"],
                "found_folders": result["found_count"],
                "total_expected": result["found_count"] + result["missing_count"],
                "missing_folders": result["missing_list"]
            })
    else:
        # ❌ Error en verificación
        app_state["step1_verified"] = False
        app_state["last_error_message"] = result["message"]
        app_state["current_status_message"] = result["message"]
        logger.error(f"Error en verificación manual: {result['message']}")

        return JSONResponse(content={
            "success": True,  # API respondió correctamente
            "verified": False,
            "message": result["message"],
            "report_available": False
        })


# --- NUEVO ENDPOINT PARA DESCARGAR EL REPORTE DE SKUs FALTANTES ---
@router.get('/api/download_missing_sku_report')
async def download_missing_sku_report():
    missing_skus = app_state.get("last_missing_sku_report_data", [])

    if not missing_skus:
        logger.warning("Se intentó descargar reporte de faltantes, pero no hay datos almacenados o la lista está vacía.")
        raise HTTPException(status_code=404, detail={"success": False, "message": "No hay datos de SKUs faltantes para generar el reporte."})

    try:
        df_missing = pd.DataFrame(missing_skus, columns=['SKU_CL_FALTANTE'])

        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df_missing.to_excel(writer, index=False, sheet_name='SKUs Faltantes')
        output.seek(0)

        logger.info(f"Generando reporte Excel con {len(missing_skus)} SKUs faltantes.")

        return StreamingResponse(
            io.BytesIO(output.read()),
            media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers={"Content-Disposition": "attachment; filename=reporte_sku_faltantes.xlsx"}
        )
    except Exception as e:
        logger.exception("Error al generar el reporte Excel de SKUs faltantes:")
        raise HTTPException(status_code=500, detail={"success": False, "message": f"Error al generar el reporte: {e}"})


# --- PASO 2: Renombrar Carpetas ---
@router.post('/api/start_step2_rename_folders')
async def start_step2_folder_renaming():
    if not app_state["step1_verified"]:
        msg = "Error: Paso 1 no verificado. No se puede iniciar el renombrado de carpetas."
        logger.warning(msg)
        raise HTTPException(status_code=400, detail={"success": False, "message": msg})

    if not app_state["download_base_path"] or app_state["sku_ean_map_for_verification"] is None:
        msg = "Datos internos (ruta de descarga o mapa SKU-EAN) no disponibles para Paso 2."
        logger.error(msg)
        raise HTTPException(status_code=500, detail={"success": False, "message": msg})

    app_state["current_status_message"] = "Paso 2: Iniciando renombrado de carpetas (SKU_CL a EAN_HIJO)..."
    logger.info(app_state["current_status_message"])

    try:
        # execute_folder_renaming debe estar definido en ./core_logic/folder_renamer.py
        renaming_results = execute_folder_renaming(
            base_folder_path=app_state["download_base_path"],
            name_mapping=app_state["sku_ean_map_for_verification"]
        )

        app_state["step2_completed"] = True

        if renaming_results.get("success", False):
            app_state["last_error_message"] = None
            app_state["current_status_message"] = f"Paso 2 (Ren. Carpetas) completado. {renaming_results.get('message', '')}"
            logger.info(app_state["current_status_message"])
            return JSONResponse(content={"success": True, "message": app_state["current_status_message"], "details": renaming_results})
        else:
            app_state["last_error_message"] = f"Paso 2 (Ren. Carpetas) con problemas: {renaming_results.get('message', 'Error desconocido del módulo.')}"
            app_state["current_status_message"] = app_state["last_error_message"]
            logger.warning(app_state["current_status_message"])
            return JSONResponse(content={"success": False, "message": app_state["current_status_message"], "details": renaming_results})

    except Exception as e:
        app_state["step2_completed"] = True
        app_state["last_error_message"] = f"Error crítico e inesperado en Paso 2 (Ren. Carpetas): {e}"
        app_state["current_status_message"] = app_state["last_error_message"]
        logger.exception("Excepción crítica en start_step2_folder_renaming:")
        raise HTTPException(status_code=500, detail={"success": False, "message": app_state["current_status_message"]})

@router.get('/api/verify_step2')
async def verify_step2_folder_renaming_completion():
    """
    Verifica si el Paso 2 (Renombrado de Carpetas) ya fue completado.

    Esta verificación funciona independientemente de si el paso fue ejecutado o no,
    permitiendo retomar el flujo desde cualquier punto.
    """
    if not app_state["download_base_path"] or app_state["sku_ean_map_for_verification"] is None:
        msg = "Datos internos (ruta de descarga o mapa SKU-EAN) no disponibles para verificación del Paso 2."
        logger.error(msg)
        raise HTTPException(status_code=500, detail={"success": False, "verified": False, "message": msg})

    app_state["current_status_message"] = "Paso 2: Verificando renombrado de carpetas..."
    logger.info(app_state["current_status_message"])

    try:
        skus_that_should_have_been_renamed = set(app_state["sku_ean_map_for_verification"].keys())
        expected_ean_folders = set(app_state["sku_ean_map_for_verification"].values())

        if not os.path.exists(app_state["download_base_path"]):
            msg = f"Verificación Paso 2: Directorio de descarga '{app_state['download_base_path']}' no existe."
            app_state["step2_verified"] = False
            app_state["last_error_message"] = msg
            logger.error(msg)
            return JSONResponse(content={"success":True, "verified": False, "message": msg})

        actual_folders_in_path = [d for d in os.listdir(app_state["download_base_path"]) if os.path.isdir(os.path.join(app_state["download_base_path"], d))]
        actual_folders = set(actual_folders_in_path)

        missing_ean_folders = expected_ean_folders - actual_folders
        lingering_sku_folders = skus_that_should_have_been_renamed.intersection(actual_folders)

        error_details = []
        if missing_ean_folders:
            missing_str = ", ".join(list(missing_ean_folders)[:10])
            if len(missing_ean_folders) > 10: missing_str += "..."
            error_details.append(f"Faltan carpetas EAN_HIJO esperadas: {missing_str}")
        if lingering_sku_folders:
            lingering_str = ", ".join(list(lingering_sku_folders)[:10])
            if len(lingering_sku_folders) > 10: lingering_str += "..."
            error_details.append(f"Aún existen carpetas SKU_CL que debieron ser renombradas: {lingering_str}")

        if not error_details:
            app_state["step2_completed"] = True  # Marcar como completado si la verificación es exitosa
            app_state["step2_verified"] = True
            app_state["last_error_message"] = None
            app_state["current_status_message"] = "Paso 2 verificado: Carpetas renombradas a EAN_HIJO correctamente."
            logger.info(app_state["current_status_message"])
            return JSONResponse(content={"success": True, "verified": True, "message": app_state["current_status_message"]})
        else:
            app_state["step2_verified"] = False
            full_error_message = f"Verificación Paso 2 fallida: {'; '.join(error_details)}"
            app_state["last_error_message"] = full_error_message
            app_state["current_status_message"] = full_error_message
            logger.warning(app_state["current_status_message"])
            return JSONResponse(content={"success": True, "verified": False, "message": app_state["current_status_message"],
                            "details": {"missing_ean_folders": list(missing_ean_folders),
                                        "lingering_sku_folders": list(lingering_sku_folders)}})

    except Exception as e:
        app_state["step2_verified"] = False
        app_state["last_error_message"] = f"Error durante la verificación del Paso 2: {e}"
        app_state["current_status_message"] = app_state["last_error_message"]
        logger.exception("Excepción en verify_step2_folder_renaming_completion:")
        raise HTTPException(status_code=500, detail={"success": False, "verified": False, "message": app_state["current_status_message"]})

# --- PASO 3: Normalización de Extensiones ---
@router.post('/api/start_step3_normalize_extensions')
async def start_step3_normalize_extensions():
    """
    PASO 3: Normaliza las extensiones de los archivos de imagen.

    Este paso:
    - Agrega extensión .webp a archivos sin extensión
    - Convierte archivos .jpg/.jpeg a .webp
    - Corrige archivos con solo punto (.) a .webp
    """
    # Validaciones previas
    if not app_state["step2_verified"]:
        msg = "No se puede ejecutar Paso 3 (Normalización): Paso 2 no verificado."
        logger.warning(msg)
        raise HTTPException(status_code=400, detail={"success": False, "message": msg})

    if not app_state["download_base_path"]:
        msg = "Datos internos (ruta de descarga) no disponibles para Paso 3."
        logger.error(msg)
        raise HTTPException(status_code=500, detail={"success": False, "message": msg})

    app_state["current_status_message"] = "Paso 3: Iniciando normalización de extensiones..."
    logger.info(app_state["current_status_message"])

    try:
        # Importar la función de normalización
        from core_logic.extension_normalizer import execute_normalization_process

        # Obtener lista de carpetas (EAN_HIJO) del mapeo
        folder_list = list(app_state["sku_ean_map_for_verification"].values())

        # Ejecutar normalización
        normalization_results = execute_normalization_process(
            base_folder_path=app_state["download_base_path"],
            folder_list=folder_list
        )

        app_state["step3_completed"] = True
        app_state["step3_verified"] = True  # Auto-verificado al completarse

        app_state["last_error_message"] = None
        app_state["current_status_message"] = f"Paso 3 (Normalización) completado. {normalization_results.get('message', '')}"
        logger.info(app_state["current_status_message"])

        return JSONResponse(content={
            "success": True,
            "message": app_state["current_status_message"],
            "details": normalization_results
        })

    except Exception as e:
        app_state["step3_completed"] = False
        app_state["last_error_message"] = f"Error en Paso 3 (Normalización): {e}"
        app_state["current_status_message"] = app_state["last_error_message"]
        logger.exception("Excepción en start_step3_normalize_extensions:")
        raise HTTPException(status_code=500, detail={
            "success": False,
            "message": app_state["current_status_message"]
        })


@router.get('/api/verify_step3')
async def verify_step3_normalization():
    """
    Verifica si el Paso 3 (Normalización de Extensiones) ya fue completado.

    Revisa que todos los archivos en las carpetas tengan extensiones válidas
    y que no haya archivos sin extensión o con extensiones incorrectas.
    """
    if not app_state["download_base_path"] or app_state["sku_ean_map_for_verification"] is None:
        msg = "Datos internos (ruta de descarga o mapa SKU-EAN) no disponibles para verificación del Paso 3."
        logger.error(msg)
        raise HTTPException(status_code=500, detail={"success": False, "verified": False, "message": msg})

    app_state["current_status_message"] = "Paso 3: Verificando normalización de extensiones..."
    logger.info(app_state["current_status_message"])

    try:
        from core_logic.extension_normalizer import _should_normalize_to_webp

        base_path = app_state["download_base_path"]
        ean_folders = set(app_state["sku_ean_map_for_verification"].values())

        files_needing_normalization = 0
        total_files_checked = 0

        # Recorrer todas las carpetas EAN
        for ean_folder in ean_folders:
            folder_path = os.path.join(base_path, ean_folder)

            if not os.path.exists(folder_path):
                continue

            # Obtener todos los archivos en la carpeta
            for filename in os.listdir(folder_path):
                file_path = os.path.join(folder_path, filename)

                if not os.path.isfile(file_path):
                    continue

                total_files_checked += 1

                # Verificar si el archivo necesita normalización
                if _should_normalize_to_webp(filename):
                    files_needing_normalization += 1

        if files_needing_normalization == 0 and total_files_checked > 0:
            app_state["step3_completed"] = True  # Marcar como completado si la verificación es exitosa
            app_state["step3_verified"] = True
            app_state["last_error_message"] = None
            app_state["current_status_message"] = f"Paso 3 verificado: Todas las {total_files_checked} extensiones están normalizadas correctamente."
            logger.info(app_state["current_status_message"])
            return JSONResponse(content={
                "success": True,
                "verified": True,
                "message": app_state["current_status_message"],
                "total_files_checked": total_files_checked
            })
        elif total_files_checked == 0:
            msg = "Verificación Paso 3: No se encontraron archivos para verificar. Asegúrese de que los pasos anteriores estén completos."
            app_state["step3_verified"] = False
            app_state["last_error_message"] = msg
            logger.warning(msg)
            return JSONResponse(content={
                "success": True,
                "verified": False,
                "message": msg
            })
        else:
            app_state["step3_verified"] = False
            msg = f"Verificación Paso 3: Se encontraron {files_needing_normalization} de {total_files_checked} archivos que requieren normalización."
            app_state["last_error_message"] = msg
            app_state["current_status_message"] = msg
            logger.warning(msg)
            return JSONResponse(content={
                "success": True,
                "verified": False,
                "message": msg,
                "files_needing_normalization": files_needing_normalization,
                "total_files_checked": total_files_checked
            })

    except Exception as e:
        app_state["step3_verified"] = False
        app_state["last_error_message"] = f"Error durante la verificación del Paso 3: {e}"
        app_state["current_status_message"] = app_state["last_error_message"]
        logger.exception("Excepción en verify_step3_normalization:")
        raise HTTPException(status_code=500, detail={"success": False, "verified": False, "message": app_state["current_status_message"]})


# --- PASO 4: Renombrar Imágenes Internas (antes Paso 3) ---
@router.post('/api/start_step4_rename_images')
async def start_step4_internal_image_renaming():
    if not app_state["step3_verified"]:
        msg = "Error: Paso 3 no verificado. No se puede iniciar el renombrado de imágenes internas."
        logger.warning(msg)
        raise HTTPException(status_code=400, detail={"success": False, "message": msg})

    if not app_state["download_base_path"] or app_state["sku_ean_map_for_verification"] is None:
        msg = "Datos internos (ruta de descarga o mapa SKU-EAN) no disponibles para Paso 4."
        logger.error(msg)
        raise HTTPException(status_code=500, detail={"success": False, "message": msg})

    app_state["current_status_message"] = "Paso 4: Iniciando renombrado de imágenes internas..."
    logger.info(app_state["current_status_message"])

    try:
        # Aquí pasamos el name_mapping a tu función execute_internal_image_renaming
        renaming_results = execute_internal_image_renaming(
            base_directory_path=app_state["download_base_path"],
            name_mapping=app_state["sku_ean_map_for_verification"]
        )

        app_state["step4_completed"] = True

        app_state["last_error_message"] = None
        app_state["current_status_message"] = f"Paso 4 (Ren. Imágenes) completado. {renaming_results.get('message', '')}"
        logger.info(app_state["current_status_message"])
        return JSONResponse(content={"success": True, "message": app_state["current_status_message"], "details": renaming_results})

    except Exception as e:
        app_state["step4_completed"] = True
        app_state["last_error_message"] = f"Error crítico e inesperado en Paso 4 (Ren. Imágenes): {e}"
        app_state["current_status_message"] = app_state["last_error_message"]
        logger.exception("Excepción crítica en start_step4_internal_image_renaming:")
        raise HTTPException(status_code=500, detail={"success": False, "message": app_state["current_status_message"]})


@router.get('/api/verify_step4')
async def verify_step4_image_renaming():
    """
    Verifica si el Paso 4 (Renombrado de Imágenes) ya fue completado.

    Revisa que todos los archivos de imagen tengan nombres basados en EAN
    y no en SKU o nombres genéricos (image, full_image, etc.).
    """
    if not app_state["download_base_path"] or app_state["sku_ean_map_for_verification"] is None:
        msg = "Datos internos (ruta de descarga o mapa SKU-EAN) no disponibles para verificación del Paso 4."
        logger.error(msg)
        raise HTTPException(status_code=500, detail={"success": False, "verified": False, "message": msg})

    app_state["current_status_message"] = "Paso 4: Verificando renombrado de imágenes..."
    logger.info(app_state["current_status_message"])

    try:
        from core_logic.image_renamer import _calculate_new_image_name
        import re

        base_path = app_state["download_base_path"]
        ean_folders = app_state["sku_ean_map_for_verification"].values()

        # Crear mapa invertido EAN -> SKU
        ean_to_sku = {v: k for k, v in app_state["sku_ean_map_for_verification"].items()}

        files_needing_rename = 0
        total_images_checked = 0
        issues_found = []

        IMAGE_RE = re.compile(r"^(image)(\d+)", re.IGNORECASE)

        # Recorrer todas las carpetas EAN
        for ean_folder in ean_folders:
            folder_path = os.path.join(base_path, ean_folder)

            if not os.path.exists(folder_path):
                continue

            original_sku = ean_to_sku.get(ean_folder)

            # Obtener todos los archivos de imagen en la carpeta
            for filename in os.listdir(folder_path):
                file_path = os.path.join(folder_path, filename)

                if not os.path.isfile(file_path):
                    continue

                # Solo verificar archivos de imagen
                ext = os.path.splitext(filename)[1].lower()
                if ext not in {'.jpg', '.jpeg', '.png', '.webp'}:
                    continue

                total_images_checked += 1
                base_name = os.path.splitext(filename)[0]

                # Verificar si el nombre del archivo necesita ser renombrado
                # Un archivo NO necesita renombre si ya empieza con el nombre de la carpeta EAN
                already_correct = (filename.startswith(f"{ean_folder}_") or filename.startswith(f"{ean_folder}-"))

                # Verificar si es un archivo que PUEDE ser renombrado
                can_be_renamed = False

                # 1. Archivos basados en SKU original
                if original_sku and (filename.startswith(f"{original_sku}_") or filename.startswith(f"{original_sku}-")):
                    can_be_renamed = True

                # 2. Archivos con patrón "full_image"
                elif base_name.lower().startswith("full_image"):
                    can_be_renamed = True

                # 3. Archivos con patrón "image<NUM>"
                elif IMAGE_RE.match(base_name.lower()):
                    can_be_renamed = True

                # 4. Archivos con números largos (EAN/SKU) con sufijo (ej: "2000406500171_2.webp")
                else:
                    ean_pattern = re.compile(r'^(\d{10,})([_-])(.+)$')
                    match_ean = ean_pattern.match(base_name)
                    if match_ean:
                        ean_number = match_ean.group(1)
                        # Solo necesita renombre si el EAN no coincide con la carpeta
                        if ean_number != ean_folder:
                            can_be_renamed = True

                # 5. Archivos con solo número largo sin sufijo (ej: "2000406500171.webp")
                if not can_be_renamed:
                    solo_number_pattern = re.compile(r'^(\d{10,})$')
                    match_solo = solo_number_pattern.match(base_name)
                    if match_solo:
                        ean_number = match_solo.group(1)
                        # Solo necesita renombre si el número no coincide con la carpeta
                        if ean_number != ean_folder:
                            can_be_renamed = True

                # Si el archivo puede ser renombrado pero aún no tiene el nombre correcto
                if can_be_renamed and not already_correct:
                    files_needing_rename += 1
                    issues_found.append(f"{ean_folder}/{filename}")

        if files_needing_rename == 0 and total_images_checked > 0:
            app_state["step4_completed"] = True
            app_state["last_error_message"] = None
            app_state["current_status_message"] = f"Paso 4 verificado: Todas las {total_images_checked} imágenes están correctamente nombradas."
            logger.info(app_state["current_status_message"])
            return JSONResponse(content={
                "success": True,
                "verified": True,
                "message": app_state["current_status_message"],
                "total_images_checked": total_images_checked
            })
        elif total_images_checked == 0:
            msg = "Verificación Paso 4: No se encontraron imágenes para verificar. Asegúrese de que los pasos anteriores estén completos."
            app_state["step4_completed"] = False
            app_state["last_error_message"] = msg
            logger.warning(msg)
            return JSONResponse(content={
                "success": True,
                "verified": False,
                "message": msg
            })
        else:
            msg = f"Verificación Paso 4: Se encontraron {files_needing_rename} de {total_images_checked} imágenes que requieren renombrado."
            app_state["step4_completed"] = False
            app_state["last_error_message"] = msg
            app_state["current_status_message"] = msg
            logger.warning(msg)
            return JSONResponse(content={
                "success": True,
                "verified": False,
                "message": msg,
                "files_needing_rename": files_needing_rename,
                "total_images_checked": total_images_checked,
                "sample_issues": issues_found[:10]  # Mostrar solo 10 ejemplos
            })

    except Exception as e:
        app_state["step4_completed"] = False
        app_state["last_error_message"] = f"Error durante la verificación del Paso 4: {e}"
        app_state["current_status_message"] = app_state["last_error_message"]
        logger.exception("Excepción en verify_step4_image_renaming:")
        raise HTTPException(status_code=500, detail={"success": False, "verified": False, "message": app_state["current_status_message"]})


# --- Función para obtener el router configurado ---
def get_router():
    """Retorna el router configurado para flujo_productivo para integración con FlexStart"""
    return router