// frontend/js/app.js

// Variables globales
const API_BASE_URL = '/flujo_productivo/api';
let workingDirectory = null;
let currentStep = 1;
let processingEvents = [];

// Variables para control de proceso
let isDownloadRunning = false;
let totalSkusToProcess = 0;

// NUEVO: Variables para modo de operación
let operationMode = 'download';  // 'download' o 'local_copy'
let localSourcePath = null;

document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const newProjectButton = document.getElementById('new-project-button');
    const workingDirectoryDisplay = document.getElementById('working-directory-display');
    const workingDirectoryInfo = document.getElementById('working-directory-info');
    const excelFileInput = document.getElementById('excel-file-input');
    const uploadStatusDiv = document.getElementById('upload-status');
    
    // NUEVO: Elementos de selección de columnas
    const columnSelectionSection = document.getElementById('column-selection-section');
    const skuColumnSelect = document.getElementById('sku-column-select');
    const eanColumnSelect = document.getElementById('ean-column-select');
    const confirmColumnsButton = document.getElementById('confirm-columns-button');
    
    // NUEVO: Elementos de modo de operación
    const operationModeSelector = document.getElementById('operation-mode-selector');
    const operationModeRadios = document.querySelectorAll('input[name="operation-mode"]');
    const localSourcePathSection = document.getElementById('local-source-path-section');
    const localSourcePathInput = document.getElementById('local-source-path-input');
    const verifySourcePathButton = document.getElementById('verify-source-path-button');
    const sourcePathStatus = document.getElementById('source-path-status');
    const step1ButtonText = document.getElementById('step1-button-text');
    const stopButtonText = document.getElementById('stop-button-text');

    const startStep1Button = document.getElementById('start-step-1-button');
    const stopStep1Button = document.getElementById('stop-step-1-button');
    const step1StatusDiv = document.getElementById('step-1-status');

    const reverifyStep1Button = document.getElementById('reverify-step-1-button');
    const skipStep1Button = document.getElementById('skip-step-1-button');
    const reverifyStep1StatusDiv = document.getElementById('reverify-step-1-status');

    const downloadMissingReportButton = document.getElementById('download-missing-report-button');

    const startStep2Button = document.getElementById('start-step-2-button');
    const verifyStep2Button = document.getElementById('verify-step-2-button');
    const step2StatusDiv = document.getElementById('step-2-status');

    const startStep3Button = document.getElementById('start-step-3-button');
    const verifyStep3Button = document.getElementById('verify-step-3-button');
    const step3StatusDiv = document.getElementById('step-3-status');

    const startStep4Button = document.getElementById('start-step-4-button');
    const verifyStep4Button = document.getElementById('verify-step-4-button');
    const step4StatusDiv = document.getElementById('step-4-status');
    const finalSummaryDiv = document.getElementById('final-summary');

    const logOutputPre = document.getElementById('log-output');

    const stepSections = document.querySelectorAll('.step-section');
    const stepIndicators = document.querySelectorAll('.stepper .step');

    let currentStep = 1;
    let uploadedExcelFile = null;
    let expectedSkuFoldersForStep1 = [];
    let workingDirectory = '';

    // --- Utility Functions ---
    function logMessage(message, type = 'info') {
        const timestamp = new Date().toLocaleTimeString();
        const currentLog = logOutputPre.textContent;
        logOutputPre.textContent = `[${timestamp}] ${type.toUpperCase()}: ${message}\n` + currentLog;

        const lines = logOutputPre.textContent.split('\n');
        if (lines.length > 150) {
            logOutputPre.textContent = lines.slice(0, 150).join('\n');
        }
    }

    function setStatus(element, message, type = 'info') {
        if (!element) return;
        element.textContent = message;
        element.className = 'status-area';
        if (type) {
            element.classList.add(type);
        }
    }

    function updateUIStep(targetStep, forceCompleteCurrentStep = false) {
        currentStep = targetStep;
        stepIndicators.forEach(indicator => {
            const stepNum = parseInt(indicator.dataset.step, 10);
            indicator.classList.remove('active', 'completed');

            if (stepNum < currentStep) {
                indicator.classList.add('completed');
            } else if (stepNum === currentStep) {
                indicator.classList.add('active');
            }

            // Permitir forzar el completado del paso actual (para cualquier paso)
            if (stepNum === currentStep && forceCompleteCurrentStep) {
                indicator.classList.remove('active');
                indicator.classList.add('completed');
            }
        });

        stepSections.forEach(section => section.classList.remove('active-section'));
        const activeSection = document.getElementById(`step-${currentStep}-section`);
        if (activeSection) {
            activeSection.classList.add('active-section');
        }

        const hasLoadedExcel = expectedSkuFoldersForStep1.length > 0;
        const hasWorkingDirectory = workingDirectory && workingDirectory.trim();
        const isStep1Processing = step1StatusDiv.classList.contains('processing');
        const isStep1Verified = step1StatusDiv.classList.contains('success');
        const isStep2Processing = step2StatusDiv.classList.contains('processing');
        const isStep2Verified = step2StatusDiv.classList.contains('success');
        const isStep3Processing = step3StatusDiv.classList.contains('processing');
        const isStep3Verified = step3StatusDiv.classList.contains('success');
        const isStep4Processing = step4StatusDiv.classList.contains('processing');
        const isStep4SuccessfullyCompleted = step4StatusDiv.classList.contains('success');

        // Simplificado: solo deshabilitar durante procesamiento
        excelFileInput.disabled = isStep1Processing || isStep2Processing || isStep3Processing || isStep4Processing;
        newProjectButton.disabled = isStep1Processing || isStep2Processing || isStep3Processing || isStep4Processing;

        // NUEVO: Considerar modo de operación para habilitar botón del paso 1
        const canStartStep1 = currentStep === 1 && hasLoadedExcel && !isStep1Verified && !isStep1Processing;
        const hasRequiredSourceForLocalMode = operationMode === 'download' || (operationMode === 'local_copy' && localSourcePath !== null);
        startStep1Button.disabled = !(canStartStep1 && hasRequiredSourceForLocalMode);

        // --- LÓGICA MODIFICADA PARA EL BOTÓN DE VERIFICACIÓN ---
        // El botón de verificación manual debe estar disponible tan pronto como se cargue un Excel,
        // y solo debe ocultarse si el paso 1 ya ha sido verificado con éxito.
        if (currentStep === 1 && hasLoadedExcel && !isStep1Verified) {
            reverifyStep1Button.style.display = 'inline-block';
            reverifyStep1Button.disabled = isStep1Processing; // Deshabilitar solo si la descarga está en curso.

            // Mostrar botón de saltar paso 1 solo si hay Excel cargado
            if (skipStep1Button) {
                skipStep1Button.style.display = 'inline-block';
                skipStep1Button.disabled = isStep1Processing;
            }
        } else {
            reverifyStep1Button.style.display = 'none';
            if (skipStep1Button) {
                skipStep1Button.style.display = 'none';
            }
        }

        if(downloadMissingReportButton) {
            if (isStep1Verified || currentStep !== 1) {
                downloadMissingReportButton.style.display = 'none';
            }
        }

        startStep2Button.disabled = !(currentStep === 2 && isStep1Verified && !isStep2Processing);
        startStep3Button.disabled = !(currentStep === 3 && isStep2Verified && !isStep3Processing && !isStep3Verified);
        // MODIFICADO: Permitir repetir el Paso 4 siempre que estemos en el paso 4 y no esté procesando
        startStep4Button.disabled = !(currentStep === 4 && isStep3Verified && !isStep4Processing);

        // Mostrar botones de verificación cuando el Excel está cargado y estamos en el paso correspondiente
        if (verifyStep2Button) {
            if (currentStep >= 2 && hasLoadedExcel && !isStep2Verified) {
                verifyStep2Button.style.display = 'inline-block';
                verifyStep2Button.disabled = isStep2Processing;
            } else {
                verifyStep2Button.style.display = 'none';
            }
        }

        if (verifyStep3Button) {
            if (currentStep >= 3 && hasLoadedExcel && !isStep3Verified) {
                verifyStep3Button.style.display = 'inline-block';
                verifyStep3Button.disabled = isStep3Processing;
            } else {
                verifyStep3Button.style.display = 'none';
            }
        }

        if (verifyStep4Button) {
            if (currentStep >= 4 && hasLoadedExcel && !isStep4SuccessfullyCompleted) {
                verifyStep4Button.style.display = 'inline-block';
                verifyStep4Button.disabled = isStep4Processing;
            } else {
                verifyStep4Button.style.display = 'none';
            }
        }
    }

    async function handleApiResponse(response, stepName = "Acción") {
        try {
            // Verificar primero si la respuesta puede ser parseada como JSON
            const contentType = response.headers.get("content-type");
            if (!contentType || !contentType.includes("application/json")) {
                // No es JSON válido, crear respuesta de error basada en el status
                const errorMsg = `Error en ${stepName}. Código HTTP: ${response.status} - ${response.statusText || 'Error de servidor'}`;
                logMessage(errorMsg, 'error');
                throw new Error(errorMsg);
            }

            const data = await response.json();

            if (response.ok && data.success !== false) {
                logMessage(`${stepName}: ${data.message || 'Completado exitosamente.'}`);
                return data;
            } else {
                const errorMsg = data.message || `Error en ${stepName}. Código HTTP: ${response.status}`;
                logMessage(errorMsg, 'error');
                throw new Error(errorMsg);
            }
        } catch (jsonError) {
            // Si falla el parseo de JSON, crear mensaje de error más descriptivo
            if (jsonError.message.includes('Unexpected token') || jsonError.message.includes('JSON')) {
                const errorMsg = `Error de comunicación en ${stepName}. El servidor no respondió con datos válidos. Código HTTP: ${response.status}`;
                logMessage(errorMsg, 'error');
                throw new Error(errorMsg);
            } else {
                // Re-lanzar otros errores que ya tienen mensajes descriptivos
                throw jsonError;
            }
        }
    }

    // --- Event Listeners ---

    newProjectButton.addEventListener('click', async () => {
        logMessage("Reseteando aplicación...", 'warning');
        if (!confirm("¿Estás seguro de que deseas resetear la aplicación? Se perderá todo el progreso no guardado.")) {
            return;
        }

        try {
            const response = await fetch(`${API_BASE_URL}/new_project`, { method: 'POST' });
            const data = await handleApiResponse(response, "Reset");
            setStatus(uploadStatusDiv, data.message, 'info');
            resetUIState();
        } catch (error) {
            setStatus(uploadStatusDiv, `Error al resetear aplicación: ${error.message}`, 'error');
        }
    });

    function resetUIState() {
        logMessage("Interfaz de usuario reseteada.");
        excelFileInput.value = ''; // Limpiar el input de archivo
        uploadedExcelFile = null;
        workingDirectory = '';
        expectedSkuFoldersForStep1 = [];

        // Ocultar carpeta de procesamiento
        workingDirectoryDisplay.style.display = 'none';
        workingDirectoryInfo.textContent = '';
        
        // NUEVO: Ocultar sección de selección de columnas
        columnSelectionSection.style.display = 'none';
        window.currentFileInfo = null;
        
        // NUEVO: Resetear modo de operación
        operationMode = 'download';
        localSourcePath = null;
        operationModeSelector.style.display = 'none';
        localSourcePathSection.style.display = 'none';
        document.querySelector('input[name="operation-mode"][value="download"]').checked = true;
        localSourcePathInput.value = '';
        setStatus(sourcePathStatus, '', 'info');
        
        // Resetear texto del botón
        step1ButtonText.textContent = 'Iniciar Descarga de Imágenes';
        stopButtonText.textContent = 'Detener Descarga';

        // Limpiar todos los estados y mensajes
        setStatus(uploadStatusDiv, 'Selecciona un archivo Excel para comenzar.', 'info');
        setStatus(step1StatusDiv, '', 'info');
        setStatus(step2StatusDiv, '', 'info');
        setStatus(step3StatusDiv, '', 'info');
        if(finalSummaryDiv) setStatus(finalSummaryDiv, '', 'info');
        if(reverifyStep1StatusDiv) setStatus(reverifyStep1StatusDiv, '', 'info');
        if(downloadMissingReportButton) downloadMissingReportButton.style.display = 'none';
        if(reverifyStep1Button) reverifyStep1Button.style.display = 'none';

        updateUIStep(1);
    }
    
    // NUEVO: Event listeners para cambio de modo de operación
    operationModeRadios.forEach(radio => {
        radio.addEventListener('change', async (e) => {
            operationMode = e.target.value;
            logMessage(`Modo de operación cambiado a: ${operationMode === 'download' ? 'Descarga desde Internet' : 'Copiado Local'}`);
            
            // Mostrar/ocultar sección de ubicación de origen
            if (operationMode === 'local_copy') {
                localSourcePathSection.style.display = 'block';
                step1ButtonText.textContent = 'Copiar Archivos';
                stopButtonText.textContent = 'Detener Copiado';
            } else {
                localSourcePathSection.style.display = 'none';
                localSourcePath = null;
                step1ButtonText.textContent = 'Iniciar Descarga de Imágenes';
                stopButtonText.textContent = 'Detener Descarga';
            }
            
            // Enviar modo al backend
            try {
                const response = await fetch(`${API_BASE_URL}/set_operation_mode`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ mode: operationMode })
                });
                
                const data = await response.json();
                if (data.success) {
                    logMessage(data.message);
                }
            } catch (error) {
                logMessage(`Error al establecer modo: ${error.message}`, 'error');
            }
            
            updateUIStep(currentStep);
        });
    });
    
    // NUEVO: Event listener para verificar ubicación de origen
    verifySourcePathButton.addEventListener('click', async () => {
        const sourcePath = localSourcePathInput.value.trim();
        
        if (!sourcePath) {
            setStatus(sourcePathStatus, 'Por favor ingrese una ubicación válida.', 'error');
            return;
        }
        
        setStatus(sourcePathStatus, 'Verificando ubicación...', 'info');
        logMessage(`Verificando ubicación de origen: ${sourcePath}`);
        
        try {
            const response = await fetch(`${API_BASE_URL}/set_local_source_path`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ source_path: sourcePath })
            });
            
            const data = await response.json();
            
            if (data.valid && data.success) {
                localSourcePath = data.source_path;
                setStatus(sourcePathStatus, `✅ ${data.message}`, 'success');
                logMessage(`Ubicación de origen verificada: ${localSourcePath}`);
            } else {
                localSourcePath = null;
                setStatus(sourcePathStatus, `❌ ${data.message}`, 'error');
                logMessage(data.message, 'error');
            }
            
            updateUIStep(currentStep);
        } catch (error) {
            localSourcePath = null;
            setStatus(sourcePathStatus, `Error al verificar ubicación: ${error.message}`, 'error');
            logMessage(`Error al verificar ubicación: ${error.message}`, 'error');
        }
    });

    // Función para obtener la carpeta de un archivo (simulada - el navegador no permite acceso real al path)
    function getFileDirectory(file) {
        // En un navegador no podemos obtener la ruta real por seguridad
        // Retornamos un placeholder que indicará al backend usar la ubicación del archivo
        return "EXCEL_FILE_DIRECTORY";
    }

    excelFileInput.addEventListener('change', async (event) => {
        uploadedExcelFile = event.target.files[0];
        if (uploadedExcelFile) {
            setStatus(uploadStatusDiv, `Archivo seleccionado: ${uploadedExcelFile.name}`, 'info');
            logMessage(`Archivo seleccionado: ${uploadedExcelFile.name}`);

            // Solicitar al usuario la carpeta donde está el archivo Excel
            const userPath = prompt(
                `Por favor, ingresa la ruta donde está ubicado el archivo "${uploadedExcelFile.name}":\n\n` +
                `Puedes ingresar:\n` +
                `• Solo la carpeta: /Users/rjarad/Desktop/TEMP/test\n` +
                `• O la ruta completa: /Users/rjarad/Desktop/TEMP/test/archivo.xlsx\n\n` +
                `El sistema detectará automáticamente la carpeta.`
            );
            
            if (userPath && userPath.trim()) {
                let finalDirectory = userPath.trim();
                
                // Si la ruta incluye el nombre del archivo, extraer solo la carpeta
                if (finalDirectory.includes('.xlsx') || finalDirectory.includes('.xls')) {
                    // Extraer el directorio de la ruta completa del archivo
                    const lastSlash = finalDirectory.lastIndexOf('/');
                    if (lastSlash !== -1) {
                        finalDirectory = finalDirectory.substring(0, lastSlash);
                    }
                }
                
                workingDirectory = finalDirectory;
                
                // Mostrar información de carpeta
                workingDirectoryDisplay.style.display = 'block';
                workingDirectoryInfo.textContent = `Carpeta de procesamiento: ${workingDirectory}`;
                
                // Procesar automáticamente el archivo
                await processExcelFile();
            } else {
                // Usuario canceló o no ingresó carpeta
                excelFileInput.value = '';
                uploadedExcelFile = null;
                workingDirectory = '';
                setStatus(uploadStatusDiv, 'Debes especificar la carpeta donde está el archivo Excel.', 'warning');
            }
        } else {
            // Resetear cuando no hay archivo
            uploadedExcelFile = null;
            workingDirectory = '';
            expectedSkuFoldersForStep1 = [];
            workingDirectoryDisplay.style.display = 'none';
            workingDirectoryInfo.textContent = '';
            setStatus(uploadStatusDiv, 'Ningún archivo seleccionado.', 'info');
        }
        updateUIStep(currentStep);
    });

    // Función para verificar automáticamente todos los pasos y avanzar al primer paso pendiente
    async function autoVerifyAllSteps() {
        logMessage('Iniciando verificación automática de todos los pasos...', 'info');

        try {
            // Verificar Paso 1
            logMessage('Verificando Paso 1...', 'info');
            const step1Response = await fetch(`${API_BASE_URL}/verify_step1`);
            const step1Data = await step1Response.json();

            if (!step1Data.verified) {
                logMessage('Paso 1 no completado. Quédate en Paso 1.', 'warning');
                updateUIStep(1);
                return;
            }

            logMessage('✓ Paso 1 verificado', 'info');
            setStatus(step1StatusDiv, 'Paso 1 verificado: Todas las carpetas presentes', 'success');

            // Verificar Paso 2
            logMessage('Verificando Paso 2...', 'info');
            const step2Response = await fetch(`${API_BASE_URL}/verify_step2`);
            const step2Data = await step2Response.json();

            if (!step2Data.verified) {
                logMessage('Paso 2 no completado. Avanzando a Paso 2.', 'warning');
                updateUIStep(2);
                return;
            }

            logMessage('✓ Paso 2 verificado', 'info');
            setStatus(step2StatusDiv, 'Paso 2 verificado: Carpetas renombradas correctamente', 'success');

            // Verificar Paso 3
            logMessage('Verificando Paso 3...', 'info');
            const step3Response = await fetch(`${API_BASE_URL}/verify_step3`);
            const step3Data = await step3Response.json();

            if (!step3Data.verified) {
                logMessage('Paso 3 no completado. Avanzando a Paso 3.', 'warning');
                updateUIStep(3);
                return;
            }

            logMessage('✓ Paso 3 verificado', 'info');
            setStatus(step3StatusDiv, 'Paso 3 verificado: Extensiones normalizadas', 'success');

            // Verificar Paso 4
            logMessage('Verificando Paso 4...', 'info');
            const step4Response = await fetch(`${API_BASE_URL}/verify_step4`);
            const step4Data = await step4Response.json();

            if (!step4Data.verified) {
                logMessage('Paso 4 no completado. Avanzando a Paso 4.', 'warning');
                updateUIStep(4);
                return;
            }

            logMessage('✓ Paso 4 verificado - ¡Todos los pasos completados!', 'info');
            setStatus(step4StatusDiv, 'Paso 4 verificado: Todas las imágenes renombradas correctamente', 'success');
            updateUIStep(4);

        } catch (error) {
            logMessage(`Error durante verificación automática: ${error.message}`, 'error');
            // En caso de error, quedarse en Paso 1
            updateUIStep(1);
        }
    }

    // Nueva función para procesar automáticamente el archivo Excel
    async function processExcelFile() {
        if (!uploadedExcelFile) {
            setStatus(uploadStatusDiv, 'Error: No hay archivo seleccionado.', 'error');
            return;
        }

        const formData = new FormData();
        formData.append('file', uploadedExcelFile);

        // Enviar la carpeta real donde está el archivo Excel
        formData.append('working_directory', workingDirectory);
        logMessage(`Procesando archivo en: ${workingDirectory}`);

        setStatus(uploadStatusDiv, 'Procesando archivo Excel...', 'info');
        logMessage('Iniciando procesamiento automático de archivo Excel...');

        // Deshabilitar input durante procesamiento
        excelFileInput.disabled = true;
        if(reverifyStep1Button) reverifyStep1Button.disabled = true;

        try {
            const response = await fetch(`${API_BASE_URL}/upload_excel`, { method: 'POST', body: formData });
            const data = await response.json();

            if (data.success) {
                // Archivo procesado exitosamente
                setStatus(uploadStatusDiv, `${data.message} ✓ Listo para descargar imágenes.`, 'success');

                if (data.expected_sku_folders && Array.isArray(data.expected_sku_folders)) {
                    expectedSkuFoldersForStep1 = data.expected_sku_folders;
                    logMessage(`Se encontraron ${expectedSkuFoldersForStep1.length} SKUs para procesar.`);
                } else {
                    logMessage("Advertencia: No se recibió la lista de carpetas SKU esperadas del backend.", "warning");
                    expectedSkuFoldersForStep1 = [];
                }

                // Actualizar información de carpeta de trabajo
                if (data.working_directory) {
                    workingDirectoryInfo.textContent = `Carpeta de procesamiento: ${data.working_directory}`;
                    logMessage(`Procesamiento configurado en: ${data.working_directory}`);
                }

                // Ocultar sección de selección de columnas si estaba visible
                columnSelectionSection.style.display = 'none';
                
                // NUEVO: Mostrar selector de modo de operación
                operationModeSelector.style.display = 'block';
                logMessage('Seleccione el modo de operación para el Paso 1.');

                // NUEVO: Ejecutar verificación automática de todos los pasos
                logMessage('Ejecutando verificación automática de pasos previos...', 'info');
                await autoVerifyAllSteps();

            } else if (data.needs_column_selection) {
                // Necesita selección de columnas
                setStatus(uploadStatusDiv, data.message, 'warning');
                logMessage('Se requiere selección manual de columnas.', 'warning');

                // Mostrar sección de selección de columnas
                columnSelectionSection.style.display = 'block';

                // Poblar los dropdowns con las columnas disponibles y preseleccionar por defecto
                populateColumnSelectors(data.available_columns, data.default_sku_column, data.default_ean_column);

                // Guardar información para usar después
                window.currentFileInfo = {
                    filename: data.filename,
                    working_directory: data.working_directory
                };

            } else {
                // Error normal
                throw new Error(data.message);
            }
        } catch (error) {
            setStatus(uploadStatusDiv, `Error en procesamiento: ${error.message}`, 'error');
            expectedSkuFoldersForStep1 = [];

            // Si hay error de carpeta, resetear para permitir reintento
            if (error.message.includes('carpeta') || error.message.includes('directorio')) {
                excelFileInput.disabled = false;
                workingDirectoryDisplay.style.display = 'none';
                workingDirectoryInfo.textContent = '';
                logMessage('Error de carpeta: puedes intentar seleccionar el archivo nuevamente.', 'warning');
            }
        } finally {
            // No llamar updateUIStep aquí porque autoVerifyAllSteps ya lo hace
        }
    }

    startStep1Button.addEventListener('click', async () => {
        // Marcar que la descarga está en proceso
        isDownloadRunning = true;
        totalSkusToProcess = expectedSkuFoldersForStep1.length;

        // Actualizar UI
        setStatus(step1StatusDiv, 'Paso 1: Descargando imágenes...', 'info');
        step1StatusDiv.classList.add('processing');
        logMessage('Paso 1: Iniciando descarga de imágenes...');
        
        // Mostrar botón de detener, ocultar botón de iniciar
        startStep1Button.style.display = 'none';
        stopStep1Button.style.display = 'inline-block';
        
        if(downloadMissingReportButton) downloadMissingReportButton.style.display = 'none';
        if(reverifyStep1StatusDiv) setStatus(reverifyStep1StatusDiv, '', 'info');

        // Mostrar barra de progreso simple
        document.getElementById('progress-container').style.display = 'block';
        document.getElementById('progress-text').textContent = 'Iniciando descarga...';
        document.getElementById('progress-percentage').textContent = '0%';
        document.getElementById('progress-bar').style.width = '0%';
        
        // Iniciar polling de progreso
        startEventsPolling();

        updateUIStep(currentStep);

        try {
            // Iniciar descarga asíncrona
            const response = await fetch(`${API_BASE_URL}/start_step1_download`, { method: 'POST' });
            const data = await handleApiResponse(response, "Iniciar Descarga");

            if (data.success && data.details && data.details.background_process) {
                // Descarga iniciada en background exitosamente
                setStatus(step1StatusDiv, data.message, 'info');
                logMessage('Descarga iniciada en segundo plano. Monitoreando progreso...');

                // Iniciar monitoreo del progreso de la descarga asíncrona
                await monitorAsyncDownload();
            } else {
                // Error al iniciar la descarga
                setStatus(step1StatusDiv, data.message || 'Error al iniciar descarga', 'error');
                logMessage(`Error al iniciar descarga: ${data.message}`, 'error');
                throw new Error(data.message || 'Error al iniciar descarga');
            }

        } catch (error) {
            // Mejorar el manejo de errores de fetch/red
            let errorMessage = error.message;
            if (error.message === 'Failed to fetch' || error.message.includes('NetworkError') || error.message.includes('fetch')) {
                errorMessage = 'Error de conexión con el servidor. Verifique su conexión a internet y que el servidor esté funcionando.';
            } else if (error.message.includes('timeout')) {
                errorMessage = 'La solicitud tardó demasiado tiempo. El servidor puede estar ocupado, intente nuevamente.';
            }

            setStatus(step1StatusDiv, `Error al iniciar descarga: ${errorMessage}`, 'error');
            logMessage(`Error al iniciar descarga: ${errorMessage}`, 'error');

            // Limpiar estado de descarga en caso de error
            isDownloadRunning = false;
            step1StatusDiv.classList.remove('processing');
            startStep1Button.style.display = 'inline-block';
            stopStep1Button.style.display = 'none';
            stopEventsPolling();
            document.getElementById('progress-container').style.display = 'none';
            updateUIStep(currentStep);
        }
    });

    // NUEVO: Función para monitorear descarga asíncrona
    async function monitorAsyncDownload() {
        let downloadCompleted = false;
        let downloadWasSuccessful = false;

        // Asegurar que la barra de progreso se muestre desde el inicio
        document.getElementById('progress-container').style.display = 'block';
        document.getElementById('progress-text').textContent = 'Iniciando descarga...';
        document.getElementById('progress-percentage').textContent = '0%';
        document.getElementById('progress-bar').style.width = '0%';

        logMessage('Iniciando monitoreo de descarga asíncrona...', 'info');

        while (!downloadCompleted) {
            try {
                const response = await fetch(`${API_BASE_URL}/status`);
                if (!response.ok) {
                    await new Promise(resolve => setTimeout(resolve, 2000)); // Esperar 2 segundos antes de reintentar
                    continue;
                }

                const data = await response.json();

                // Actualizar progreso visual
                const processed = data.processed_skus || 0;
                const total = data.total_skus || totalSkusToProcess || 1; // Evitar división por 0

                const percentage = Math.round((processed / total) * 100);
                document.getElementById('progress-percentage').textContent = `${percentage}%`;
                document.getElementById('progress-bar').style.width = `${percentage}%`;

                // Actualizar texto de progreso basado en el estado
                if (data.download_completed) {
                    document.getElementById('progress-text').textContent = `Descarga completada: ${processed} productos procesados`;
                } else if (data.download_in_progress) {
                    document.getElementById('progress-text').textContent = `Procesando: ${processed} de ${total} productos`;
                } else if (data.total_skus > 0) {
                    document.getElementById('progress-text').textContent = `Preparando descarga de ${data.total_skus} productos...`;
                } else {
                    document.getElementById('progress-text').textContent = 'Iniciando descarga...';
                }

                // Log de progreso para debugging
                if (processed > 0 || data.download_in_progress) {
                    logMessage(`Progreso: ${processed}/${total} productos (${percentage}%)`, 'info');
                }

                // Verificar si la descarga ha terminado
                if (data.download_completed) {
                    downloadCompleted = true;

                    // DEBUG: Log para verificar que tenemos download_results
                    console.log("DEBUG - download_completed=true, download_results:", data.download_results);

                    // Procesar resultados
                    if (data.download_results) {
                        const results = data.download_results;

                        if (results.cancelled) {
                            const totalImages = results.details?.total_images_downloaded || 0;
                            const totalProducts = results.details?.total_items_processed || 0;
                            let message = results.message || 'Descarga cancelada';
                            if (totalImages > 0 && totalProducts > 0) {
                                message += ` (${totalImages} imágenes descargadas de ${totalProducts} productos antes de cancelar)`;
                            }
                            setStatus(step1StatusDiv, message, 'warning');
                            logMessage(`Descarga cancelada exitosamente. ${totalImages} imágenes descargadas.`, 'warning');
                            downloadWasSuccessful = false;
                        } else if (results.success) {
                            // Buscar en ambos lugares: nivel superior y details (para compatibilidad)
                            const totalImages = results.total_images_downloaded || results.details?.total_images_downloaded || 0;
                            const totalProducts = results.total_items_processed || results.details?.total_items_processed || 0;
                            if (totalImages > 0) {
                                setStatus(step1StatusDiv, `Descarga completada exitosamente: ${totalImages} imágenes descargadas de ${totalProducts} productos`, 'success');
                                downloadWasSuccessful = true;
                            } else {
                                setStatus(step1StatusDiv, `Descarga completada pero no se descargaron imágenes. Se procesaron ${totalProducts} productos. Revise que los SKUs sean válidos.`, 'warning');
                                downloadWasSuccessful = false;
                            }
                        } else {
                            setStatus(step1StatusDiv, `Error en descarga: ${results.message || 'Error desconocido'}`, 'error');
                            downloadWasSuccessful = false;
                        }
                    } else if (data.download_error) {
                        setStatus(step1StatusDiv, `Error en descarga: ${data.download_error}`, 'error');
                        downloadWasSuccessful = false;
                    } else {
                        // DEBUG: Fallback - no hay download_results ni download_error
                        console.log("DEBUG - Fallback: download_results=", data.download_results, "download_error=", data.download_error);

                        // Fallback si no hay resultados específicos
                        setStatus(step1StatusDiv, 'Descarga completada', 'info');
                        downloadWasSuccessful = false; // Conservador: no verificar automáticamente sin datos
                    }
                } else if (data.download_error && !data.download_in_progress) {
                    // Error sin que la descarga esté en progreso
                    downloadCompleted = true;
                    setStatus(step1StatusDiv, `Error en descarga: ${data.download_error}`, 'error');
                    downloadWasSuccessful = false;
                }

                // Si no ha terminado, esperar antes del siguiente chequeo
                if (!downloadCompleted) {
                    await new Promise(resolve => setTimeout(resolve, 2000)); // Esperar 2 segundos
                }

            } catch (error) {
                console.error('Error monitoreando descarga:', error);
                await new Promise(resolve => setTimeout(resolve, 3000)); // Esperar más tiempo en caso de error
            }
        }

        // Limpiar estado después de que la descarga termine
        isDownloadRunning = false;
        step1StatusDiv.classList.remove('processing');
        startStep1Button.style.display = 'inline-block';
        stopStep1Button.style.display = 'none';
        stopEventsPolling();
        document.getElementById('progress-container').style.display = 'none';

        // Ejecutar verificación si la descarga fue exitosa
        if (downloadWasSuccessful) {
            logMessage('Descarga exitosa. Verificando estado de verificación automática...');

            // Esperar un momento para que el backend complete la verificación automática
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Verificar si el backend ya completó la verificación automática
            try {
                const statusResponse = await fetch(`${API_BASE_URL}/status`);
                const statusData = await statusResponse.json();

                if (statusData.step1_verified) {
                    // El backend ya verificó automáticamente - actualizar UI
                    setStatus(step1StatusDiv, '✅ Verificación automática completada. Todas las carpetas verificadas. Paso 2 habilitado.', 'success');
                    logMessage('Verificación automática exitosa detectada.');
                    updateUIStep(2); // Habilitar paso 2
                } else {
                    // Ejecutar verificación manual si la automática no fue exitosa
                    logMessage('Verificación automática no completada. Ejecutando verificación manual...');
                    await verifyStep(1);
                }
            } catch (error) {
                // Si hay error al verificar el estado, ejecutar verificación manual
                logMessage('Error verificando estado. Ejecutando verificación manual...');
                await verifyStep(1);
            }
        } else {
            logMessage('Descarga no exitosa. Saltando verificación automática.', 'warning');
            updateUIStep(currentStep);
        }
    }

    // MEJORADO: Función para actualizar el visor de eventos con feedback detallado
    async function updateProgressBar() {
        try {
            const response = await fetch(`${API_BASE_URL}/processing_events`);
            
            if (!response.ok) {
                return; // Silently fail for progress updates
            }
            
            const data = await response.json();
            
            // Actualizar progreso simple
            const processed = data.processed_skus || 0;
            const total = data.total_skus || totalSkusToProcess;
            
            if (total > 0) {
                const percentage = Math.round((processed / total) * 100);
                document.getElementById('progress-percentage').textContent = `${percentage}%`;
                document.getElementById('progress-bar').style.width = `${percentage}%`;
                
                if (processed >= total) {
                    document.getElementById('progress-text').textContent = `Descarga completada: ${processed} productos procesados`;
                } else {
                    document.getElementById('progress-text').textContent = `Procesando: ${processed} de ${total} productos`;
                }
            }
            
        } catch (error) {
            // Silent fail for progress updates
            console.log('Progress update error:', error);
        }
    }

    // NUEVO: Actualizar eventos cada 2 segundos durante el procesamiento
    let eventsInterval = null;
    
    function startEventsPolling() {
        // Limpiar cualquier polling anterior
        if (eventsInterval) {
            clearInterval(eventsInterval);
        }
        eventsInterval = setInterval(updateProgressBar, 2000); // Actualizar cada 2 segundos
    }
    
    function stopEventsPolling() {
        if (eventsInterval) {
            clearInterval(eventsInterval);
            eventsInterval = null;
        }
    }

    // NUEVO: Event listener para botón de detener - Mejorado
    stopStep1Button.addEventListener('click', async () => {
        if (confirm('¿Estás seguro de que deseas detener la descarga? El progreso actual se perderá.')) {
            
            // NUEVO: Deshabilitar botón inmediatamente para evitar clics múltiples
            stopStep1Button.disabled = true;
            stopStep1Button.textContent = 'Cancelando...';
            
            logMessage('Usuario solicitó detener la descarga. Enviando señal de cancelación...', 'warning');
            setStatus(step1StatusDiv, 'Cancelando descarga, por favor espere...', 'warning');
            
            try {
                // Llamar al endpoint de cancelación
                const response = await fetch(`${API_BASE_URL}/cancel_download`, { method: 'POST' });
                const data = await response.json();
                
                if (data.success) {
                    setStatus(step1StatusDiv, 'Descarga cancelada por el usuario.', 'warning');
                    logMessage('Descarga cancelada exitosamente.', 'warning');
                    
                    // NUEVO: Esperar un poco para que el backend procese la cancelación
                    setTimeout(() => {
                        updateProgressBar(); // Actualización final del progreso
                    }, 1000);
                    
                } else {
                    setStatus(step1StatusDiv, 'Error al cancelar la descarga.', 'error');
                    
                    // Reactivar botón si falló la cancelación
                    stopStep1Button.disabled = false;
                    stopStep1Button.textContent = 'Detener Descarga';
                    return; // No continuar con la limpieza si falló
                }
            } catch (error) {
                setStatus(step1StatusDiv, 'Error de conexión al cancelar la descarga.', 'error');
                logMessage(`Error de conexión al cancelar descarga: ${error.message}`, 'error');
                
                // Reactivar botón si hubo error de conexión
                stopStep1Button.disabled = false;
                stopStep1Button.textContent = 'Detener Descarga';
                return; // No continuar con la limpieza si hubo error
            }
            
            // Limpiar estado SOLO si la cancelación fue exitosa
            isDownloadRunning = false;
            step1StatusDiv.classList.remove('processing');
            stopEventsPolling();
            startStep1Button.style.display = 'inline-block';
            stopStep1Button.style.display = 'none';
            stopStep1Button.disabled = false;
            stopStep1Button.textContent = 'Detener Descarga';
            
            // Ocultar barra de progreso al cancelar
            document.getElementById('progress-container').style.display = 'none';
            
            updateUIStep(currentStep);
        }
    });


    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function verifyStep(stepToVerify) {
        let verifyUrl = '';
        let statusDiv = null;
        let liveFeedbackDiv = (stepToVerify === 1) ? reverifyStep1StatusDiv : null;
        let stepName = '';

        if (stepToVerify === 1) {
            verifyUrl = `${API_BASE_URL}/verify_step1`;
            statusDiv = step1StatusDiv;
            stepName = 'Verificación Paso 1';
            if (reverifyStep1Button) reverifyStep1Button.disabled = true;
            if (downloadMissingReportButton) downloadMissingReportButton.style.display = 'none';

            // La barra de progreso se mantiene visible durante verificación
        } else if (stepToVerify === 2) {
            verifyUrl = `${API_BASE_URL}/verify_step2`;
            statusDiv = step2StatusDiv;
            stepName = 'Verificación Paso 2';
            if (verifyStep2Button) verifyStep2Button.disabled = true;
        } else if (stepToVerify === 3) {
            verifyUrl = `${API_BASE_URL}/verify_step3`;
            statusDiv = step3StatusDiv;
            stepName = 'Verificación Paso 3';
            if (verifyStep3Button) verifyStep3Button.disabled = true;
        } else if (stepToVerify === 4) {
            verifyUrl = `${API_BASE_URL}/verify_step4`;
            statusDiv = step4StatusDiv;
            stepName = 'Verificación Paso 4';
            if (verifyStep4Button) verifyStep4Button.disabled = true;
        } else {
            return;
        }

        if (liveFeedbackDiv) setStatus(liveFeedbackDiv, 'Iniciando verificación...', 'info');
        const mainStatusMsgPrefix = statusDiv.textContent.split(" :: ")[0];
        setStatus(statusDiv, `${mainStatusMsgPrefix} :: ${stepName}: Verificando...`, 'info');
        logMessage(`${stepName}: Iniciando...`);

        // Simulación visual de la verificación para el feedback del usuario
        if (stepToVerify === 1 && expectedSkuFoldersForStep1 && expectedSkuFoldersForStep1.length > 0) {
            if (liveFeedbackDiv) liveFeedbackDiv.innerHTML = '';
            for (let i = 0; i < expectedSkuFoldersForStep1.length; i++) {
                const sku = expectedSkuFoldersForStep1[i];
                if (i % 10 === 0) { // Actualiza el DOM no tan frecuentemente para no ralentizar
                    const checkingMsg = `Verificando carpeta para SKU: ${sku} (${i + 1} de ${expectedSkuFoldersForStep1.length})...`;
                    if (liveFeedbackDiv) {
                        const p = document.createElement('p');
                        p.textContent = checkingMsg;
                        liveFeedbackDiv.prepend(p);
                        while (liveFeedbackDiv.childElementCount > 10) {
                            liveFeedbackDiv.removeChild(liveFeedbackDiv.lastChild);
                        }
                    }
                    await sleep(1); // Pequeña pausa para permitir que la UI se actualice
                }
            }
            if (liveFeedbackDiv) {
                const allSkusCheckedMsg = `Revisión frontend completada. Esperando respuesta final del backend...`;
                const p = document.createElement('p');
                p.innerHTML = `<strong>${allSkusCheckedMsg}</strong>`;
                liveFeedbackDiv.prepend(p);
            }
        }

        try {
            const response = await fetch(verifyUrl);
            const data = await response.json();

            if (!response.ok && !data.message) {
                 throw new Error(`Error en ${stepName}. Código HTTP: ${response.status}`);
            }

            if (data.verified) {
                setStatus(statusDiv, `${data.message || stepName + ' verificada exitosamente.'}`, 'success');
                if(liveFeedbackDiv) setStatus(liveFeedbackDiv, 'Verificación completada con éxito por el backend.', 'success');
                logMessage(`${stepName} exitosa.`);
                if (downloadMissingReportButton && stepToVerify === 1) {
                    downloadMissingReportButton.style.display = 'none';
                }
                updateUIStep(currentStep + 1);
            } else {
                setStatus(statusDiv, `${data.message || stepName + ' falló la verificación.'}`, 'error');
                if(liveFeedbackDiv) setStatus(liveFeedbackDiv, 'Verificación backend reportó problemas.', 'error');
                logMessage(`${stepName} fallida: ${data.message}`, 'error');

                if (stepToVerify === 1 && data.report_available === true) {
                    if (downloadMissingReportButton) {
                        downloadMissingReportButton.style.display = 'inline-block';
                        downloadMissingReportButton.disabled = false;
                    }
                    logMessage(`Reporte de SKUs faltantes disponible (Faltantes: ${data.missing_count || 'N/A'}).`);
                } else if (downloadMissingReportButton && stepToVerify === 1) {
                    downloadMissingReportButton.style.display = 'none';
                }
            }
        } catch (error) {
            setStatus(statusDiv, `Error en ${stepName}: ${error.message}`, 'error');
            if(liveFeedbackDiv) setStatus(liveFeedbackDiv, `Error durante la verificación: ${error.message}`, 'error');
            logMessage(`Error en ${stepName}: ${error.message}`, 'error');
            if (downloadMissingReportButton && stepToVerify === 1) {
                 downloadMissingReportButton.style.display = 'none';
            }
        } finally {
            // NUEVO: Hacer una actualización final del visor de eventos para mostrar estado final
            if (stepToVerify === 1) {
                setTimeout(async () => {
                    await updateProgressBar();
                }, 500); // Pequeño delay para permitir que el backend procese
            }
            updateUIStep(currentStep);
        }
    }

    reverifyStep1Button.addEventListener('click', async () => {
        logMessage("Iniciando verificación manual del Paso 1...");
        if(reverifyStep1StatusDiv) {
            setStatus(reverifyStep1StatusDiv, 'Iniciando verificación de carpetas...', 'info');
            reverifyStep1StatusDiv.innerHTML = '';
        }
        if(downloadMissingReportButton) downloadMissingReportButton.style.display = 'none';
        await verifyStep(1);
    });

    // Event listener para saltar Paso 1
    if (skipStep1Button) {
        skipStep1Button.addEventListener('click', async () => {
            if (confirm('¿Estás seguro de que deseas saltar el Paso 1? Esto asumirá que las imágenes ya están descargadas y renombradas. Solo usa esta opción si ya completaste el Paso 2 (renombrado de carpetas).')) {
                logMessage("Usuario solicitó saltar Paso 1. Marcando paso como verificado...", 'warning');

                // Marcar paso 1 como completado y verificado
                setStatus(step1StatusDiv, '⚠️ Paso 1 saltado manualmente - Asumiendo imágenes ya descargadas', 'success');
                step1StatusDiv.classList.add('success');

                // Avanzar directamente al paso 2
                logMessage('Paso 1 saltado. Avanzando al Paso 2...', 'info');
                updateUIStep(2);

                // Limpiar mensajes previos
                if(reverifyStep1StatusDiv) {
                    reverifyStep1StatusDiv.innerHTML = '';
                }
                if(downloadMissingReportButton) {
                    downloadMissingReportButton.style.display = 'none';
                }
            }
        });
    }

    // Event listener para verificar Paso 2
    if (verifyStep2Button) {
        verifyStep2Button.addEventListener('click', async () => {
            logMessage("Iniciando verificación manual del Paso 2...");
            setStatus(step2StatusDiv, 'Verificando renombrado de carpetas...', 'info');
            await verifyStep(2);
        });
    }

    // Event listener para verificar Paso 3
    if (verifyStep3Button) {
        verifyStep3Button.addEventListener('click', async () => {
            logMessage("Iniciando verificación manual del Paso 3...");
            setStatus(step3StatusDiv, 'Verificando normalización de extensiones...', 'info');
            await verifyStep(3);
        });
    }

    // Event listener para verificar Paso 4
    if (verifyStep4Button) {
        verifyStep4Button.addEventListener('click', async () => {
            logMessage("Iniciando verificación manual del Paso 4...");
            setStatus(step4StatusDiv, 'Verificando renombrado de imágenes...', 'info');
            await verifyStep(4);
        });
    }

    if (downloadMissingReportButton) {
        downloadMissingReportButton.addEventListener('click', () => {
            logMessage("Solicitando descarga del reporte de SKUs faltantes...");
            window.location.href = `${API_BASE_URL}/download_missing_sku_report`;
        });
    }

    startStep2Button.addEventListener('click', async () => {
        setStatus(step2StatusDiv, 'Paso 2: Iniciando renombrado de carpetas...', 'info');
        step2StatusDiv.classList.add('processing');
        logMessage('Paso 2: Iniciando renombrado de carpetas...');
        updateUIStep(currentStep);

        try {
            const response = await fetch(`${API_BASE_URL}/start_step2_rename_folders`, { method: 'POST' });
            const data = await handleApiResponse(response, "Renombrado de Carpetas (Paso 2)");
            let messageType = data.success === false ? 'error' : 'info';
            setStatus(step2StatusDiv, data.message + (data.details ? ` (Renombradas: ${data.details.renamed_count}, Errores: ${data.details.error_count})` : ''), messageType);

        } catch (error) {
            setStatus(step2StatusDiv, `Error en Ren. Carpetas: ${error.message}`, 'error');
        } finally {
            step2StatusDiv.classList.remove('processing');
            await verifyStep(2);
        }
    });

    startStep3Button.addEventListener('click', async () => {
        setStatus(step3StatusDiv, 'Paso 3: Iniciando normalización de extensiones...', 'info');
        step3StatusDiv.classList.add('processing');
        logMessage('Paso 3: Iniciando normalización de extensiones...');
        updateUIStep(currentStep);

        try {
            const response = await fetch(`${API_BASE_URL}/start_step3_normalize_extensions`, { method: 'POST' });
            const data = await handleApiResponse(response, "Normalización de Extensiones (Paso 3)");
            setStatus(step3StatusDiv, data.message, 'success');

            if (data.details) {
                const details = data.details;
                let summaryHTML = `<strong>Resumen Paso 3 (Normalización):</strong><br>
                    Carpetas procesadas: ${details.processed_folders}/${details.total_folders}<br>
                    Archivos normalizados: ${details.total_normalized}<br>
                    Archivos sin cambios: ${details.total_skipped}`;

                if (details.total_errors > 0) {
                    summaryHTML += `<br><span style="color: #e74c3c;">Errores: ${details.total_errors}</span>`;
                }

                step3StatusDiv.innerHTML += `<div style="margin-top: 10px; padding: 10px; background-color: #f0f0f0; border-radius: 4px;">${summaryHTML}</div>`;
            }

            logMessage("Paso 3 (Normalización) completado. Avanzando al Paso 4...");

            // Avanzar al paso 4 después de completar exitosamente
            updateUIStep(4);

        } catch (error) {
            setStatus(step3StatusDiv, `Error en Normalización: ${error.message}`, 'error');
            step3StatusDiv.classList.remove('processing');
            updateUIStep(currentStep);
        } finally {
            step3StatusDiv.classList.remove('processing');
        }
    });

    startStep4Button.addEventListener('click', async () => {
        setStatus(step4StatusDiv, 'Paso 4: Iniciando renombrado de imágenes internas...', 'info');
        step4StatusDiv.classList.add('processing');
        logMessage('Paso 4: Iniciando renombrado de imágenes internas...');
        updateUIStep(currentStep);

        try {
            const response = await fetch(`${API_BASE_URL}/start_step4_rename_images`, { method: 'POST' });
            const data = await handleApiResponse(response, "Renombrado de Imágenes Internas (Paso 4)");

            // Mostrar mensaje según la cantidad de archivos renombrados
            const renamed = data.details?.renamed_files || 0;
            if (renamed > 0) {
                setStatus(step4StatusDiv, `${data.message} - Se renombraron ${renamed} archivos.`, 'success');
                logMessage(`Paso 4 completado: ${renamed} archivos renombrados.`);
            } else {
                setStatus(step4StatusDiv, `${data.message} - No se encontraron archivos para renombrar.`, 'success');
                logMessage("Paso 4 completado: Todos los archivos ya están correctamente nombrados.");
            }

            if (data.details) {
                finalSummaryDiv.innerHTML = `<strong>Resumen Final (Paso 4):</strong><br>
                    Archivos Procesados: ${data.details.processed_files}<br>
                    Renombrados: ${data.details.renamed_files}<br>
                    Omitidos/Ya Correctos: ${data.details.omitted_files}<br>
                    Conflictos/Errores: ${data.details.conflict_files}`;
                setStatus(finalSummaryDiv, '', 'info');
            }

            // Sugerencia para repetir si hubo archivos renombrados
            if (renamed > 0) {
                logMessage("💡 Puedes ejecutar el Paso 4 nuevamente si agregaste más imágenes.", 'info');
            }

        } catch (error) {
            setStatus(step4StatusDiv, `Error en Ren. Imágenes: ${error.message}`, 'error');
        } finally {
            step4StatusDiv.classList.remove('processing');
            // IMPORTANTE: Mantener en el paso 4, no avanzar
            updateUIStep(currentStep);
        }
    });

    // Mostrar instrucciones del script helper (solo si el elemento existe)
    const runHelperScriptButton = document.getElementById('run-helper-script');
    const helperInstructionsDiv = document.getElementById('helper-instructions');
    if (runHelperScriptButton && helperInstructionsDiv) {
        runHelperScriptButton.addEventListener('click', function() {
            helperInstructionsDiv.style.display = 'block';
            setStatus(uploadStatusDiv, 'Sigue las instrucciones para autocompletar la ruta usando el script.', 'info');
        });
    }

    // Initial UI setup
    resetUIState();

    // NUEVO: Función para poblar los dropdowns de selección de columnas
    function populateColumnSelectors(columns, defaultSkuColumn = null, defaultEanColumn = null) {
        // Limpiar opciones existentes (excepto la primera)
        skuColumnSelect.innerHTML = '<option value="">-- Seleccione una columna --</option>';
        eanColumnSelect.innerHTML = '<option value="">-- Seleccione una columna --</option>';

        // Agregar opciones de columnas
        columns.forEach(column => {
            const skuOption = document.createElement('option');
            skuOption.value = column;
            skuOption.textContent = column;
            skuColumnSelect.appendChild(skuOption);

            const eanOption = document.createElement('option');
            eanOption.value = column;
            eanOption.textContent = column;
            eanColumnSelect.appendChild(eanOption);
        });

        // NUEVO: Preseleccionar columnas por defecto si existen
        if (defaultSkuColumn && columns.includes(defaultSkuColumn)) {
            skuColumnSelect.value = defaultSkuColumn;
            logMessage(`Columna SKU preseleccionada: ${defaultSkuColumn}`, 'info');
        }

        if (defaultEanColumn && columns.includes(defaultEanColumn)) {
            eanColumnSelect.value = defaultEanColumn;
            logMessage(`Columna EAN preseleccionada: ${defaultEanColumn}`, 'info');
        }

        // Validar selección después de preseleccionar
        validateColumnSelection();

        logMessage(`Columnas disponibles en el Excel: ${columns.join(', ')}`);
    }

    // NUEVO: Función para validar selección de columnas
    function validateColumnSelection() {
        const skuColumn = skuColumnSelect.value;
        const eanColumn = eanColumnSelect.value;
        
        const isValid = skuColumn && eanColumn && skuColumn !== eanColumn;
        confirmColumnsButton.disabled = !isValid;
        
        if (skuColumn && eanColumn && skuColumn === eanColumn) {
            setStatus(uploadStatusDiv, 'Error: Debe seleccionar columnas diferentes para SKU y EAN.', 'error');
        } else if (isValid) {
            setStatus(uploadStatusDiv, `Columnas seleccionadas - SKU: "${skuColumn}", EAN: "${eanColumn}". Haga clic en "Confirmar Selección" para continuar.`, 'info');
        }
    }

    // NUEVO: Event listeners para la selección de columnas
    skuColumnSelect.addEventListener('change', validateColumnSelection);
    eanColumnSelect.addEventListener('change', validateColumnSelection);

    // NUEVO: Event listener para confirmar selección de columnas
    confirmColumnsButton.addEventListener('click', async () => {
        const skuColumn = skuColumnSelect.value;
        const eanColumn = eanColumnSelect.value;
        const fileInfo = window.currentFileInfo;
        
        if (!fileInfo) {
            setStatus(uploadStatusDiv, 'Error: Información del archivo no disponible. Intente cargar el archivo nuevamente.', 'error');
            return;
        }
        
        logMessage(`Confirmando selección - SKU: "${skuColumn}", EAN: "${eanColumn}"`);
        setStatus(uploadStatusDiv, 'Procesando selección de columnas...', 'info');
        confirmColumnsButton.disabled = true;
        
        try {
            const formData = new FormData();
            formData.append('sku_column', skuColumn);
            formData.append('ean_column', eanColumn);
            formData.append('filename', fileInfo.filename);
            
            const response = await fetch(`${API_BASE_URL}/confirm_column_selection`, {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.detail || `Error HTTP ${response.status}`);
            }
            
            if (data.success) {
                setStatus(uploadStatusDiv, `${data.message} ✓ Listo para descargar imágenes.`, 'success');

                // Actualizar datos para el procesamiento
                expectedSkuFoldersForStep1 = data.expected_sku_folders || [];
                logMessage(`Columnas confirmadas. Se encontraron ${expectedSkuFoldersForStep1.length} SKUs para procesar.`);

                // Actualizar información de carpeta de trabajo
                if (data.working_directory) {
                    workingDirectoryDisplay.style.display = 'block';
                    workingDirectoryInfo.textContent = `Carpeta de procesamiento: ${data.working_directory}`;
                    logMessage(`Procesamiento configurado en: ${data.working_directory}`);
                }

                // Ocultar sección de selección de columnas
                columnSelectionSection.style.display = 'none';
                
                // NUEVO: Mostrar selector de modo de operación
                operationModeSelector.style.display = 'block';
                logMessage('Seleccione el modo de operación para el Paso 1.');

                // NUEVO: Ejecutar verificación automática de todos los pasos
                logMessage('Ejecutando verificación automática de pasos previos...', 'info');
                await autoVerifyAllSteps();

            } else {
                throw new Error(data.message || 'Error desconocido al confirmar columnas');
            }
            
        } catch (error) {
            setStatus(uploadStatusDiv, `Error al confirmar selección: ${error.message}`, 'error');
            logMessage(`Error al confirmar columnas: ${error.message}`, 'error');
        } finally {
            confirmColumnsButton.disabled = false;
            updateUIStep(currentStep);
        }
    });

    // Los event listeners para workingDirectoryInput se han eliminado ya que ahora
    // la carpeta se establece automáticamente al seleccionar el archivo Excel
});