# backend/app.py - Router para integración con FlexStart

import os
import io
import asyncio
from fastapi import APIRouter, HTTPException, UploadFile, File, Form, BackgroundTasks
from fastapi.responses import FileResponse, StreamingResponse, JSONResponse
from pydantic import BaseModel
from typing import Optional
import pandas as pd
import logging

# --- Configuración del Logger ---
logger = logging.getLogger(__name__)

# --- Importación de Configuración ---
from .config import (
    PROCESS_FOLDER_NAME,
    ALLOWED_EXCEL_EXTENSIONS,
    MAX_PROCESSING_EVENTS,
    PROCESSED_EXCEL_SUFFIX,
    DOWNLOAD_TYPES
)

# Importación del modelo de estado independiente
from .models.app_state import DescargadorImagenesState

# --- Importación de Utilidades de Limpieza de Datos ---
from .utils.data_cleaning import clean_excel_column, clean_excel_value

# --- Importación de la Lógica de Negocio desde core_logic ---
try:
    from .core_logic.downloader import execute_download_process
    from .core_logic.folder_renamer import execute_folder_renaming
    from .core_logic.image_renamer import execute_internal_image_renaming
    from .core_logic.local_copier import execute_local_copy_process, LocalCopyCancelledException
    logger.info("Módulos de core_logic importados correctamente.")
except ImportError as e:
    logging.basicConfig(level=logging.ERROR)
    logger_init = logging.getLogger(__name__)
    logger_init.error(f"Error CRÍTICO al importar módulos de core_logic: {e}. "
                      "Asegúrate de que la carpeta 'core_logic' sea un subdirectorio de 'backend', "
                      "contenga un __init__.py (puede estar vacío), y que los módulos .py no tengan errores internos.")
    raise e

# --- Creación del Router para FlexStart ---
router = APIRouter(prefix="/descargador_imagenes", tags=["descargador_imagenes"])
logger.info("Router de Descargador de Imagenes creado para integración con FlexStart.")


# --- Configuración de Carpetas de la Aplicación ---
APP_PY_DIR = os.path.dirname(os.path.abspath(__file__)) # Directorio 'backend'
PROJECT_ROOT_DIR = os.path.dirname(APP_PY_DIR) # Raíz del proyecto
# Cambio #1: Usar la carpeta "Proceso" en la raíz del proyecto
PROCESS_FOLDER = os.path.join(PROJECT_ROOT_DIR, PROCESS_FOLDER_NAME)
ALLOWED_EXTENSIONS = ALLOWED_EXCEL_EXTENSIONS

try:
    os.makedirs(PROCESS_FOLDER, exist_ok=True)
    logger.info(f"Carpeta de proceso (base para cargas y descargas): {PROCESS_FOLDER}")
except OSError as e:
    logger.error(f"No se pudo crear la carpeta de proceso en {PROCESS_FOLDER}: {e}")


# --- Estado Global de la Aplicación ---
app_state = DescargadorImagenesState()


def _reset_app_state():
    """Resetea el estado de la aplicación a sus valores iniciales."""
    app_state.reset(PROCESSED_EXCEL_SUFFIX)
    logger.info("Estado de la aplicación reseteado.")


def _add_processing_event(event_type, message, sku=None, image_type=None, url=None):
    """Agrega un evento de procesamiento para mostrar en la UI con información detallada."""
    event = app_state.record_processing_event(
        event_type,
        message,
        sku=sku,
        image_type=image_type,
        url=url,
        max_events=MAX_PROCESSING_EVENTS
    )

    total_events = len(app_state.processing_events)
    logger.info(f"[EVENTO] {event['timestamp']} - {message}")
    logger.debug(f"[EVENTO DEBUG] Total eventos en memoria: {total_events}")


# === SUBFUNCIONES PARA VERIFICACIÓN DE CARPETAS (FASE 5) ===

def _validate_verification_preconditions() -> tuple[bool, Optional[str], set]:
    """
    Valida que existan los datos necesarios para verificar carpetas.

    Returns:
        Tupla (es_valido, mensaje_error, expected_folders_set)
    """
    if not app_state.get("download_base_path") or not app_state.get("sku_cl_list_for_verification"):
        return False, "No se puede verificar: faltan datos del Excel cargado", set()

    # MODIFICADO: Si la agrupación está activa, verificar solo representantes
    if app_state.get("group_by_parent_color", False) and app_state.get("representative_skus"):
        expected_folders = set(app_state["representative_skus"])
        logger.info(f"Verificación con agrupación activa: esperando {len(expected_folders)} representantes")
    else:
        expected_folders = set(app_state["sku_cl_list_for_verification"])

    if not os.path.exists(app_state["download_base_path"]):
        error_msg = f"El directorio de trabajo '{app_state['download_base_path']}' no existe."
        logger.error(error_msg)
        return False, error_msg, expected_folders

    return True, None, expected_folders


def _get_actual_folders_from_path(base_path: str) -> set:
    """
    Obtiene el conjunto de carpetas que realmente existen en el directorio base.
    
    Args:
        base_path: Ruta del directorio a escanear
        
    Returns:
        Set con los nombres de las carpetas encontradas
    """
    actual_folders_list = [
        d for d in os.listdir(base_path)
        if os.path.isdir(os.path.join(base_path, d))
    ]
    return set(actual_folders_list)


def _count_images_in_folders(base_path: str, folder_names: set) -> int:
    """
    Cuenta el total de imágenes en las carpetas especificadas.
    
    Args:
        base_path: Directorio base donde están las carpetas
        folder_names: Nombres de las carpetas a revisar
        
    Returns:
        Número total de imágenes encontradas
    """
    total_images = 0
    for folder_name in folder_names:
        folder_path = os.path.join(base_path, folder_name)
        if os.path.isdir(folder_path):
            image_files = [
                f for f in os.listdir(folder_path)
                if f.lower().endswith(('.jpg', '.jpeg', '.png', '.webp', '.gif'))
            ]
            total_images += len(image_files)
    return total_images


def _build_verification_success_message(
    mode: str,
    found_count: int,
    total_images: int,
    count_images: bool
) -> str:
    """
    Construye mensaje de éxito cuando todas las carpetas están presentes.

    Args:
        mode: 'auto' o 'manual'
        found_count: Número de carpetas encontradas
        total_images: Total de imágenes contadas (si count_images=True)
        count_images: Si se contaron imágenes

    Returns:
        Mensaje descriptivo del éxito
    """
    # Obtener información de agrupación
    skipped_by_grouping = len(app_state.get("skipped_by_grouping_skus", []))
    group_by_parent_color = app_state.get("group_by_parent_color", False)

    if mode == 'auto':
        download_results = app_state.get("download_results", {})
        reported_images = download_results.get('total_images_downloaded', 0)
        reported_items = download_results.get('total_items_processed', 0)

        actual_items = found_count if reported_items == 0 else reported_items
        actual_images = total_images if reported_images == 0 else reported_images

        message = f"¡Descarga exitosa! {actual_images} imágenes descargadas de {actual_items} productos. Todas las carpetas creadas."

        # Agregar información de agrupación si está activa
        if group_by_parent_color and skipped_by_grouping > 0:
            message += f" ({skipped_by_grouping} SKUs omitidos por agrupación padre+color)"

        message += " Paso 2 habilitado."
        return message
    else:  # manual
        message = f"✅ Reverificación exitosa! Todas las {found_count} carpetas encontradas."

        # Agregar información de agrupación si está activa
        if group_by_parent_color and skipped_by_grouping > 0:
            message += f" ({skipped_by_grouping} SKUs omitidos por agrupación)"

        message += " Paso 2 habilitado."
        return message


def _build_verification_failure_message(
    mode: str,
    found_count: int,
    missing_count: int,
    missing_folders: list,
    total_expected: int,
    actual_folders_count: int
) -> str:
    """
    Construye mensaje cuando faltan carpetas.

    Args:
        mode: 'auto' o 'manual'
        found_count: Carpetas encontradas
        missing_count: Carpetas faltantes
        missing_folders: Lista de nombres de carpetas faltantes
        total_expected: Total de carpetas esperadas
        actual_folders_count: Carpetas reales en el directorio

    Returns:
        Mensaje descriptivo de la falla
    """
    # Obtener información de agrupación
    skipped_by_grouping = len(app_state.get("skipped_by_grouping_skus", []))
    group_by_parent_color = app_state.get("group_by_parent_color", False)

    if mode == 'auto':
        download_results = app_state.get("download_results", {})
        total_images_dl = download_results.get('total_images_downloaded', 0)
        total_items_dl = download_results.get('total_items_processed', 0)

        if found_count > 0:
            message = f"Descarga parcial: {total_images_dl} imágenes descargadas de {total_items_dl} productos procesados. {found_count} carpetas creadas, {missing_count} productos sin imágenes."

            # Agregar información de agrupación
            if group_by_parent_color and skipped_by_grouping > 0:
                message += f" ({skipped_by_grouping} SKUs omitidos por agrupación)"

            message += " Reporte disponible."
            return message
        else:
            message = f"No se encontraron imágenes: {total_items_dl} productos procesados, pero no se crearon carpetas. {missing_count} productos fallidos."

            # Agregar información de agrupación
            if group_by_parent_color and skipped_by_grouping > 0:
                message += f" ({skipped_by_grouping} SKUs omitidos por agrupación)"

            message += " Reporte disponible."
            return message
    else:  # manual
        if found_count > 0:
            sample_missing = ', '.join(sorted(missing_folders)[:5])
            if missing_count > 5:
                sample_missing += '...'
            message = f"⚠️ Aún faltan imágenes: {found_count}/{total_expected} carpetas encontradas. Faltan {missing_count} productos: {sample_missing}."

            # Agregar información de agrupación
            if group_by_parent_color and skipped_by_grouping > 0:
                message += f" ({skipped_by_grouping} SKUs omitidos por agrupación)"

            message += " Agregue las imágenes manualmente y verifique nuevamente."
            return message
        else:
            if actual_folders_count > 0:
                return f"❌ Error de nombres: Se encontraron {actual_folders_count} carpetas, pero no coinciden con los SKUs del Excel. Verifique que los nombres de las carpetas coincidan exactamente con los SKUs."
            else:
                return f"❌ Sin imágenes: No se encontraron carpetas en '{app_state['download_base_path']}'. Agregue manualmente las carpetas con imágenes y verifique nuevamente."


def _unified_folder_verification(mode: str = 'manual', count_images: bool = False) -> dict:
    """
    Función unificada para verificar carpetas creadas vs SKUs esperados del Excel.

    Elimina la duplicación entre verificación automática (post-descarga)
    y verificación manual (usuario solicita).

    Args:
        mode: 'auto' (post-descarga) o 'manual' (usuario solicita explícitamente)
        count_images: Si True, cuenta imágenes reales en carpetas (solo para modo 'auto')

    Returns:
        dict con estructura:
        {
            "success": bool,  # True si la verificación se pudo ejecutar
            "verified": bool,  # True si todas las carpetas están presentes
            "found_count": int,
            "missing_count": int,
            "missing_list": list[str],
            "message": str,
            "report_available": bool,
            "total_images": int (solo si count_images=True)
        }
    """
    try:
        # Validar precondiciones
        is_valid, error_msg, expected_folders = _validate_verification_preconditions()
        
        if not is_valid:
            logger.warning(error_msg)
            if mode == 'auto':
                _add_processing_event("warning" if "faltan datos" in error_msg else "error", error_msg)
            
            return {
                "success": False,
                "verified": False,
                "found_count": 0,
                "missing_count": len(expected_folders),
                "missing_list": list(expected_folders),
                "message": error_msg,
                "report_available": False
            }

        # Obtener carpetas actuales del sistema de archivos
        base_path = app_state["download_base_path"]
        actual_folders = _get_actual_folders_from_path(base_path)

        # Calcular coincidencias y faltantes
        matching_folders = expected_folders.intersection(actual_folders)
        missing_folders = list(expected_folders - actual_folders)
        
        found_count = len(matching_folders)
        missing_count = len(missing_folders)
        total_expected = len(expected_folders)

        logger.info(f"Verificación {mode}: {found_count} encontradas, {missing_count} faltantes de {total_expected} totales")

        # Contar imágenes si se solicita
        total_images = 0
        if count_images and found_count > 0:
            total_images = _count_images_in_folders(base_path, matching_folders)

        # Determinar si verificación fue exitosa
        all_folders_present = missing_count == 0

        # Construir respuesta según resultado
        if all_folders_present:
            message = _build_verification_success_message(mode, found_count, total_images, count_images)
            
            return {
                "success": True,
                "verified": True,
                "found_count": found_count,
                "missing_count": 0,
                "missing_list": [],
                "message": message,
                "report_available": False,
                "total_images": total_images if count_images else 0
            }
        else:
            actual_folders_count = len(actual_folders)
            message = _build_verification_failure_message(
                mode, found_count, missing_count, missing_folders, 
                total_expected, actual_folders_count
            )
            
            return {
                "success": True,
                "verified": False,
                "found_count": found_count,
                "missing_count": missing_count,
                "missing_list": sorted(missing_folders),
                "message": message,
                "report_available": True,
                "total_images": total_images if count_images else 0
            }

    except Exception as e:
        error_msg = f"Error durante la verificación del Paso 1: {str(e)}"
        logger.exception(f"Excepción en _unified_folder_verification (mode={mode}): {e}")
        if mode == 'auto':
            _add_processing_event("error", f"Error en verificación automática: {str(e)}")

        return {
            "success": False,
            "verified": False,
            "found_count": 0,
            "missing_count": 0,
            "missing_list": [],
            "message": error_msg,
            "report_available": False
        }

# === SUBFUNCIONES PARA PROCESO DE DESCARGA (FASE 5) ===

def _handle_download_success(download_results: dict) -> None:
    """
    Maneja el estado después de una descarga exitosa.
    
    Args:
        download_results: Diccionario con resultados de la descarga
    """
    app_state["download_completed"] = True
    app_state.set_download_results(download_results)
    
    # Registrar resultados detallados para diagnóstico
    total_images = download_results.get('total_images_downloaded', 0)
    total_items = download_results.get('total_items_processed', 0)
    download_success = download_results.get("success", False)
    
    logger.info(f"Descarga completada - Success: {download_success}, Items: {total_items}, Images: {total_images}")
    logger.info(f"Download results completos: {download_results}")
    
    _add_processing_event("info", f"Descarga terminada: {total_images} imágenes de {total_items} productos. Ejecutando verificación automática...")
    
    # Ejecutar verificación automática
    logger.info("FORZANDO verificación automática inmediatamente...")
    try:
        _perform_automatic_verification()
    except Exception as e:
        logger.error(f"Error en verificación automática forzada: {e}")
        _add_processing_event("error", f"Error en verificación automática: {str(e)}")


def _handle_download_cancellation() -> None:
    """Maneja el estado después de una cancelación de descarga por el usuario."""
    app_state["download_completed"] = True
    app_state.set_download_results({
        "success": True,
        "message": "Descarga cancelada por el usuario.",
        "details": {
            "total_items_processed": app_state.get("processed_skus", 0),
            "total_images_downloaded": app_state.get("successful_downloads", 0)
        },
        "cancelled": True
    })
    app_state["current_status_message"] = "Descarga cancelada por el usuario."
    _add_processing_event("warning", app_state["current_status_message"])
    logger.info("Descarga en background cancelada por el usuario")


def _handle_download_error(error: Exception) -> None:
    """
    Maneja el estado después de un error en la descarga.
    
    Args:
        error: Excepción capturada durante la descarga
    """
    app_state["download_completed"] = True
    app_state["download_error"] = str(error)
    app_state["current_status_message"] = f"Error en descarga: {str(error)}"
    _add_processing_event("error", app_state["current_status_message"])
    logger.error(f"Error en descarga background: {error}", exc_info=True)


def _perform_automatic_verification():
    """
    Realiza verificación automática después de completar la descarga.
    Refactorizada para usar _unified_folder_verification().
    """
    _add_processing_event("info", "Ejecutando verificación automática de carpetas...")
    logger.info("Iniciando verificación automática post-descarga")

    # Llamar a la función unificada en modo automático con conteo de imágenes
    result = _unified_folder_verification(mode='auto', count_images=True)

    # Actualizar estado basado en resultado
    if result["success"]:
        if result["verified"]:
            # ✅ Todas las carpetas presentes
            app_state["last_error_message"] = None
            app_state["current_status_message"] = result["message"]
            _add_processing_event("success", result["message"])
            logger.info(f"Verificación automática exitosa")
        else:
            # ⚠️ Faltan carpetas - Generar reporte
            app_state["current_status_message"] = result["message"]
            app_state["last_error_message"] = result["message"]
            _add_processing_event("warning", result["message"])
            logger.warning(f"Verificación automática: descarga parcial - {result['missing_count']} productos faltantes")
    else:
        # ❌ Error en verificación
        app_state["last_error_message"] = result["message"]
        logger.error(f"Error en verificación automática: {result['message']}")

async def _background_download_process():
    """
    Ejecuta el proceso de descarga en background y actualiza el estado.
    
    Refactorizada en FASE 5 para mejor manejo de errores y legibilidad.
    """
    # Importar la excepción de cancelación
    try:
        from .core_logic.downloader import DownloadCancelledException
    except ImportError:
        from core_logic.downloader import DownloadCancelledException
    
    try:
        # Marcar que la descarga está en progreso
        app_state["download_in_progress"] = True
        app_state["download_completed"] = False
        app_state["download_error"] = None
        app_state.set_download_results(None)

        _add_processing_event("info", f"Iniciando descarga en background para {app_state['total_skus']} productos...")
        logger.info("Iniciando proceso de descarga en background")

        # Obtener el tipo de descarga seleccionado
        download_type = app_state.get("download_type", "both_fallback")
        
        # Ejecutar el proceso de descarga sincrónicamente en un hilo separado
        # para no bloquear el loop de eventos de asyncio
        loop = asyncio.get_event_loop()

        # Obtener configuración de agrupación
        group_by_parent_color = app_state.get("group_by_parent_color", False)

        # Log de configuración de descarga
        if group_by_parent_color:
            logger.info("Descarga con agrupación por padre+color ACTIVADA")

        download_results = await loop.run_in_executor(
            None,  # Usar el default ThreadPoolExecutor
            execute_download_process,
            app_state["excel_file_path"],
            "SKU_CL",
            app_state["download_base_path"],
            "CODDEPTO",
            download_type,
            app_state,
            _add_processing_event,
            group_by_parent_color  # NUEVO: Pasar parámetro de agrupación
        )

        # Manejar éxito de la descarga (usando subfunción)
        _handle_download_success(download_results)

    except DownloadCancelledException:
        # Descarga cancelada por el usuario (usando subfunción)
        _handle_download_cancellation()

    except Exception as e:
        # Error en la descarga (usando subfunción)
        _handle_download_error(e)

    finally:
        # Limpiar estado de progreso
        app_state["download_in_progress"] = False
        logger.info("Proceso de descarga background finalizado")


async def _background_local_copy_process():
    """
    Ejecuta el proceso de copiado local en background y actualiza el estado.
    """
    try:
        # Marcar que el copiado está en progreso
        app_state["download_in_progress"] = True
        app_state["download_completed"] = False
        app_state["download_error"] = None
        app_state.set_download_results(None)

        _add_processing_event("info", f"Iniciando copiado local para {app_state['total_skus']} carpetas...")
        logger.info("Iniciando proceso de copiado local en background")

        # Ejecutar el proceso de copiado sincrónicamente en un hilo separado
        loop = asyncio.get_event_loop()
        copy_results = await loop.run_in_executor(
            None,  # Usar el default ThreadPoolExecutor
            execute_local_copy_process,
            app_state["sku_cl_list_for_verification"],
            app_state["local_source_path"],
            app_state["download_base_path"],
            app_state,
            _add_processing_event
        )

        # Procesar resultados del copiado
        app_state["download_completed"] = True

        # Adaptar resultados al formato esperado por el frontend
        adapted_results = {
            "success": copy_results["success"],
            "message": copy_results["message"],
            "total_items_processed": copy_results["total_items_processed"],
            "total_images_downloaded": copy_results["total_files_copied"],
            "folders_found": copy_results["total_folders_found"],
            "folders_copied": copy_results["total_folders_copied"],
            "missing_folders": copy_results["missing_folders"],
            "performance": copy_results.get("performance", {})
        }

        app_state.set_download_results(adapted_results)

        # Registrar resultados con métricas de performance
        perf = copy_results.get("performance", {})
        logger.info(f"Copiado completado - Carpetas: {copy_results['total_folders_copied']}/{copy_results['total_items_processed']}, "
                   f"Archivos: {copy_results['total_files_copied']}")

        if perf:
            logger.info(f"Performance - Indexación: {perf.get('indexing_time', 0):.2f}s, "
                       f"Copiado: {perf.get('copy_time', 0):.2f}s, "
                       f"Total: {perf.get('total_time', 0):.2f}s")

            _add_processing_event(
                "info",
                f"📊 Copiado terminado: {copy_results['total_files_copied']} archivos de "
                f"{copy_results['total_folders_copied']} carpetas en {perf.get('total_time', 0):.1f}s. "
                f"Ejecutando verificación automática..."
            )
        else:
            _add_processing_event("info", f"Copiado terminado: {copy_results['total_files_copied']} archivos de "
                                f"{copy_results['total_folders_copied']} carpetas. Ejecutando verificación automática...")
        
        # Ejecutar verificación automática
        logger.info("FORZANDO verificación automática inmediatamente...")
        try:
            _perform_automatic_verification()
        except Exception as e:
            logger.error(f"Error en verificación automática forzada: {e}")
            _add_processing_event("error", f"Error en verificación automática: {str(e)}")

    except LocalCopyCancelledException:
        # Copiado cancelado por el usuario
        app_state["download_completed"] = True
        app_state.set_download_results({
            "success": True,
            "message": "Copiado cancelado por el usuario.",
            "details": {
                "total_items_processed": app_state.get("processed_skus", 0),
                "total_images_downloaded": app_state.get("successful_downloads", 0)
            },
            "cancelled": True
        })
        app_state["current_status_message"] = "Copiado cancelado por el usuario."
        _add_processing_event("warning", app_state["current_status_message"])
        logger.info("Copiado en background cancelado por el usuario")

    except Exception as e:
        # Error en el copiado
        app_state["download_completed"] = True
        app_state["download_error"] = str(e)
        app_state["current_status_message"] = f"Error en copiado: {str(e)}"
        _add_processing_event("error", app_state["current_status_message"])
        logger.error(f"Error en copiado background: {e}", exc_info=True)

    finally:
        # Limpiar estado de progreso
        app_state["download_in_progress"] = False
        logger.info("Proceso de copiado local background finalizado")

# --- Modelos Pydantic ---
class WorkingDirectoryRequest(BaseModel):
    directory: str

class StatusResponse(BaseModel):
    success: bool
    message: str
    valid: Optional[bool] = None
    directory: Optional[str] = None

def _secure_filename(filename):
    """Versión simplificada de secure_filename sin dependencia de werkzeug"""
    import re
    filename = str(filename).strip().replace(' ', '_')
    return re.sub(r'[^\w\-_\.]', '', filename)

def _is_allowed_file(filename):
    """Verifica si la extensión del archivo está permitida."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Función _clean_excel_string_column removida - ahora se usa clean_excel_column de utils.data_cleaning


# === SUBFUNCIONES PARA CARGA DE EXCEL (FASE 5) ===

def _validate_uploaded_file(file: UploadFile) -> tuple[bool, Optional[str]]:
    """
    Valida el archivo subido.
    
    Returns:
        Tupla (es_valido, mensaje_error)
    """
    if not file:
        return False, "No se encontró el archivo en la solicitud."
    
    if file.filename == '' or not file.filename:
        return False, "Ningún archivo seleccionado."
    
    if not _is_allowed_file(file.filename):
        return False, "Tipo de archivo no permitido. Solo se aceptan .xlsx o .xls."
    
    return True, None


async def _determine_and_save_excel_file(
    file: UploadFile, 
    working_directory: Optional[str],
    original_filename: str
) -> tuple[str, str]:
    """
    Determina el directorio de trabajo y guarda el archivo Excel si es necesario.
    
    Args:
        file: Archivo subido
        working_directory: Directorio especificado por el usuario (opcional)
        original_filename: Nombre del archivo seguro
        
    Returns:
        Tupla (excel_file_path, excel_directory)
        
    Raises:
        HTTPException: Si hay error al guardar o el directorio es inválido
    """
    working_directory = working_directory.strip() if working_directory else ''
    
    if working_directory:
        original_path = working_directory  # Guardar la ruta original para mensajes de error
        
        # Si la ruta incluye un archivo, extraer solo el directorio
        if working_directory.endswith(('.xlsx', '.xls')):
            working_directory = os.path.dirname(working_directory)
            logger.info(f"Ruta incluía archivo, extrayendo directorio: {working_directory}")
        
        # Validaciones mejoradas con mensajes descriptivos
        if not working_directory:
            error_msg = (
                f"❌ Ruta inválida: La ruta '{original_path}' está vacía o no es válida.\n\n"
                f"💡 Asegúrate de ingresar una ruta completa, por ejemplo:\n"
                f"   • /Users/tuusuario/Desktop/MiCarpeta\n"
                f"   • /Users/tuusuario/Documents/Proyecto"
            )
            logger.warning(f"Ruta vacía después de procesar: {original_path}")
            raise HTTPException(status_code=400, detail=error_msg)
        
        # Verificar si la ruta existe
        if not os.path.exists(working_directory):
            error_msg = (
                f"❌ Carpeta no encontrada: La ruta '{working_directory}' no existe en tu sistema.\n\n"
                f"💡 Posibles causas:\n"
                f"   • La carpeta fue eliminada o movida\n"
                f"   • Hay un error tipográfico en la ruta\n"
                f"   • La ruta es de otro sistema operativo\n\n"
                f"✓ Verifica que la carpeta existe antes de continuar."
            )
            logger.warning(f"Ruta no existe: {working_directory}")
            raise HTTPException(status_code=400, detail=error_msg)
        
        # Verificar que sea un directorio (no un archivo)
        if not os.path.isdir(working_directory):
            error_msg = (
                f"❌ No es una carpeta: La ruta '{working_directory}' existe pero no es una carpeta.\n\n"
                f"💡 Has especificado un archivo en lugar de una carpeta.\n"
                f"   • Si quieres usar la carpeta donde está el archivo, elimina el nombre del archivo de la ruta\n"
                f"   • Ejemplo: en lugar de '/ruta/archivo.xlsx', usa solo '/ruta/'"
            )
            logger.warning(f"Ruta no es un directorio: {working_directory}")
            raise HTTPException(status_code=400, detail=error_msg)
        
        # Verificar permisos de escritura
        if not os.access(working_directory, os.W_OK):
            error_msg = (
                f"❌ Sin permisos de escritura: No tienes permisos para guardar archivos en '{working_directory}'.\n\n"
                f"💡 Posibles soluciones:\n"
                f"   • Elige una carpeta donde tengas permisos de escritura\n"
                f"   • Verifica los permisos de la carpeta en tu sistema\n"
                f"   • Intenta con tu carpeta de Documentos o Escritorio"
            )
            logger.warning(f"Sin permisos de escritura: {working_directory}")
            raise HTTPException(status_code=403, detail=error_msg)
        
        # Todo OK - proceder con el guardado
        excel_directory = working_directory
        excel_file_path = os.path.join(working_directory, original_filename)
        logger.info(f"✓ Carpeta válida: {working_directory}")
        
        # Verificar si el archivo Excel ya existe en esa carpeta
        if os.path.exists(excel_file_path):
            logger.info(f"Archivo Excel ya existe en la carpeta: {excel_file_path}. Usando archivo existente.")
        else:
            # Solo guardar el archivo si NO existe en la carpeta especificada
            try:
                contents = await file.read()
                with open(excel_file_path, 'wb') as f:
                    f.write(contents)
                logger.info(f"✓ Archivo Excel guardado exitosamente: {excel_file_path}")
            except PermissionError as e:
                error_msg = (
                    f"❌ Error de permisos: No se pudo guardar el archivo en '{working_directory}'.\n\n"
                    f"💡 El sistema operativo bloqueó el acceso. Intenta con otra carpeta."
                )
                logger.error(f"PermissionError al guardar: {e}")
                raise HTTPException(status_code=403, detail=error_msg)
            except OSError as e:
                error_msg = (
                    f"❌ Error del sistema: No se pudo guardar el archivo.\n\n"
                    f"Detalles técnicos: {str(e)}\n\n"
                    f"💡 Posibles causas:\n"
                    f"   • Disco lleno\n"
                    f"   • Nombre de archivo inválido\n"
                    f"   • Problemas con el sistema de archivos"
                )
                logger.error(f"OSError al guardar: {e}")
                raise HTTPException(status_code=500, detail=error_msg)
            except Exception as e:
                error_msg = f"❌ Error inesperado al guardar el archivo: {str(e)}"
                logger.error(f"Error inesperado al guardar: {e}")
                raise HTTPException(status_code=500, detail=error_msg)
    else:
        # Fallback: usar PROCESS_FOLDER cuando no se especifica carpeta
        excel_directory = os.path.join(PROCESS_FOLDER, os.path.splitext(original_filename)[0])
        os.makedirs(excel_directory, exist_ok=True)
        excel_file_path = os.path.join(excel_directory, original_filename)
        logger.info(f"Fallback: usando carpeta de proceso: {excel_directory}")
        
        # Guardar el archivo en la carpeta de proceso
        try:
            contents = await file.read()
            with open(excel_file_path, 'wb') as f:
                f.write(contents)
            logger.info(f"Archivo Excel guardado en fallback: {excel_file_path}")
        except Exception as e:
            error_msg = f"Error al guardar el archivo Excel: {e}"
            logger.error(error_msg)
            raise HTTPException(status_code=500, detail=error_msg)
    
    return excel_file_path, excel_directory


def _detect_default_columns(df: pd.DataFrame) -> Optional[str]:
    """
    Detecta columna por defecto si existe (para preseleccionar en UI).
    
    Args:
        df: DataFrame de pandas con datos del Excel
        
    Returns:
        Nombre de la columna por defecto o None
    """
    default_sku_column = "SKU_CL" if "SKU_CL" in df.columns else None
    return default_sku_column


# --- Endpoint para servir el frontend ---
@router.get("/")
async def serve_index():
    frontend_dir = os.path.join(PROJECT_ROOT_DIR, 'frontend')
    index_path = os.path.join(frontend_dir, 'index.html')
    logger.info(f"Intentando servir index.html desde: {index_path}")
    if not os.path.exists(index_path):
        logger.error(f"index.html NO ENCONTRADO en {frontend_dir}")
        raise HTTPException(status_code=404, detail="Frontend index.html no encontrado.")
    return FileResponse(index_path)


# --- Rutas API de la aplicación ---
@router.get('/api/status')
async def get_application_status():
    logger.debug("Solicitud de estado recibida para /api/status")
    return JSONResponse(content=app_state.to_dict())

@router.get('/api/processing_events')
async def get_processing_events():
    """Obtiene los eventos de procesamiento en tiempo real con información detallada."""
    try:
        state_snapshot = app_state.to_dict()
        events = state_snapshot.get("processing_events", [])
        current_sku = state_snapshot.get("current_processing_sku")
        current_image_type = state_snapshot.get("current_image_type")
        current_url = state_snapshot.get("current_url")
        total_skus = state_snapshot.get("total_skus", 0)
        processed_skus = state_snapshot.get("processed_skus", 0)
        successful_downloads = state_snapshot.get("successful_downloads", 0)
        failed_downloads = state_snapshot.get("failed_downloads", 0)
        download_in_progress = state_snapshot.get("download_in_progress", False)
        download_completed = state_snapshot.get("download_completed", False)
        download_error = state_snapshot.get("download_error")
        download_results = state_snapshot.get("download_results")

        logger.debug(
            "Processing events request - events=%s current_sku=%s processed=%s/%s",
            len(events),
            current_sku,
            processed_skus,
            total_skus,
        )

        return JSONResponse(content={
            "events": events,
            "current_processing_sku": current_sku,
            "current_image_type": current_image_type,
            "current_url": current_url,
            "total_skus": total_skus,
            "processed_skus": processed_skus,
            "successful_downloads": successful_downloads,
            "failed_downloads": failed_downloads,
            "download_in_progress": download_in_progress,
            "download_completed": download_completed,
            "download_error": download_error,
            "download_results": download_results,
        })

    except Exception as e:
        logger.error(f"Error en get_processing_events: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "events": [],
                "current_processing_sku": None,
                "current_image_type": None,
                "current_url": None,
                "total_skus": 0,
                "processed_skus": 0,
                "successful_downloads": 0,
                "failed_downloads": 0,
                "error": f"Error del servidor: {str(e)}"
            })

@router.post('/api/cancel_download')
async def cancel_download():
    """Endpoint para cancelar la descarga en progreso inmediatamente."""
    app_state["should_cancel_download"] = True
    _add_processing_event("warning", "Cancelación solicitada por el usuario. Deteniendo descarga inmediatamente...")
    logger.info("Usuario solicitó cancelar la descarga. Flag de cancelación activado.")
    
    # Forzar cancelación inmediata cambiando el estado
    app_state["download_completed"] = True  # Marcar como "completado" para detener el proceso
    app_state["current_status_message"] = "Descarga cancelada por el usuario."
    
    return JSONResponse(content={
        "success": True,
        "message": "Descarga cancelada. Deteniendo proceso inmediatamente..."
    })

# --- NUEVO ENDPOINT PARA INICIAR UN NUEVO PROYECTO ---
@router.post('/api/new_project')
async def new_project():
    _reset_app_state()
    logger.info("Se ha iniciado un nuevo proyecto. El estado ha sido reseteado.")
    return JSONResponse(content={"success": True, "message": "Nuevo proyecto iniciado. Puede cargar un nuevo archivo Excel."})


@router.get('/api/download_types')
async def get_download_types():
    """Obtiene los tipos de descarga disponibles para que el usuario seleccione."""
    return JSONResponse(content={
        "success": True,
        "download_types": DOWNLOAD_TYPES
    })


@router.post('/api/set_download_type')
async def set_download_type(request_data: dict):
    """Establece el tipo de descarga seleccionado por el usuario."""
    download_type = request_data.get("download_type", "both_fallback")
    
    if download_type not in DOWNLOAD_TYPES:
        raise HTTPException(status_code=400, detail=f"Tipo de descarga inválido: {download_type}")
    
    app_state["download_type"] = download_type
    download_config = DOWNLOAD_TYPES[download_type]
    
    logger.info(f"Tipo de descarga establecido: {download_type}")
    
    return JSONResponse(content={
        "success": True,
        "message": f"Tipo de descarga establecido: {download_config['name']}",
        "download_type": download_type,
        "config": download_config
    })


# --- NUEVO ENDPOINT PARA ESTABLECER EL MODO DE OPERACIÓN ---
@router.post('/api/set_operation_mode')
async def set_operation_mode(request_data: dict):
    """Establece el modo de operación (download o local_copy)."""
    mode = request_data.get("mode", "download")

    if mode not in ["download", "local_copy"]:
        raise HTTPException(status_code=400, detail="Modo inválido. Debe ser 'download' o 'local_copy'.")

    app_state["operation_mode"] = mode
    logger.info(f"Modo de operación establecido: {mode}")

    # Si cambia a modo local_copy, deshabilitar agrupación (solo para descargas de internet)
    if mode == "local_copy" and app_state.get("group_by_parent_color", False):
        app_state["group_by_parent_color"] = False
        logger.info("Agrupación deshabilitada automáticamente (no disponible en modo local_copy)")

    return JSONResponse(content={
        "success": True,
        "message": f"Modo establecido: {'Descargar desde Internet' if mode == 'download' else 'Copiar desde Equipo Local'}",
        "mode": mode
    })


# --- ENDPOINT PARA ACTIVAR/DESACTIVAR AGRUPACIÓN POR PADRE+COLOR ---
@router.post('/api/set_grouping_mode')
async def set_grouping_mode(request_data: dict):
    """Activa o desactiva la agrupación por codskupadrelargo + color."""
    enabled = request_data.get("enabled", False)

    # Validar que solo esté disponible en modo download
    if enabled and app_state.get("operation_mode") == "local_copy":
        return JSONResponse(content={
            "success": False,
            "message": "La agrupación solo está disponible para descargas desde Internet"
        })

    # Validar que existan las columnas necesarias
    if enabled and not app_state.get("grouping_columns_available", False):
        return JSONResponse(content={
            "success": False,
            "message": "No se puede activar agrupación: faltan columnas 'color' y/o 'codskupadrelargo' en el Excel"
        })

    app_state["group_by_parent_color"] = enabled
    logger.info(f"Agrupación por padre+color {'ACTIVADA' if enabled else 'DESACTIVADA'}")

    message = "✓ Agrupación activada: se descargará solo un representante por grupo padre+color" if enabled else "Agrupación desactivada: se procesarán todos los SKUs individualmente"

    return JSONResponse(content={
        "success": True,
        "message": message,
        "enabled": enabled
    })


# --- NUEVO ENDPOINT PARA ESTABLECER UBICACIÓN DE ORIGEN (MODO LOCAL) ---
@router.post('/api/set_local_source_path')
async def set_local_source_path(request_data: dict):
    """Establece la ubicación de origen para el modo de copiado local."""
    source_path = request_data.get("source_path", "").strip()

    if not source_path:
        raise HTTPException(status_code=400, detail="La ruta de origen no puede estar vacía.")

    if not os.path.exists(source_path):
        return JSONResponse(content={
            "success": False,
            "message": f"La carpeta de origen no existe: {source_path}",
            "valid": False
        })

    if not os.path.isdir(source_path):
        return JSONResponse(content={
            "success": False,
            "message": f"La ruta especificada no es una carpeta válida: {source_path}",
            "valid": False
        })

    app_state["local_source_path"] = source_path
    logger.info(f"Ubicación de origen establecida: {source_path}")

    return JSONResponse(content={
        "success": True,
        "message": f"Ubicación de origen establecida: {source_path}",
        "valid": True,
        "source_path": source_path
    })


# --- NUEVO ENDPOINT PARA ESTABLECER RANGO CODDEPTO PERSONALIZADO ---
@router.post('/api/set_coddepto_range')
async def set_coddepto_range(request_data: dict):
    """Establece el rango personalizado de CODDEPTO para búsqueda exhaustiva (solo store_only)."""
    try:
        range_start = request_data.get("range_start")
        range_end = request_data.get("range_end")

        # Validar que ambos valores estén presentes
        if range_start is None or range_end is None:
            return JSONResponse(content={
                "success": False,
                "message": "Debe especificar tanto el inicio como el fin del rango"
            })

        # Convertir a enteros
        range_start = int(range_start)
        range_end = int(range_end)

        # Validar que sean valores positivos
        if range_start < 0 or range_end < 0:
            return JSONResponse(content={
                "success": False,
                "message": "Los valores del rango deben ser números positivos"
            })

        # Validar que el inicio sea menor o igual al fin
        if range_start > range_end:
            return JSONResponse(content={
                "success": False,
                "message": f"El valor inicial ({range_start}) debe ser menor o igual al valor final ({range_end})"
            })

        # Guardar en el estado
        app_state["coddepto_range_start"] = range_start
        app_state["coddepto_range_end"] = range_end

        logger.info(f"Rango CODDEPTO personalizado establecido: D{range_start}-D{range_end}")

        return JSONResponse(content={
            "success": True,
            "message": f"Rango CODDEPTO establecido: D{range_start} a D{range_end}",
            "range_start": range_start,
            "range_end": range_end
        })

    except ValueError:
        return JSONResponse(content={
            "success": False,
            "message": "Los valores del rango deben ser números enteros válidos"
        })


# --- NUEVO ENDPOINT PARA CARGAR PLANILLA DE CODDEPTOs PERSONALIZADOS ---
@router.post('/api/upload_coddepto_list')
async def upload_coddepto_list(file: UploadFile = File(...)):
    """Carga una planilla Excel con valores CODDEPTO específicos a probar."""
    try:
        # Validar que sea un archivo Excel
        if not file.filename.endswith(('.xlsx', '.xls')):
            return JSONResponse(content={
                "success": False,
                "message": "El archivo debe ser un Excel (.xlsx o .xls)"
            })

        # Leer el archivo Excel
        contents = await file.read()
        df = pd.read_excel(io.BytesIO(contents))

        logger.info(f"Planilla CODDEPTO cargada. Columnas: {list(df.columns)}, Filas: {len(df)}")

        # Intentar detectar la columna automáticamente
        coddepto_column = None
        for col in df.columns:
            col_upper = str(col).upper()
            if 'CODDEPTO' in col_upper or 'DEPTO' in col_upper or 'COD' in col_upper:
                coddepto_column = col
                break

        # Si no se detectó, usar la primera columna
        if coddepto_column is None:
            coddepto_column = df.columns[0]
            logger.info(f"No se detectó columna CODDEPTO automáticamente. Usando primera columna: '{coddepto_column}'")
        else:
            logger.info(f"Columna CODDEPTO detectada: '{coddepto_column}'")

        # Limpiar y extraer valores únicos
        coddepto_values = df[coddepto_column].dropna().astype(str).str.strip().unique().tolist()

        # Filtrar valores vacíos
        coddepto_values = [v for v in coddepto_values if v and v != '']

        if not coddepto_values:
            return JSONResponse(content={
                "success": False,
                "message": "La planilla no contiene valores CODDEPTO válidos"
            })

        # Normalizar formato: asegurar que tengan prefijo D si son números
        normalized_values = []
        for val in coddepto_values:
            val_clean = str(val).strip().upper()
            # Si es un número puro, agregar D
            if val_clean.isdigit():
                normalized_values.append(f"D{val_clean}")
            # Si ya tiene D, dejarlo como está
            elif val_clean.startswith('D') and val_clean[1:].isdigit():
                normalized_values.append(val_clean)
            # Otros formatos, dejarlo como está (para flexibilidad)
            else:
                normalized_values.append(val_clean)

        # Eliminar duplicados preservando orden
        seen = set()
        unique_values = []
        for val in normalized_values:
            if val not in seen:
                seen.add(val)
                unique_values.append(val)

        # Guardar en el estado
        app_state["coddepto_custom_list"] = unique_values

        logger.info(f"Lista CODDEPTO personalizada cargada: {len(unique_values)} valores únicos")
        logger.info(f"Primeros 10 valores: {unique_values[:10]}")

        return JSONResponse(content={
            "success": True,
            "message": f"✅ Planilla cargada: {len(unique_values)} valores CODDEPTO únicos",
            "count": len(unique_values),
            "preview": unique_values[:10],  # Mostrar los primeros 10 para verificación
            "column_used": coddepto_column
        })

    except Exception as e:
        logger.error(f"Error al cargar planilla CODDEPTO: {e}", exc_info=True)
        return JSONResponse(content={
            "success": False,
            "message": f"Error al procesar la planilla: {str(e)}"
        })


# --- NUEVO ENDPOINT PARA LIMPIAR LISTA DE CODDEPTOs ---
@router.post('/api/clear_coddepto_list')
async def clear_coddepto_list():
    """Limpia la lista personalizada de CODDEPTOs y vuelve al comportamiento por defecto."""
    app_state["coddepto_custom_list"] = None
    logger.info("Lista CODDEPTO personalizada limpiada")

    return JSONResponse(content={
        "success": True,
        "message": "✅ Lista CODDEPTO personalizada eliminada. Se usará rango por defecto."
    })


# --- NUEVO ENDPOINT PARA VERIFICAR CARPETA DE TRABAJO ---
@router.post('/api/verify_working_directory')
async def verify_working_directory(request_data: WorkingDirectoryRequest):
    """Verifica si una carpeta de trabajo es válida y tiene permisos de escritura."""
    directory = request_data.directory.strip()
    
    if not directory:
        raise HTTPException(status_code=400, detail="La carpeta de trabajo no puede estar vacía.")
    
    try:
        # Verificar si la carpeta existe
        if not os.path.exists(directory):
            return JSONResponse(content={
                "success": False, 
                "message": f"La carpeta '{directory}' no existe.",
                "valid": False
            })
        
        # Verificar si es un directorio
        if not os.path.isdir(directory):
            return JSONResponse(content={
                "success": False, 
                "message": f"'{directory}' no es una carpeta válida.",
                "valid": False
            })
        
        # Verificar permisos de escritura
        test_file = os.path.join(directory, '.test_write_permission')
        try:
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            writable = True
        except (OSError, IOError):
            writable = False
        
        if not writable:
            return JSONResponse(content={
                "success": False, 
                "message": f"No tienes permisos de escritura en la carpeta '{directory}'.",
                "valid": False
            })
        
        return JSONResponse(content={
            "success": True, 
            "message": f"Carpeta de trabajo válida: {directory}",
            "valid": True,
            "directory": directory
        })
        
    except Exception as e:
        logger.error(f"Error al verificar carpeta de trabajo '{directory}': {e}")
        raise HTTPException(status_code=500, detail=f"Error al verificar la carpeta de trabajo: {str(e)}")


@router.post('/api/confirm_column_selection')
async def confirm_column_selection(
    sku_column: str = Form(...),
    filename: str = Form(...),
    coddepto_column: Optional[str] = Form(None)
):
    """Endpoint para confirmar la selección de columna por parte del usuario."""
    if not app_state["excel_file_path"]:
        raise HTTPException(status_code=400, detail="No hay archivo Excel cargado")
    
    try:
        df = pd.read_excel(app_state["excel_file_path"])
        
        # Verificar que la columna SKU seleccionada exista
        if sku_column not in df.columns:
            raise HTTPException(status_code=400, detail=f"La columna SKU seleccionada '{sku_column}' no existe en el Excel")
        
        # Verificar columna CODDEPTO si fue seleccionada
        coddepto_processed = False
        if coddepto_column and coddepto_column.strip():
            if coddepto_column not in df.columns:
                raise HTTPException(status_code=400, detail=f"La columna CODDEPTO seleccionada '{coddepto_column}' no existe en el Excel")
            coddepto_processed = True
        
        # Renombrar las columnas para que el resto del sistema funcione
        rename_dict = {sku_column: "SKU_CL"}
        if coddepto_processed:
            rename_dict[coddepto_column] = "CODDEPTO"
        
        df = df.rename(columns=rename_dict)
        
        # Procesar la columna SKU usando función centralizada
        df["SKU_CL"] = clean_excel_column(df["SKU_CL"])
        
        # Procesar la columna CODDEPTO si existe
        if coddepto_processed:
            df["CODDEPTO"] = clean_excel_column(df["CODDEPTO"])

        # Verificar si existen columnas para agrupación por padre+color
        has_color = "color" in df.columns
        has_parent = "codskupadrelargo" in df.columns
        grouping_columns_available = has_color and has_parent

        if grouping_columns_available:
            logger.info("✓ Columnas 'color' y 'codskupadrelargo' detectadas: agrupación por padre+color disponible")
            app_state["grouping_columns_available"] = True
        else:
            logger.info("Columnas para agrupación no disponibles (requiere 'color' y 'codskupadrelargo')")
            app_state["grouping_columns_available"] = False
            # Si el toggle estaba habilitado, deshabilitarlo automáticamente
            if app_state.get("group_by_parent_color", False):
                logger.warning("Agrupación por padre+color deshabilitada: faltan columnas necesarias")
                app_state["group_by_parent_color"] = False

        # Guardar el DataFrame procesado como archivo temporal para el downloader
        processed_excel_path = app_state["excel_file_path"].replace('.xlsx', PROCESSED_EXCEL_SUFFIX)
        df.to_excel(processed_excel_path, index=False)
        logger.info(f"DataFrame procesado guardado en: {processed_excel_path}")

        # Actualizar la ruta del Excel para usar el archivo procesado
        app_state["excel_file_path"] = processed_excel_path

        # Actualizar el estado con los datos procesados
        # Obtener lista de SKUs únicos
        sku_list = df["SKU_CL"].dropna().unique().tolist()
        app_state["sku_cl_list_for_verification"] = sku_list
        # No necesitamos mapeo SKU-EAN para descargador de imágenes
        app_state["sku_ean_map_for_verification"] = {}

        # NUEVO: Calcular grupos y representantes si la agrupación está disponible
        if grouping_columns_available:
            # Construir diccionario de grupos
            groups = {}
            for idx, row in df.iterrows():
                sku = row["SKU_CL"]
                parent = clean_excel_value(row.get('codskupadrelargo', ''))
                color = clean_excel_value(row.get('color', ''))

                if parent and color:
                    group_key = (parent, color)
                    if group_key not in groups:
                        groups[group_key] = []
                    if sku not in groups[group_key]:
                        groups[group_key].append(sku)

            # Identificar representantes (primer SKU de cada grupo)
            representatives = []
            skipped = []

            for group_key, skus_in_group in groups.items():
                if len(skus_in_group) > 0:
                    # El primer SKU es el representante
                    representatives.append(skus_in_group[0])
                    # Los demás se omitirán
                    if len(skus_in_group) > 1:
                        skipped.extend(skus_in_group[1:])

            # SKUs que no pertenecen a ningún grupo también son "representantes" (se procesan siempre)
            all_grouped_skus = set()
            for skus_in_group in groups.values():
                all_grouped_skus.update(skus_in_group)

            ungrouped_skus = [sku for sku in sku_list if sku not in all_grouped_skus]
            representatives.extend(ungrouped_skus)

            # Guardar en el estado
            app_state["parent_color_groups"] = groups
            app_state["representative_skus"] = representatives
            app_state["skipped_by_grouping_skus"] = skipped

            logger.info(f"Grupos calculados: {len(groups)} grupos, {len(representatives)} representantes, {len(skipped)} SKUs a omitir")
        else:
            # Sin agrupación, todos son representantes
            app_state["parent_color_groups"] = {}
            app_state["representative_skus"] = sku_list.copy()
            app_state["skipped_by_grouping_skus"] = []

        logger.info(f"Columna SKU confirmada - '{sku_column}' -> SKU_CL")
        if coddepto_processed:
            logger.info(f"Columna CODDEPTO confirmada - '{coddepto_column}' -> CODDEPTO")
        logger.info(f"Identificadores únicos procesados: {len(app_state['sku_cl_list_for_verification'])}")
        
        status_msg = f"Archivo '{filename}' procesado exitosamente. Columna SKU: '{sku_column}'"
        if coddepto_processed:
            status_msg += f", CODDEPTO: '{coddepto_column}'"
        status_msg += ". Listo para iniciar descarga."
        
        app_state["current_status_message"] = status_msg

        selected_columns = {"sku_column": sku_column}
        if coddepto_processed:
            selected_columns["coddepto_column"] = coddepto_column

        # Mensaje sobre disponibilidad de agrupación
        grouping_message = None
        if grouping_columns_available:
            grouping_message = "✓ Agrupación por padre+color disponible"
        elif has_color or has_parent:
            missing = []
            if not has_color:
                missing.append("'color'")
            if not has_parent:
                missing.append("'codskupadrelargo'")
            grouping_message = f"⚠️ Agrupación no disponible: falta columna {' y '.join(missing)}"

        return JSONResponse(content={
            "success": True,
            "message": app_state["current_status_message"],
            "filename": filename,
            "expected_sku_folders": app_state["sku_cl_list_for_verification"],
            "working_directory": app_state["download_base_path"],
            "selected_columns": selected_columns,
            "grouping_columns_available": grouping_columns_available,
            "grouping_message": grouping_message
        })

    except Exception as e:
        error_msg = f"Error al procesar la columna seleccionada: {str(e)}"
        app_state["last_error_message"] = error_msg
        logger.error(error_msg)
        raise HTTPException(status_code=500, detail=error_msg)


@router.post('/api/upload_excel')
async def handle_excel_upload(
    file: UploadFile = File(...), 
    working_directory: Optional[str] = Form(None)
):
    """
    Maneja la carga de archivos Excel.
    
    Refactorizada en FASE 5 para mejor legibilidad usando subfunciones.
    """
    # Validar archivo subido
    is_valid, error_msg = _validate_uploaded_file(file)
    if not is_valid:
        app_state["last_error_message"] = error_msg
        logger.warning(error_msg)
        raise HTTPException(status_code=400, detail=error_msg)

    # Obtener nombre de archivo seguro
    original_filename = _secure_filename(file.filename)
    
    # Determinar directorio y guardar archivo
    try:
        excel_file_path, excel_directory = await _determine_and_save_excel_file(
            file, working_directory, original_filename
        )
    except HTTPException:
        raise  # Re-raise para que FastAPI lo maneje
    
    # Procesar Excel y preparar respuesta
    try:
        # Actualizar estado de la aplicación
        app_state["excel_file_path"] = excel_file_path
        app_state["excel_file_name"] = original_filename
        app_state["download_base_path"] = excel_directory
        
        logger.info(f"Archivo Excel '{original_filename}' procesado desde '{excel_file_path}'.")
        logger.info(f"Directorio de trabajo para esta sesión: '{excel_directory}'. Todo el procesamiento ocurrirá en esta carpeta.")

        # Leer Excel y obtener columnas disponibles
        df = pd.read_excel(excel_file_path)
        available_columns = df.columns.tolist()
        logger.info(f"Columnas disponibles en el Excel: {available_columns}")

        # Detectar columna por defecto para preseleccionar
        default_sku_column = _detect_default_columns(df)

        # Retornar respuesta para selección de columna
        selection_message = "Archivo Excel cargado exitosamente. Por favor seleccione la columna para procesamiento."
        logger.info("Mostrando selección de columna al usuario")

        return JSONResponse(
            status_code=200,
            content={
                "success": False,  # False para activar la UI de selección
                "message": selection_message,
                "available_columns": available_columns,
                "needs_column_selection": True,
                "filename": original_filename,
                "working_directory": excel_directory,
                "default_sku_column": default_sku_column
            }
        )

    except Exception as e:
        error_msg = f"Error al procesar el archivo Excel '{original_filename}': {e}"
        app_state["last_error_message"] = error_msg
        logger.exception("Excepción en handle_excel_upload:")
        raise HTTPException(status_code=500, detail=error_msg)


# --- Endpoint para verificar carpetas existentes antes de descargar ---
@router.post('/api/verify_existing_folders')
async def verify_existing_folders():
    """
    Verifica qué carpetas ya existen en la ubicación de destino antes de iniciar la descarga.
    Retorna información sobre carpetas existentes y nuevas.
    """
    try:
        # Verificar que tengamos los datos necesarios
        if not app_state.get("download_base_path"):
            raise HTTPException(status_code=400, detail="No se ha configurado la ubicación de descarga")
        
        if not app_state.get("sku_cl_list_for_verification"):
            raise HTTPException(status_code=400, detail="No se ha cargado la lista de SKUs del Excel")
        
        destination_folder = app_state["download_base_path"]
        sku_list = app_state["sku_cl_list_for_verification"]
        
        # Verificar qué carpetas ya existen
        existing_folders = []
        new_folders = []
        
        for sku in sku_list:
            folder_path = os.path.join(destination_folder, str(sku))
            if os.path.exists(folder_path) and os.path.isdir(folder_path):
                existing_folders.append(str(sku))
            else:
                new_folders.append(str(sku))
        
        total_count = len(sku_list)
        existing_count = len(existing_folders)
        new_count = len(new_folders)
        
        logger.info(f"Verificación previa: {total_count} total, {existing_count} existentes, {new_count} nuevos")
        
        return JSONResponse(content={
            "success": True,
            "has_existing": existing_count > 0,
            "total_count": total_count,
            "existing_count": existing_count,
            "new_count": new_count,
            "existing_folders": existing_folders[:50],  # Limitar a 50 para no sobrecargar
            "message": f"Verificación completada: {existing_count} carpetas existentes, {new_count} nuevas"
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error al verificar carpetas existentes: {e}")
        raise HTTPException(status_code=500, detail=f"Error al verificar carpetas: {str(e)}")


# --- PASO 1: Descarga de Imágenes / Copiado Local (VERSIÓN ASÍNCRONA) ---
@router.post('/api/start_step1_download')
async def start_step1_image_download(background_tasks: BackgroundTasks):
    # Validaciones previas
    if not app_state["excel_file_path"] or not app_state["download_base_path"]:
        msg = "Error: No se ha cargado un archivo Excel o la configuración de sesión es inválida."
        logger.error(msg)
        raise HTTPException(status_code=400, detail=msg)

    # Verificar que hay SKUs para procesar
    if not app_state["sku_cl_list_for_verification"] or len(app_state["sku_cl_list_for_verification"]) == 0:
        msg = "Error: El archivo Excel no contiene SKUs válidos para procesar. Verifique que la columna 'SKU_CL' tenga datos."
        logger.warning(msg)
        return JSONResponse(content={
            "success": False,
            "message": msg,
            "details": {"total_items_processed": 0, "total_images_downloaded": 0}
        })
    
    # Validación específica para modo local_copy
    operation_mode = app_state.get("operation_mode", "download")
    if operation_mode == "local_copy":
        if not app_state.get("local_source_path"):
            msg = "Error: Debe especificar la ubicación de origen para el modo de copiado local."
            logger.error(msg)
            raise HTTPException(status_code=400, detail=msg)
        
        if not os.path.exists(app_state["local_source_path"]):
            msg = f"Error: La ubicación de origen no existe: {app_state['local_source_path']}"
            logger.error(msg)
            raise HTTPException(status_code=400, detail=msg)

    # Verificar que no hay otra descarga/copiado en progreso
    if app_state["download_in_progress"]:
        action_name = "copiado" if operation_mode == "local_copy" else "descarga"
        msg = f"Ya hay un {action_name} en progreso. Espere a que termine o cancélelo antes de iniciar uno nuevo."
        logger.warning(msg)
        return JSONResponse(content={
            "success": False,
            "message": msg,
            "details": {"download_in_progress": True}
        })

    # Resetear estado para la nueva descarga/copiado
    app_state["should_cancel_download"] = False
    app_state["total_skus"] = len(app_state["sku_cl_list_for_verification"])
    app_state["processed_skus"] = 0
    app_state["successful_downloads"] = 0
    app_state["failed_downloads"] = 0
    app_state["processing_events"] = []
    app_state["download_in_progress"] = False
    app_state["download_completed"] = False
    app_state["download_error"] = None
    app_state.set_download_results(None)

    # Mensaje y proceso según el modo
    if operation_mode == "local_copy":
        app_state["current_status_message"] = f"Iniciando copiado local para {app_state['total_skus']} carpetas..."
        logger.info(app_state["current_status_message"])
        
        # Marcar que el copiado va a comenzar
        app_state["download_in_progress"] = True
        
        # Iniciar el proceso de copiado en background
        background_tasks.add_task(_background_local_copy_process)
        
        return JSONResponse(content={
            "success": True,
            "message": f"Copiado local iniciado para {app_state['total_skus']} carpetas. El progreso se mostrará automáticamente en pantalla.",
            "details": {
                "total_skus": app_state["total_skus"],
                "download_started": True,
                "background_process": True,
                "operation_mode": "local_copy"
            }
        })
    else:
        # Modo download (comportamiento original)
        app_state["current_status_message"] = f"Iniciando descarga de imágenes para {app_state['total_skus']} productos..."
        logger.info(app_state["current_status_message"])
        
        # Marcar que la descarga va a comenzar
        app_state["download_in_progress"] = True
        
        # Iniciar el proceso de descarga en background
        background_tasks.add_task(_background_download_process)
        
        return JSONResponse(content={
            "success": True,
            "message": f"Descarga iniciada exitosamente para {app_state['total_skus']} productos. El progreso se mostrará automáticamente en pantalla.",
            "details": {
                "total_skus": app_state["total_skus"],
                "download_started": True,
                "background_process": True,
                "operation_mode": "download"
            }
        })


@router.get('/api/verify_step1')
async def verify_step1_folder_creation():
    """
    Endpoint para verificación manual de carpetas (usuario hace clic en botón).
    Refactorizada para usar _unified_folder_verification().
    """
    # Verificar si tenemos la información necesaria (cargada desde el Excel)
    if not app_state["download_base_path"] or app_state["sku_cl_list_for_verification"] is None or not app_state["sku_cl_list_for_verification"]:
        msg = "No se ha cargado un archivo Excel o no contiene SKUs válidos para verificar."
        logger.warning(msg)
        raise HTTPException(status_code=400, detail={"success": False, "verified": False, "message": msg, "report_available": False})

    # Preparar para verificación
    app_state["current_status_message"] = "Reverificando carpetas manualmente..."
    logger.info("Usuario solicitó reverificación manual de carpetas")
    _add_processing_event("info", "Ejecutando reverificación manual de carpetas...")

    # Llamar a la función unificada en modo manual (sin conteo de imágenes)
    result = _unified_folder_verification(mode='manual', count_images=False)

    # Actualizar estado basado en resultado
    if result["success"]:
        if result["verified"]:
            # ✅ Todas las carpetas presentes
            app_state["last_error_message"] = None
            app_state["current_status_message"] = result["message"]
            _add_processing_event("success", result["message"])
            logger.info(f"Reverificación manual exitosa: {result['found_count']} carpetas - Paso 2 habilitado")

            return JSONResponse(content={
                "success": True,
                "verified": True,
                "message": result["message"],
                "found_folders": result["found_count"],
                "total_expected": result["found_count"]  # Si verified=True, found == expected
            })
        else:
            # ⚠️ Faltan carpetas - Generar reporte
            app_state["last_error_message"] = result["message"]
            app_state["current_status_message"] = result["message"]
            _add_processing_event("warning", result["message"])
            logger.warning(f"Reverificación manual: {result['message']}")

            return JSONResponse(content={
                "success": True,
                "verified": False,
                "message": result["message"],
                "report_available": result["report_available"],
                "missing_count": result["missing_count"],
                "found_folders": result["found_count"],
                "total_expected": result["found_count"] + result["missing_count"],
                "missing_folders": result["missing_list"]
            })
    else:
        # ❌ Error en verificación
        app_state["last_error_message"] = result["message"]
        app_state["current_status_message"] = result["message"]
        logger.error(f"Error en verificación manual: {result['message']}")

        return JSONResponse(content={
            "success": True,  # API respondió correctamente
            "verified": False,
            "message": result["message"],
            "report_available": False
        })


# --- NUEVO ENDPOINT PARA DESCARGAR EL REPORTE DE SKUs FALTANTES ---
@router.get('/api/download_missing_sku_report')
async def download_missing_sku_report():
    missing_skus = app_state.get("last_missing_sku_report_data", [])

    if not missing_skus:
        logger.warning("Se intentó descargar reporte de faltantes, pero no hay datos almacenados o la lista está vacía.")
        raise HTTPException(status_code=404, detail={"success": False, "message": "No hay datos de SKUs faltantes para generar el reporte."})

    try:
        df_missing = pd.DataFrame(missing_skus, columns=['SKU_CL_FALTANTE'])

        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df_missing.to_excel(writer, index=False, sheet_name='SKUs Faltantes')
        output.seek(0)

        logger.info(f"Generando reporte Excel con {len(missing_skus)} SKUs faltantes.")

        return StreamingResponse(
            io.BytesIO(output.read()),
            media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers={"Content-Disposition": "attachment; filename=reporte_sku_faltantes.xlsx"}
        )
    except Exception as e:
        logger.exception("Error al generar el reporte Excel de SKUs faltantes:")
        raise HTTPException(status_code=500, detail={"success": False, "message": f"Error al generar el reporte: {e}"})


# --- FUNCIONES ELIMINADAS DEL FLUJO_PRODUCTIVO ---
# El descargador de imágenes no necesita renombrado de carpetas ni pasos adicionales

# --- Función para obtener el router configurado ---


# --- Función para obtener el router configurado ---
def get_router():
    """Retorna el router configurado para descargador_imagenes para integración con FlexStart"""
    return router
