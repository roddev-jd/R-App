# backend/core_logic/downloader.py

import os
import pandas as pd
import requests
import urllib3
import time
import random
import logging
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from requests.exceptions import ConnectTimeout, ReadTimeout, Timeout, RequestException

# Importar configuración centralizada
from ..config import (
    USER_AGENT,
    DEFAULT_REQUEST_TIMEOUT,
    LARGE_BATCH_REQUEST_TIMEOUT,
    RETRY_TOTAL,
    RETRY_BACKOFF_FACTOR,
    RETRY_STATUS_FORCELIST,
    RETRY_CONNECT,
    RETRY_READ,
    HTTP_POOL_CONNECTIONS,
    HTTP_POOL_MAXSIZE,
    DELAY_BETWEEN_SKUS,
    DELAY_BETWEEN_SKUS_LARGE_BATCH,
    LARGE_BATCH_THRESHOLD,
    DELAY_JITTER_MAX,
    DELAY_BETWEEN_IMAGES,
    DELAY_ON_429_ERROR,
    RIMAGE_BASE_URL_PATTERN,
    STORE_BASE_URL_PATTERN,
    IMAGE_TYPES_PRIMARY,
    IMAGE_EXTENSIONS,
    DOWNLOAD_TYPES,
    DEFAULT_CODDEPTO_RANGE_START,
    DEFAULT_CODDEPTO_RANGE_END
)

# Importar utilidades de limpieza de datos
from ..utils.data_cleaning import clean_excel_value, clean_excel_column

# --- Configuración del Logger ---
logger = logging.getLogger(__name__)

# NUEVO: Excepción personalizada para cancelación
class DownloadCancelledException(Exception):
    """Excepción lanzada cuando el usuario cancela la descarga."""
    pass

def _check_cancellation(APP_STATE):
    """Verifica si se solicitó cancelación y lanza excepción si es necesario."""
    if APP_STATE and APP_STATE.get("should_cancel_download", False):
        logger.info("Descarga cancelada por el usuario. Interrumpiendo proceso.")
        raise DownloadCancelledException("Descarga cancelada por el usuario")

def _interruptible_sleep(seconds, APP_STATE):
    """Sleep que puede ser interrumpido por cancelación.
    Divide el sleep en chunks de 0.1 segundos para poder responder rápidamente a cancelación."""
    chunks = int(seconds / 0.1)
    remainder = seconds % 0.1

    for _ in range(chunks):
        _check_cancellation(APP_STATE)
        time.sleep(0.1)

    if remainder > 0:
        _check_cancellation(APP_STATE)
        time.sleep(remainder)

# Deshabilitar advertencias por conexiones inseguras (SSL)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- Funciones Auxiliares ---

def _get_adaptive_delay(base_delay, is_large_batch=False, add_jitter=True):
    """
    Calcula delay adaptativo basado en tamaño del lote y agrega jitter aleatorio.

    Args:
        base_delay: Delay base en segundos
        is_large_batch: True si el lote tiene >100 SKUs
        add_jitter: Si True, agrega jitter aleatorio para evitar patrones

    Returns:
        Delay final en segundos
    """
    # Si es lote grande, usar el delay aumentado
    if is_large_batch:
        delay = DELAY_BETWEEN_SKUS_LARGE_BATCH
    else:
        delay = base_delay

    # Agregar jitter aleatorio (0 a DELAY_JITTER_MAX segundos)
    if add_jitter:
        jitter = random.uniform(0, DELAY_JITTER_MAX)
        delay += jitter

    return delay

def _get_adaptive_timeout(total_items):
    """
    Retorna timeout apropiado según el tamaño del lote.

    Args:
        total_items: Número total de SKUs a procesar

    Returns:
        Tupla (connect_timeout, read_timeout)
    """
    if total_items >= LARGE_BATCH_THRESHOLD:
        return LARGE_BATCH_REQUEST_TIMEOUT
    else:
        return DEFAULT_REQUEST_TIMEOUT

def _classify_download_error(exception, status_code):
    """
    Clasifica el tipo de error en la descarga para mejor logging y análisis.

    Args:
        exception: Excepción capturada (puede ser None)
        status_code: Código HTTP de respuesta (puede ser None)

    Returns:
        Tupla (error_type, error_description) donde error_type es:
        - "not_found": El recurso no existe (404)
        - "rate_limit": Rate limit excedido (429)
        - "timeout": Timeout de conexión o lectura
        - "server_error": Error del servidor (5xx)
        - "network_error": Error de red/conexión
        - "unknown": Error no clasificado
    """
    if status_code == 404:
        return ("not_found", "Imagen no existe en el servidor")
    elif status_code == 429:
        return ("rate_limit", "Rate limit excedido")
    elif status_code and 500 <= status_code < 600:
        return ("server_error", f"Error del servidor ({status_code})")
    elif isinstance(exception, (ConnectTimeout, ReadTimeout, Timeout)):
        return ("timeout", f"Timeout de conexión/lectura")
    elif isinstance(exception, RequestException):
        return ("network_error", f"Error de red: {type(exception).__name__}")
    else:
        return ("unknown", "Error no clasificado")

def _initialize_session():
    """Configura y retorna una sesión de requests con reintentos mejorados y pool optimizado."""
    session = requests.Session()
    retry_strategy = Retry(
        total=RETRY_TOTAL,
        backoff_factor=RETRY_BACKOFF_FACTOR,
        status_forcelist=RETRY_STATUS_FORCELIST,
        allowed_methods=["GET"],
        connect=RETRY_CONNECT,
        read=RETRY_READ,
        # Importante: raise_on_status=False para que no lance excepción en 404
        # y podamos manejarlo correctamente
        raise_on_status=False
    )
    # MEJORA: Configurar pool de conexiones más grande para lotes masivos
    adapter = HTTPAdapter(
        max_retries=retry_strategy,
        pool_connections=HTTP_POOL_CONNECTIONS,
        pool_maxsize=HTTP_POOL_MAXSIZE,
        pool_block=False  # No bloquear si el pool está lleno, crear nueva conexión
    )
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update({"User-Agent": USER_AGENT})

    logger.info(f"Sesión HTTP inicializada: pool_connections={HTTP_POOL_CONNECTIONS}, "
                f"pool_maxsize={HTTP_POOL_MAXSIZE}, retry_total={RETRY_TOTAL}")

    return session

def _read_and_validate_excel(excel_path, sku_column_name, coddepto_column_name=None):
    """
    Lee el archivo Excel y valida las columnas requeridas.
    Usa las funciones centralizadas de limpieza de datos.
    """
    try:
        df = pd.read_excel(excel_path, dtype=str) # Leer todas las columnas como string inicialmente
        logger.info(f"Archivo Excel '{excel_path}' leído. Columnas encontradas: {list(df.columns)}")
    except Exception as e:
        logger.error(f"Error crítico: No se pudo leer el archivo Excel en {excel_path}: {e}")
        raise ValueError(f"No se pudo leer el archivo Excel: {e}")

    # Validar existencia de sku_column_name
    if sku_column_name not in df.columns:
        error_msg = f"Error: Columna SKU requerida '{sku_column_name}' no encontrada en el Excel."
        logger.error(error_msg)
        raise ValueError(error_msg)

    # Limpiar la columna SKU_CL usando función centralizada
    df[sku_column_name] = clean_excel_column(df[sku_column_name])
    df.dropna(subset=[sku_column_name], inplace=True) # Eliminar filas donde SKU_CL es NaN o vacío después de limpiar
    if df.empty:
        error_msg = f"No hay datos válidos en la columna SKU '{sku_column_name}' después de la limpieza."
        logger.warning(error_msg) # Puede no ser un error fatal si el archivo está intencionalmente vacío.
        # raise ValueError(error_msg) # Opcional: hacerlo un error fatal

    # Validar y limpiar coddepto_column_name si se proporcionó y existe
    if coddepto_column_name:
        if coddepto_column_name not in df.columns:
            logger.warning(f"Advertencia: Columna CODDEPTO opcional '{coddepto_column_name}' no encontrada. "
                           "La descarga secundaria podría no funcionar.")
            # No es un error fatal, la descarga primaria aún puede funcionar.
        else:
            df[coddepto_column_name] = clean_excel_column(df[coddepto_column_name])
            # No eliminamos filas si CODDEPTO es NaN, ya que es opcional para el ítem.

    return df

def _group_items_by_parent_color(df, sku_column_name):
    """
    Agrupa SKUs por combinación de codskupadrelargo + color.

    Args:
        df: DataFrame con los datos
        sku_column_name: Nombre de la columna con los SKUs

    Returns:
        dict: {(codskupadrelargo, color): [lista_de_skus_ordenados]}
    """
    # Verificar que existan las columnas necesarias
    if 'codskupadrelargo' not in df.columns or 'color' not in df.columns:
        logger.warning("No se encontraron columnas 'codskupadrelargo' y/o 'color' para agrupación")
        return {}

    groups = {}

    # Iterar sobre el dataframe en orden para preservar secuencia
    for idx, row in df.iterrows():
        sku = row[sku_column_name]
        parent = clean_excel_value(row.get('codskupadrelargo', ''))
        color = clean_excel_value(row.get('color', ''))

        # Si algún valor es vacío, no agrupar este SKU
        if not parent or not color:
            continue

        group_key = (parent, color)
        if group_key not in groups:
            groups[group_key] = []

        # Evitar duplicados en el mismo grupo
        if sku not in groups[group_key]:
            groups[group_key].append(sku)

    logger.info(f"Agrupación por padre+color: {len(groups)} grupos únicos encontrados")

    return groups


def _prepare_items_for_processing(df, sku_column_name, coddepto_column_name=None, destination_folder=None, skip_existing=True, group_by_parent_color=False):
    """
    Prepara la lista de ítems a procesar (SKU_CL únicos) desde el DataFrame.

    Args:
        df: DataFrame con los datos
        sku_column_name: Nombre de la columna con los SKUs
        coddepto_column_name: Nombre de la columna con códigos de departamento (opcional)
        destination_folder: Carpeta de destino para verificar carpetas existentes (opcional)
        skip_existing: Si True, omite carpetas que ya existen (default: True)
        group_by_parent_color: Si True, agrupa por codskupadrelargo+color (default: False)

    Returns:
        tuple: (items_to_process, existing_folders, skipped_count, parent_color_groups)
    """
    items_to_process = []
    existing_folders = []
    skipped_count = 0
    parent_color_groups = {}

    logger.info(f"Preparando ítems para procesar desde la columna SKU: '{sku_column_name}'.")

    # Si se solicita agrupación, obtener los grupos
    if group_by_parent_color:
        parent_color_groups = _group_items_by_parent_color(df, sku_column_name)
        if parent_color_groups:
            logger.info(f"Agrupación activada: se procesará solo el primer SKU de cada grupo padre+color")

    # Obtener SKU_CL únicos para procesar
    unique_sku_cls = df[sku_column_name].unique() # Ya están limpios y sin NaNs por _read_and_validate_excel

    for sku_val in unique_sku_cls:
        # Verificar si la carpeta ya existe
        folder_exists = False
        if destination_folder and skip_existing:
            folder_path = os.path.join(destination_folder, str(sku_val))
            folder_exists = os.path.exists(folder_path) and os.path.isdir(folder_path)

            if folder_exists:
                existing_folders.append(str(sku_val))
                skipped_count += 1
                logger.debug(f"Carpeta ya existe, omitiendo: {sku_val}")
                continue  # Saltar este ítem

        item_data = {'sku_cl': sku_val, 'log_name': sku_val}

        # Si se usa CODDEPTO, encontrar el primer CODDEPTO no nulo para este SKU_CL
        if coddepto_column_name and coddepto_column_name in df.columns:
            first_matching_row = df[df[sku_column_name] == sku_val].iloc[0]
            coddepto_val = first_matching_row.get(coddepto_column_name)
            item_data['coddepto'] = coddepto_val
        else:
            item_data['coddepto'] = None

        # Añadir información de agrupación si está disponible
        if group_by_parent_color and parent_color_groups:
            first_matching_row = df[df[sku_column_name] == sku_val].iloc[0]
            parent = clean_excel_value(first_matching_row.get('codskupadrelargo', ''))
            color = clean_excel_value(first_matching_row.get('color', ''))

            if parent and color:
                group_key = (parent, color)
                item_data['parent_color_group'] = group_key

                # Verificar si es el primer SKU del grupo
                if group_key in parent_color_groups and parent_color_groups[group_key]:
                    item_data['is_group_representative'] = (sku_val == parent_color_groups[group_key][0])
                else:
                    item_data['is_group_representative'] = True
            else:
                item_data['is_group_representative'] = True  # Sin grupo, procesar siempre
        else:
            item_data['is_group_representative'] = True  # Sin agrupación, procesar siempre

        items_to_process.append(item_data)

    total_unique = len(unique_sku_cls)
    logger.info(f"Total de SKUs únicos en Excel: {total_unique}")
    logger.info(f"Carpetas existentes (omitidas): {skipped_count}")
    logger.info(f"SKUs a procesar (nuevos): {len(items_to_process)}")

    return items_to_process, existing_folders, skipped_count, parent_color_groups

def _attempt_single_download(url, save_path, session, item_log_prefix, request_timeout=None, APP_STATE=None):
    """
    Intenta descargar una única URL y la guarda.

    Args:
        url: URL a descargar
        save_path: Ruta donde guardar el archivo
        session: Sesión de requests
        item_log_prefix: Prefijo para logs
        request_timeout: Timeout personalizado (tupla) o None para usar default
        APP_STATE: Estado de la aplicación

    Returns:
        Tupla (success: bool, error_type: str)
    """
    # NUEVO: Verificar cancelación antes de cada descarga HTTP
    _check_cancellation(APP_STATE)

    # Usar timeout proporcionado o el default
    timeout = request_timeout if request_timeout else DEFAULT_REQUEST_TIMEOUT
    captured_exception = None
    status_code = None

    try:
        # logger.debug(f"Intentando ({item_log_prefix}): {url}") # Descomentar para logs muy detallados
        resp = session.get(url, timeout=timeout, verify=False)
        status_code = resp.status_code

        if resp.status_code == 200:
            # Asegurar que el directorio de la subcarpeta (SKU_CL) exista
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            with open(save_path, 'wb') as f:
                f.write(resp.content)
            logger.info(f"✓ Descargado ({item_log_prefix}): '{os.path.basename(save_path)}'")
            return (True, None)
        elif resp.status_code == 404:
            logger.debug(f"✗ No encontrado (404) ({item_log_prefix}): {os.path.basename(url)}")
            return (False, "not_found")
        elif resp.status_code == 429:
            logger.warning(f"⚠ Rate limit (429) ({item_log_prefix}). Esperando {DELAY_ON_429_ERROR}s...")
            _interruptible_sleep(DELAY_ON_429_ERROR, APP_STATE)
            return (False, "rate_limit")
        else:
            error_type, error_desc = _classify_download_error(None, resp.status_code)
            logger.warning(f"✗ {error_desc} ({item_log_prefix}): {os.path.basename(url)}")
            return (False, error_type)

    except ConnectTimeout as e:
        captured_exception = e
        logger.warning(f"⏱ Timeout de Conexión ({item_log_prefix}): {os.path.basename(url)}")
    except ReadTimeout as e:
        captured_exception = e
        logger.warning(f"⏱ Timeout de Lectura ({item_log_prefix}): {os.path.basename(url)}")
    except Timeout as e:
        captured_exception = e
        logger.warning(f"⏱ Timeout General ({item_log_prefix}): {os.path.basename(url)}")
    except RequestException as e_req:
        captured_exception = e_req
        logger.warning(f"✗ Error de Request ({item_log_prefix}): {type(e_req).__name__}")
    except Exception as e:
        captured_exception = e
        logger.error(f"✗ Error Inesperado ({item_log_prefix}): {type(e).__name__} - {str(e)}")

    # Clasificar el error capturado
    if captured_exception:
        error_type, _ = _classify_download_error(captured_exception, status_code)
        return (False, error_type)

    return (False, "unknown")

def _download_rimage_images(sku_cl, session, subfolder_path, item_log_prefix, request_timeout=None, APP_STATE=None, _add_processing_event=None):
    """Descarga imágenes desde rimage.ripley.cl

    OPTIMIZACIÓN MEJORADA: Si full_image no existe (404 confirmado), se saltan las demás imágenes.
    Si falla por timeout o error temporal, se intentan las demás imágenes por si acaso.
    """
    images_downloaded_count = 0
    image_found = False
    full_image_found = False
    full_image_confirmed_not_found = False  # True solo si fue 404 en todas las extensiones

    logger.info(f"Procesando descarga Rimage para {item_log_prefix}...")

    download_config = DOWNLOAD_TYPES["rimage_only"]
    image_types = download_config["image_types"]
    extensions = download_config["extensions"]

    for tipo in image_types:
        _check_cancellation(APP_STATE)

        # OPTIMIZACIÓN: Si es la primera imagen (full_image), verificar si existe
        if tipo == "full_image":
            tipo_found = False
            all_404 = True  # Asumimos que todas son 404 hasta que encontremos otra cosa

            for ext in extensions:
                # Construir URL y filename correctamente para casos con y sin extensión
                if ext == "":
                    url = f"https://rimage.ripley.cl/home.ripley/Attachment/WOP/1/{sku_cl}/{tipo}-{sku_cl}"
                    filename = f"{tipo}-{sku_cl}"
                    display_ext = "sin_ext"
                elif ext == ".":
                    url = f"https://rimage.ripley.cl/home.ripley/Attachment/WOP/1/{sku_cl}/{tipo}-{sku_cl}."
                    filename = f"{tipo}-{sku_cl}."
                    display_ext = "punto"
                else:
                    url = RIMAGE_BASE_URL_PATTERN.format(sku_cl=sku_cl, tipo=tipo, ext=ext)
                    filename = f"{tipo}-{sku_cl}.{ext}"
                    display_ext = ext

                save_path = os.path.join(subfolder_path, filename)

                if _add_processing_event:
                    _add_processing_event("info", f"Descargando Rimage {tipo}.{display_ext}", sku=sku_cl, image_type=f"{tipo}.{display_ext}", url=url)

                success, error_type = _attempt_single_download(url, save_path, session, f"{item_log_prefix}, Rimage {tipo}.{display_ext}", request_timeout, APP_STATE)

                if success:
                    images_downloaded_count += 1
                    image_found = True
                    tipo_found = True
                    full_image_found = True
                    if APP_STATE:
                        APP_STATE["successful_downloads"] += 1
                    break  # Si encontró la imagen en alguna extensión, pasar al siguiente tipo
                else:
                    # Si el error NO es 404, significa que hubo un problema temporal
                    if error_type != "not_found":
                        all_404 = False
                    if APP_STATE:
                        APP_STATE["failed_downloads"] += 1

                _interruptible_sleep(DELAY_BETWEEN_IMAGES, APP_STATE)

            # MEJORA: Solo saltar si TODAS las extensiones dieron 404
            if not full_image_found:
                if all_404:
                    full_image_confirmed_not_found = True
                    logger.info(f"OPTIMIZACIÓN: full_image no existe (404 confirmado) para {item_log_prefix}, saltando image1-image15")
                    break  # Salir del loop de tipos de imagen
                else:
                    logger.info(f"full_image falló por error temporal para {item_log_prefix}, intentando image1-image15 por si acaso")
        else:
            # Para image1, image2, etc., buscar en todas las extensiones
            for ext in extensions:
                # Construir URL y filename correctamente para casos con y sin extensión
                if ext == "":
                    url = f"https://rimage.ripley.cl/home.ripley/Attachment/WOP/1/{sku_cl}/{tipo}-{sku_cl}"
                    filename = f"{tipo}-{sku_cl}"
                    display_ext = "sin_ext"
                elif ext == ".":
                    url = f"https://rimage.ripley.cl/home.ripley/Attachment/WOP/1/{sku_cl}/{tipo}-{sku_cl}."
                    filename = f"{tipo}-{sku_cl}."
                    display_ext = "punto"
                else:
                    url = RIMAGE_BASE_URL_PATTERN.format(sku_cl=sku_cl, tipo=tipo, ext=ext)
                    filename = f"{tipo}-{sku_cl}.{ext}"
                    display_ext = ext

                save_path = os.path.join(subfolder_path, filename)

                if _add_processing_event:
                    _add_processing_event("info", f"Descargando Rimage {tipo}.{display_ext}", sku=sku_cl, image_type=f"{tipo}.{display_ext}", url=url)

                success, error_type = _attempt_single_download(url, save_path, session, f"{item_log_prefix}, Rimage {tipo}.{display_ext}", request_timeout, APP_STATE)

                if success:
                    images_downloaded_count += 1
                    image_found = True
                    if APP_STATE:
                        APP_STATE["successful_downloads"] += 1
                    break  # Si encontró la imagen en alguna extensión, pasar al siguiente tipo
                else:
                    if APP_STATE:
                        APP_STATE["failed_downloads"] += 1

                _interruptible_sleep(DELAY_BETWEEN_IMAGES, APP_STATE)

    return images_downloaded_count, image_found


def _try_store_download_with_coddepto(sku_cl, coddepto, session, subfolder_path, item_log_prefix, request_timeout=None, APP_STATE=None, _add_processing_event=None):
    """
    Intenta descargar imágenes Store con un CODDEPTO específico.

    Returns:
        Tupla (images_count, image_found, error_type_main)
        - images_count: Número de imágenes descargadas
        - image_found: True si encontró al menos una imagen
        - error_type_main: Tipo de error en _2.jpg ('not_found', 'timeout', etc.) o None si éxito
    """
    images_downloaded_count = 0
    image_found = False

    base_store_url = STORE_BASE_URL_PATTERN.format(coddepto=coddepto, sku_cl=sku_cl)

    # OPTIMIZACIÓN: Intento con guion bajo (_2.jpg) - IMAGEN PRINCIPAL
    url_underscore = f"{base_store_url}{sku_cl}_2.jpg"
    filename_underscore = f"{sku_cl}_2.jpg"
    save_path_underscore = os.path.join(subfolder_path, filename_underscore)

    if _add_processing_event:
        _add_processing_event("info", f"Descargando Store _2.jpg (CODDEPTO: {coddepto})", sku=sku_cl, image_type="store_2.jpg", url=url_underscore)

    underscore_image_found = False
    error_type_underscore = None
    success, error_type_underscore = _attempt_single_download(url_underscore, save_path_underscore, session, f"{item_log_prefix}, Store _2.jpg (CODDEPTO: {coddepto})", request_timeout, APP_STATE)

    if success:
        images_downloaded_count += 1
        image_found = True
        underscore_image_found = True
        if APP_STATE:
            APP_STATE["successful_downloads"] += 1
    else:
        if APP_STATE:
            APP_STATE["failed_downloads"] += 1

    # Si _2.jpg dio 404, retornar inmediatamente (no hay imágenes con este CODDEPTO)
    if not underscore_image_found and error_type_underscore == "not_found":
        return images_downloaded_count, image_found, error_type_underscore

    # Si _2.jpg tuvo error temporal pero no 404, intentar -1 a -18 por si acaso
    if not underscore_image_found:
        logger.debug(f"_2.jpg falló por error temporal (CODDEPTO: {coddepto}) para {item_log_prefix}, intentando -1 a -18 por si acaso")

    _interruptible_sleep(DELAY_BETWEEN_IMAGES, APP_STATE)

    # Intento con guiones (-i.jpg) - Intentar a menos que _2.jpg dio 404
    for i in range(1, 19):
        _check_cancellation(APP_STATE)

        url_hyphen = f"{base_store_url}{sku_cl}-{i}.jpg"
        filename_hyphen = f"{sku_cl}-{i}.jpg"
        save_path_hyphen = os.path.join(subfolder_path, filename_hyphen)

        if _add_processing_event:
            _add_processing_event("info", f"Descargando Store -{i}.jpg (CODDEPTO: {coddepto})", sku=sku_cl, image_type=f"store_{i}.jpg", url=url_hyphen)

        success, _ = _attempt_single_download(url_hyphen, save_path_hyphen, session, f"{item_log_prefix}, Store -{i}.jpg (CODDEPTO: {coddepto})", request_timeout, APP_STATE)

        if success:
            images_downloaded_count += 1
            image_found = True
            if APP_STATE:
                APP_STATE["successful_downloads"] += 1
        else:
            if APP_STATE:
                APP_STATE["failed_downloads"] += 1

        _interruptible_sleep(DELAY_BETWEEN_IMAGES, APP_STATE)

    return images_downloaded_count, image_found, error_type_underscore


def _download_store_images(sku_cl, coddepto, session, subfolder_path, item_log_prefix, request_timeout=None, APP_STATE=None, _add_processing_event=None):
    """Descarga imágenes desde home.ripley.cl/store

    OPTIMIZACIÓN MEJORADA:
    1. Primero intenta con CODDEPTO de la planilla (si existe)
    2. Si no encuentra imágenes (404), busca exhaustivamente en CODDEPTO 100-462
    3. Se detiene al primer CODDEPTO que tenga imágenes
    """
    images_downloaded_count = 0
    image_found = False

    logger.info(f"Procesando descarga Store para {item_log_prefix}...")

    # PASO 1: Intentar con CODDEPTO de la planilla (si existe)
    if coddepto:
        logger.info(f"Intentando con CODDEPTO de planilla: {coddepto}")
        images_count, found, error_type = _try_store_download_with_coddepto(
            sku_cl, coddepto, session, subfolder_path, item_log_prefix,
            request_timeout, APP_STATE, _add_processing_event
        )

        images_downloaded_count += images_count
        image_found = found

        # Si encontró imágenes, terminar exitosamente
        if image_found:
            logger.info(f"✓ Imágenes encontradas con CODDEPTO de planilla: {coddepto}")
            return images_downloaded_count, image_found

        # Si fue 404, continuar con búsqueda exhaustiva
        if error_type == "not_found":
            logger.info(f"CODDEPTO de planilla ({coddepto}) no tiene imágenes (404). Iniciando búsqueda exhaustiva D100-D462...")
        else:
            # Error temporal, aún así probar búsqueda exhaustiva
            logger.warning(f"CODDEPTO de planilla ({coddepto}) falló por error temporal. Iniciando búsqueda exhaustiva D100-D462...")
    else:
        logger.warning(f"No se proporcionó CODDEPTO en planilla para {item_log_prefix}. Iniciando búsqueda exhaustiva D100-D462...")

    # PASO 2: Búsqueda exhaustiva CODDEPTO
    # Determinar estrategia: Lista personalizada > Rango > Por defecto

    coddepto_list_to_try = []
    search_method = "default"

    if APP_STATE:
        # PRIORIDAD 1: Lista personalizada desde planilla
        custom_list = APP_STATE.get("coddepto_custom_list")
        if custom_list and isinstance(custom_list, list) and len(custom_list) > 0:
            coddepto_list_to_try = custom_list
            search_method = "custom_list"
            logger.info(f"📋 Usando lista personalizada de planilla: {len(coddepto_list_to_try)} valores CODDEPTO")
            logger.info(f"   Primeros valores: {coddepto_list_to_try[:5]}")

        # PRIORIDAD 2: Rango personalizado
        elif APP_STATE.get("coddepto_range_start") is not None and APP_STATE.get("coddepto_range_end") is not None:
            range_start = APP_STATE.get("coddepto_range_start")
            range_end = APP_STATE.get("coddepto_range_end")
            coddepto_list_to_try = [f"D{num}" for num in range(range_start, range_end + 1)]
            search_method = "custom_range"
            logger.info(f"🎯 Usando rango personalizado: D{range_start}-D{range_end} ({len(coddepto_list_to_try)} valores)")

        # PRIORIDAD 3: Rango por defecto
        else:
            coddepto_list_to_try = [f"D{num}" for num in range(DEFAULT_CODDEPTO_RANGE_START, DEFAULT_CODDEPTO_RANGE_END + 1)]
            search_method = "default"
            logger.info(f"🔍 Usando rango por defecto: D{DEFAULT_CODDEPTO_RANGE_START}-D{DEFAULT_CODDEPTO_RANGE_END} ({len(coddepto_list_to_try)} valores)")

    logger.info(f"🔍 Búsqueda exhaustiva CODDEPTO para {item_log_prefix}...")

    # Iterar sobre la lista de CODDEPTOs a probar
    for index, coddepto_test in enumerate(coddepto_list_to_try):
        _check_cancellation(APP_STATE)

        # Saltar el CODDEPTO ya probado de la planilla
        if coddepto and str(coddepto_test).upper() == str(coddepto).upper():
            logger.debug(f"Saltando {coddepto_test} (ya probado de planilla)")
            continue

        logger.debug(f"Probando CODDEPTO alternativo: {coddepto_test} ({index + 1}/{len(coddepto_list_to_try)})")

        images_count, found, error_type = _try_store_download_with_coddepto(
            sku_cl, coddepto_test, session, subfolder_path, item_log_prefix,
            request_timeout, APP_STATE, _add_processing_event
        )

        images_downloaded_count += images_count
        image_found = found

        # Si encontró imágenes, terminar búsqueda
        if image_found:
            logger.info(f"✓ Imágenes encontradas con CODDEPTO alternativo: {coddepto_test} (planilla indicaba: {coddepto}, método: {search_method})")
            return images_downloaded_count, image_found

        # Delay entre intentos de diferentes CODDEPTO (solo si no encontró)
        _interruptible_sleep(DELAY_BETWEEN_IMAGES, APP_STATE)

    # Si llegó aquí, no encontró imágenes en ningún CODDEPTO
    logger.warning(f"No se encontraron imágenes Store para {item_log_prefix} en ningún CODDEPTO ({search_method}, {len(coddepto_list_to_try)} intentos)")
    return images_downloaded_count, image_found


def _download_images_for_item(item_data, session, base_destination_folder, item_log_prefix, download_type="both_fallback", request_timeout=None, APP_STATE=None, _add_processing_event=None):
    """Maneja la lógica de descarga para un solo ítem (SKU_CL) según el tipo seleccionado."""
    sku_cl = item_data['sku_cl']
    coddepto = item_data.get('coddepto')

    # Las subcarpetas se nombran directamente con el valor de SKU_CL
    subfolder_path = os.path.join(base_destination_folder, str(sku_cl))

    images_downloaded_count = 0

    # NUEVO: Verificar cancelación antes de procesar el item
    _check_cancellation(APP_STATE)

    # Validar tipo de descarga
    if download_type not in DOWNLOAD_TYPES:
        logger.error(f"Tipo de descarga no válido: {download_type}")
        return 0

    download_config = DOWNLOAD_TYPES[download_type]

    # Verificar si se requiere CODDEPTO
    if download_config["requires_coddepto"] and not coddepto:
        logger.warning(f"Tipo de descarga '{download_type}' requiere CODDEPTO, pero no se proporcionó para {item_log_prefix}")
        if download_type == "store_only":
            return 0  # No se puede procesar sin CODDEPTO

    # Ejecutar descarga según el tipo seleccionado, pasando timeout adaptativo
    if download_type == "rimage_only":
        images_count, _ = _download_rimage_images(sku_cl, session, subfolder_path, item_log_prefix, request_timeout, APP_STATE, _add_processing_event)
        images_downloaded_count += images_count

    elif download_type == "store_only":
        images_count, _ = _download_store_images(sku_cl, coddepto, session, subfolder_path, item_log_prefix, request_timeout, APP_STATE, _add_processing_event)
        images_downloaded_count += images_count

    elif download_type == "both_fallback":
        # Intenta Rimage primero
        rimage_count, rimage_found = _download_rimage_images(sku_cl, session, subfolder_path, item_log_prefix, request_timeout, APP_STATE, _add_processing_event)
        images_downloaded_count += rimage_count

        # Si no encontró imágenes en Rimage y tiene CODDEPTO, intenta Store
        if not rimage_found and coddepto:
            logger.info(f"No se encontraron imágenes Rimage para {item_log_prefix}, intentando Store como fallback...")
            store_count, _ = _download_store_images(sku_cl, coddepto, session, subfolder_path, item_log_prefix, request_timeout, APP_STATE, _add_processing_event)
            images_downloaded_count += store_count

    if images_downloaded_count == 0:
        logger.warning(f"No se descargaron imágenes para {item_log_prefix} (SKU_CL: {sku_cl}) usando tipo '{download_type}'.")
    else:
        logger.info(f"Total imágenes descargadas para {item_log_prefix}: {images_downloaded_count} (tipo: {download_type}).")

    return images_downloaded_count

# --- Función Principal para ser Llamada por la App Flask ---

def execute_download_process(excel_file_path: str, sku_column_name: str,
                             destination_folder: str, coddepto_column_name: str = None,
                             download_type: str = "both_fallback",
                             APP_STATE=None, _add_processing_event=None,
                             group_by_parent_color: bool = False):
    """
    Orquesta el proceso completo de descarga de imágenes.

    Args:
        group_by_parent_color: Si True, agrupa SKUs por codskupadrelargo+color y omite duplicados
                               Además, si el representante falla, intenta con el siguiente del grupo (fallback)
    """
    if not excel_file_path or not os.path.exists(excel_file_path):
        msg = f"Ruta del archivo Excel no proporcionada o el archivo '{excel_file_path}' no existe."
        logger.error(msg)
        return {"success": False, "message": msg, "total_items_processed": 0, "total_images_downloaded": 0}
    if not destination_folder:
        msg = "Carpeta de destino no proporcionada."
        logger.error(msg)
        return {"success": False, "message": msg, "total_items_processed": 0, "total_images_downloaded": 0}

    try:
        # La carpeta base de sesión (destination_folder) ya debería estar creada por app.py
        # os.makedirs(destination_folder, exist_ok=True) # No es estrictamente necesario si app.py lo hace
        pass
    except OSError as e:
        msg = f"No se pudo asegurar la creación de la carpeta de destino {destination_folder}: {e}"
        logger.error(msg)
        return {"success": False, "message": msg, "total_items_processed": 0, "total_images_downloaded": 0}

    try:
        df = _read_and_validate_excel(excel_file_path, sku_column_name, coddepto_column_name)
    except ValueError as e: # Error ya logueado en la función helper
        return {"success": False, "message": str(e), "total_items_processed": 0, "total_images_downloaded": 0}

    # Preparar ítems y verificar carpetas existentes
    items_to_process, existing_folders, skipped_count, parent_color_groups = _prepare_items_for_processing(
        df, sku_column_name, coddepto_column_name, destination_folder, skip_existing=True, group_by_parent_color=group_by_parent_color
    )

    if not items_to_process and skipped_count > 0:
        msg = f"Todas las carpetas ({skipped_count}) ya existen en la ubicación de destino. No hay nada nuevo para descargar."
        logger.info(msg)
        return {
            "success": True,
            "message": msg,
            "total_items_processed": 0,
            "total_images_downloaded": 0,
            "skipped_count": skipped_count,
            "existing_folders": existing_folders,
            "skipped_by_grouping": 0
        }

    if not items_to_process:
        msg = "No hay ítems válidos para procesar después de leer y limpiar el Excel."
        logger.warning(msg)
        return {"success": False, "message": msg, "total_items_processed": 0, "total_images_downloaded": 0, "skipped_by_grouping": 0}

    total_items_to_process = len(items_to_process)

    # Mensaje informativo sobre omisiones
    if skipped_count > 0:
        logger.info(f"Iniciando descarga para {total_items_to_process} SKU_CL únicos ({skipped_count} omitidos por ya existir).")
    else:
        logger.info(f"Iniciando descarga para {total_items_to_process} SKU_CL únicos.")

    # Mensaje sobre agrupación si está activa
    if group_by_parent_color and parent_color_groups:
        logger.info(f"Agrupación por padre+color activa: {len(parent_color_groups)} grupos detectados")

    # Usar las funciones de eventos pasadas como parámetros
    if _add_processing_event:
        if skipped_count > 0:
            _add_processing_event("info", f"✓ {skipped_count} carpetas ya existen y se omitirán.")
            _add_processing_event("info", f"Iniciando descarga de imágenes para {total_items_to_process} productos nuevos...")
        else:
            _add_processing_event("info", f"Iniciando descarga de imágenes para {total_items_to_process} productos...")
        logger.info("Iniciando proceso con monitoreo de eventos")

    http_session = _initialize_session()
    total_images_downloaded_overall = 0
    items_processed_count = 0 # Ítems (SKU_CL únicos) para los que se intentó la descarga
    skipped_by_grouping = 0 # Contador de SKUs omitidos por agrupación padre+color

    # Diccionario para trackear grupos exitosos: {(parent, color): True/False}
    successful_groups = {}

    # MEJORA: Determinar si es lote grande para usar configuración optimizada
    is_large_batch = total_items_to_process >= LARGE_BATCH_THRESHOLD
    request_timeout = _get_adaptive_timeout(total_items_to_process)

    if is_large_batch:
        logger.info(f"🔧 Lote GRANDE detectado ({total_items_to_process} SKUs). Usando configuración optimizada:")
        logger.info(f"   - Timeouts: {request_timeout[0]}s conexión, {request_timeout[1]}s lectura")
        logger.info(f"   - Delay entre SKUs: {DELAY_BETWEEN_SKUS_LARGE_BATCH}s + jitter aleatorio")
        logger.info(f"   - Pool de conexiones: {HTTP_POOL_CONNECTIONS}/{HTTP_POOL_MAXSIZE}")
    else:
        logger.info(f"Lote normal ({total_items_to_process} SKUs). Usando configuración estándar.")

    try:
        for index, item_data in enumerate(items_to_process):
            # NUEVO: Verificar cancelación antes de procesar cada SKU
            _check_cancellation(APP_STATE)

            item_log_name = item_data.get('log_name', item_data.get('sku_cl', 'SKU_DESCONOCIDO'))
            item_log_prefix = f"Ítem {index + 1}/{total_items_to_process} (SKU_CL: {item_log_name})"

            # LÓGICA DE AGRUPACIÓN: Verificar si debe omitirse por pertenecer a grupo ya descargado
            if group_by_parent_color and 'parent_color_group' in item_data:
                group_key = item_data['parent_color_group']
                is_representative = item_data.get('is_group_representative', True)

                # Si NO es representante y el grupo YA fue descargado exitosamente, omitir
                if not is_representative and group_key in successful_groups and successful_groups[group_key]:
                    skipped_by_grouping += 1
                    logger.debug(f"Omitiendo {item_log_name} (grupo {group_key} ya descargado exitosamente)")

                    # Actualizar progreso sin procesar
                    if APP_STATE:
                        APP_STATE["processed_skus"] = index + 1

                    continue  # Saltar este SKU

            logger.info(f"--- {item_log_prefix} ---")

            # NUEVO: Actualizar progreso y registrar evento de inicio de procesamiento de SKU
            if APP_STATE:
                APP_STATE["processed_skus"] = index
            if _add_processing_event:
                _add_processing_event("info", f"Procesando SKU: {item_log_name}", sku=item_log_name)

            try:
                # La carpeta de destino para este ítem es destination_folder (la base de sesión)
                # _download_images_for_item creará la subcarpeta SKU_CL dentro de destination_folder
                # MEJORA: Pasar timeout adaptativo
                images_for_this_item = _download_images_for_item(item_data, http_session, destination_folder, item_log_prefix, download_type, request_timeout, APP_STATE, _add_processing_event)
                total_images_downloaded_overall += images_for_this_item

                # NUEVO: FALLBACK - Si es representante y no descargó imágenes, intentar con siguiente del grupo
                if group_by_parent_color and 'parent_color_group' in item_data and images_for_this_item == 0:
                    group_key = item_data['parent_color_group']
                    is_representative = item_data.get('is_group_representative', True)

                    # Si es representante y el grupo existe con más SKUs
                    if is_representative and group_key in parent_color_groups:
                        group_skus = parent_color_groups[group_key]
                        current_sku = item_data['sku_cl']

                        # Buscar posición del SKU actual
                        try:
                            current_index = group_skus.index(current_sku)
                            # Intentar con los siguientes SKUs del grupo
                            for fallback_index in range(current_index + 1, len(group_skus)):
                                fallback_sku = group_skus[fallback_index]
                                logger.info(f"🔄 Fallback: Representante {current_sku} sin imágenes. Intentando con {fallback_sku}")

                                if _add_processing_event:
                                    _add_processing_event("info", f"Fallback: intentando con {fallback_sku}", sku=fallback_sku)

                                # Crear item_data para el fallback
                                fallback_item_data = item_data.copy()
                                fallback_item_data['sku_cl'] = fallback_sku
                                fallback_item_data['log_name'] = fallback_sku
                                fallback_log_prefix = f"{item_log_prefix} [Fallback: {fallback_sku}]"

                                # Intentar descarga con el fallback SKU
                                fallback_images = _download_images_for_item(
                                    fallback_item_data, http_session, destination_folder,
                                    fallback_log_prefix, download_type, request_timeout,
                                    APP_STATE, _add_processing_event
                                )

                                if fallback_images > 0:
                                    # Éxito con fallback
                                    images_for_this_item = fallback_images
                                    total_images_downloaded_overall += fallback_images
                                    logger.info(f"✅ Fallback exitoso: {fallback_images} imágenes descargadas con {fallback_sku}")

                                    if _add_processing_event:
                                        _add_processing_event("success", f"Fallback exitoso con {fallback_sku}: {fallback_images} imágenes", sku=fallback_sku)

                                    break  # Salir del loop de fallback
                                else:
                                    logger.info(f"⚠️ Fallback {fallback_sku} tampoco tiene imágenes. Continuando...")
                        except ValueError:
                            # SKU no encontrado en grupo (no debería pasar)
                            logger.warning(f"SKU {current_sku} no encontrado en su grupo para fallback")

                # LÓGICA DE AGRUPACIÓN: Registrar éxito del grupo
                if group_by_parent_color and 'parent_color_group' in item_data:
                    group_key = item_data['parent_color_group']
                    # Marcar grupo como exitoso si se descargaron imágenes
                    successful_groups[group_key] = (images_for_this_item > 0)

                # NUEVO: Registrar resultado del procesamiento
                if _add_processing_event:
                    if images_for_this_item > 0:
                        _add_processing_event("success", f"SKU {item_log_name}: {images_for_this_item} imágenes descargadas", sku=item_log_name)
                    else:
                        _add_processing_event("warning", f"SKU {item_log_name}: No se encontraron imágenes", sku=item_log_name)

            except Exception as e_item_processing:
                # Capturar cualquier error inesperado durante el procesamiento de un ítem
                # para que el bucle pueda continuar con los siguientes ítems.
                logger.error(f"Error crítico procesando el {item_log_prefix}: {e_item_processing}", exc_info=True)

                # NUEVO: Registrar error
                if _add_processing_event:
                    _add_processing_event("error", f"Error procesando SKU {item_log_name}: {str(e_item_processing)}", sku=item_log_name)

            items_processed_count += 1

            # Actualizar progreso final para este SKU
            if APP_STATE:
                APP_STATE["processed_skus"] = index + 1

            # DELAY ENTRE SKUS para evitar rate limiting (CON JITTER)
            if index < total_items_to_process - 1:  # No hacer delay después del último item
                # NUEVO: Verificar cancelación durante el delay
                _check_cancellation(APP_STATE)

                # MEJORA: Usar delay adaptativo con jitter aleatorio
                adaptive_delay = _get_adaptive_delay(DELAY_BETWEEN_SKUS, is_large_batch, add_jitter=True)
                logger.info(f"Esperando {adaptive_delay:.2f}s antes del siguiente SKU...")

                # MEJORADO: Hacer el sleep interrompible dividiendo en chunks pequeños
                _interruptible_sleep(adaptive_delay, APP_STATE)
            
    except DownloadCancelledException:
        # Re-lanzar la excepción para que sea manejada por el nivel superior
        logger.info(f"Descarga cancelada. Se procesaron {items_processed_count} de {total_items_to_process} SKUs.")
        if _add_processing_event:
            _add_processing_event("warning", f"Descarga cancelada: {total_images_downloaded_overall} imágenes descargadas de {items_processed_count} productos antes de la cancelación")
        raise

    # NUEVO: Registrar resumen final
    if _add_processing_event:
        if APP_STATE and APP_STATE.get("should_cancel_download", False):
            summary = f"Descarga cancelada: {total_images_downloaded_overall} imágenes descargadas de {items_processed_count} productos antes de la cancelación"
            if skipped_by_grouping > 0:
                summary += f". {skipped_by_grouping} SKUs omitidos por agrupación."
            _add_processing_event("warning", summary)
        else:
            summary = f"Descarga completada: {total_images_downloaded_overall} imágenes descargadas de {items_processed_count} productos"
            if skipped_by_grouping > 0:
                summary += f". {skipped_by_grouping} SKUs omitidos por agrupación."
            _add_processing_event("info", summary)

    # Construir mensaje final con información de carpetas omitidas
    message_parts = [f"Proceso de descarga completado. Ítems procesados: {items_processed_count}/{total_items_to_process}, Imágenes descargadas: {total_images_downloaded_overall}"]

    if skipped_count > 0:
        message_parts.append(f"Carpetas omitidas (ya existían): {skipped_count}")

    if skipped_by_grouping > 0:
        message_parts.append(f"SKUs omitidos por agrupación padre+color: {skipped_by_grouping}")

    final_message = ". ".join(message_parts) + "."

    logger.info(final_message)

    return {
        "success": True,
        "message": final_message,
        "total_items_processed": items_processed_count,
        "total_images_downloaded": total_images_downloaded_overall,
        "skipped_count": skipped_count,
        "skipped_by_grouping": skipped_by_grouping,
        "existing_folders": existing_folders[:50] if len(existing_folders) > 50 else existing_folders  # Limitar para no enviar listas enormes
    }

# --- Bloque de prueba para ejecutar el módulo directamente (opcional) ---
if __name__ == "__main__":
    print("Ejecutando prueba del módulo downloader...")
    
    # Crear un DataFrame de prueba y guardarlo como Excel
    # Asegúrate de que los SKU_CL sean strings si pandas los puede interpretar como números.
    test_data = {
        'SKU_CL': ['2000379090900', '2000377528168', 'MPM0000000001', '2000379090900.0', 'INVALID_SKU_TEST', None, ' ', '2000404905015'],
        'CODDEPTO': ['2010', '2030', None, '2010.0', '2040', '2050', '2060', ''], # CODDEPTO es opcional
        'OtroDato': ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
    }
    test_df = pd.DataFrame(test_data)
    test_excel_filename = "test_skus_downloader_temp.xlsx"
    test_df.to_excel(test_excel_filename, index=False)

    # Definir una carpeta de destino para las pruebas (se creará y limpiará)
    test_output_destination_folder = os.path.join(os.path.dirname(__file__), "test_download_output")

    if os.path.exists(test_output_destination_folder):
        import shutil
        shutil.rmtree(test_output_destination_folder) # Limpiar ejecuciones anteriores
    os.makedirs(test_output_destination_folder, exist_ok=True)
    
    logger.info(f"Excel de prueba: '{os.path.abspath(test_excel_filename)}'")
    logger.info(f"Carpeta de destino para pruebas: '{os.path.abspath(test_output_destination_folder)}'")

    # Probar sin CODDEPTO (solo descarga primaria)
    # results = execute_download_process(test_excel_filename, "SKU_CL", test_output_destination_folder)
    
    # Probar con CODDEPTO (intenta descarga primaria y luego secundaria si es necesario)
    results = execute_download_process(test_excel_filename, "SKU_CL", test_output_destination_folder, coddepto_column_name="CODDEPTO")
    
    print(f"\nResultados finales de la prueba:\n{results}")

    # Opcional: limpiar el archivo Excel de prueba
    # os.remove(test_excel_filename)
    # La carpeta test_download_output permanece para inspección.