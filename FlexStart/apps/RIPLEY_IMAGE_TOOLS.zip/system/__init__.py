"""
Ripley Image Tools - System Package
Contiene todos los módulos del sistema: backend, frontend, apps, y configuraciones.
"""

__version__ = "1.0.0"
