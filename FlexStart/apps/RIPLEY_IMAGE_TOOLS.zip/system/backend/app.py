"""
Ripley Image Tools - Backend Gateway
Gateway FastAPI que integra 3 aplicaciones con autenticación SharePoint.
"""

import sys
import secrets
import logging
from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from starlette.middleware.sessions import SessionMiddleware

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Paths
BACKEND_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BACKEND_DIR.parent
APPS_DIR = PROJECT_ROOT / "apps"
FRONTEND_DIR = PROJECT_ROOT / "frontend"

logger.info(f"Project root: {PROJECT_ROOT}")
logger.info(f"Apps directory: {APPS_DIR}")
logger.info(f"Frontend directory: {FRONTEND_DIR}")

# Crear aplicación FastAPI
app = FastAPI(
    title="Ripley Image Tools",
    version="1.0.0",
    description="Herramientas de procesamiento de imágenes para Ripley"
)

# Session middleware (DEBE IR PRIMERO antes del auth middleware)
app.add_middleware(
    SessionMiddleware,
    secret_key=secrets.token_urlsafe(32),
    session_cookie="ripley_session",
    max_age=3600 * 8,  # 8 horas
    same_site="lax"
)

# Auth middleware
logger.info("Configurando middleware de autenticación...")
from .auth.middleware import auth_middleware
app.middleware("http")(auth_middleware)

# Montar archivos estáticos (frontend)
logger.info("Montando archivos estáticos...")
app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

# Rutas básicas
@app.get("/")
async def root():
    """Página de login."""
    return FileResponse(FRONTEND_DIR / "index.html")

@app.get("/dashboard.html")
async def dashboard():
    """Dashboard principal (protegido por auth middleware)."""
    return FileResponse(FRONTEND_DIR / "dashboard.html")

@app.get("/health")
async def health():
    """Health check para el launcher."""
    return {"status": "healthy", "version": "1.0.0"}

# Montar endpoints de autenticación
logger.info("Registrando endpoints de autenticación...")
from .auth import auth_router
app.include_router(auth_router)

# === INTEGRAR 3 APLICACIONES ===

def integrate_app(app_name: str):
    """
    Integra una aplicación al gateway.

    Args:
        app_name: Nombre de la carpeta de la app (ej: descargador_imagenes)
    """
    logger.info(f"Integrando aplicación: {app_name}")

    try:
        import importlib.util

        app_path = APPS_DIR / app_name / "backend" / "app.py"

        if not app_path.exists():
            logger.error(f"No se encontró {app_path}")
            return

        # Agregar path del PARENT de backend al sys.path para permitir imports como paquete
        # Por ejemplo, para apps/descargador_imagenes/backend, agregamos apps/descargador_imagenes
        app_root_path = str(APPS_DIR / app_name)
        path_was_added = False
        if app_root_path not in sys.path:
            sys.path.insert(0, app_root_path)
            path_was_added = True
            logger.debug(f"Agregado al sys.path: {app_root_path}")

        try:
            # Cargar el módulo como un paquete completo: backend.app
            # Esto permite que los imports relativos (.config, .models, etc.) funcionen
            package_name = f"{app_name}_backend"

            # Crear el paquete backend primero
            backend_init = APPS_DIR / app_name / "backend" / "__init__.py"
            if backend_init.exists():
                spec_pkg = importlib.util.spec_from_file_location(package_name, backend_init)
                pkg_module = importlib.util.module_from_spec(spec_pkg)
                sys.modules[package_name] = pkg_module
                spec_pkg.loader.exec_module(pkg_module)

            # Ahora cargar el módulo app.py dentro del paquete
            spec = importlib.util.spec_from_file_location(f"{package_name}.app", app_path, submodule_search_locations=[str(APPS_DIR / app_name / "backend")])
            module = importlib.util.module_from_spec(spec)
            module.__package__ = package_name
            sys.modules[f"{package_name}.app"] = module

            spec.loader.exec_module(module)
        finally:
            # Limpiar sys.path después de cargar para evitar conflictos entre apps
            if path_was_added and app_root_path in sys.path:
                sys.path.remove(app_root_path)
                logger.debug(f"Removido del sys.path: {app_root_path}")

            # Limpiar módulos del caché para evitar conflictos (models, config, utils, etc.)
            modules_to_clean = ['models', 'config', 'utils', 'core_logic']
            for mod_name in list(sys.modules.keys()):
                for prefix in modules_to_clean:
                    if mod_name == prefix or (mod_name.startswith(prefix + '.') and '.' in mod_name):
                        # Limpiar módulos que coinciden exactamente o submódulos
                        try:
                            del sys.modules[mod_name]
                            logger.debug(f"Limpiado del caché: {mod_name}")
                        except KeyError:
                            pass
                        break

        # Obtener router
        if not hasattr(module, 'get_router'):
            logger.error(f"{app_name} no tiene función get_router()")
            return

        router = module.get_router()
        app.include_router(router)
        logger.info(f"✅ Router de {app_name} integrado")

        # Montar archivos estáticos
        frontend_dir = APPS_DIR / app_name / "frontend"
        if frontend_dir.exists():
            app.mount(
                f"/{app_name}/static",
                StaticFiles(directory=str(frontend_dir)),
                name=f"{app_name}_static"
            )
            logger.info(f"✅ Archivos estáticos de {app_name} montados en /{app_name}/static")
        else:
            logger.warning(f"⚠️ No se encontró directorio frontend para {app_name}")

    except Exception as e:
        logger.error(f"❌ Error integrando {app_name}: {e}", exc_info=True)

# Integrar las 3 aplicaciones
logger.info("=" * 60)
logger.info("INTEGRANDO APLICACIONES")
logger.info("=" * 60)

integrate_app("descargador_imagenes")
integrate_app("descargador_imagenes_peru")
integrate_app("flujo_productivo")

logger.info("=" * 60)
logger.info("✅ Gateway de Ripley Image Tools iniciado correctamente")
logger.info("=" * 60)
