"""Authentication endpoints."""

import logging
from fastapi import APIRouter, Request
from .sharepoint_auth import get_sharepoint_authenticator

router = APIRouter(prefix="/api/auth", tags=["auth"])

@router.post("/login")
async def login(request: Request):
    """
    Inicia flujo de autenticación SharePoint.
    Abre popup del navegador para login con Microsoft.
    """
    auth = get_sharepoint_authenticator()

    try:
        logging.info("Iniciando autenticación SharePoint...")
        token = auth.get_token()

        # Guardar token en sesión
        request.session["access_token"] = token

        logging.info("✅ Autenticación exitosa")
        return {"success": True, "redirect": "/dashboard.html"}

    except Exception as e:
        logging.error(f"❌ Error de autenticación: {e}")
        return {"success": False, "error": str(e)}

@router.post("/logout")
async def logout(request: Request):
    """Cierra sesión del usuario."""
    request.session.clear()
    logging.info("Usuario desconectado")
    return {"success": True}

@router.get("/status")
async def status(request: Request):
    """Verifica si el usuario está autenticado."""
    token = request.session.get("access_token")
    return {"authenticated": token is not None}

# Exportar router para uso en app.py
auth_router = router
