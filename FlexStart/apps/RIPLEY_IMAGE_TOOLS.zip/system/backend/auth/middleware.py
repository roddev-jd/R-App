"""Authentication middleware for protecting routes."""

from fastapi import Request, HTTPException
from fastapi.responses import RedirectResponse

# Rutas públicas que no requieren autenticación
PUBLIC_ROUTES = {"/", "/api/auth/login", "/api/auth/logout", "/health", "/static"}

async def auth_middleware(request: Request, call_next):
    """Middleware que verifica autenticación en todas las rutas excepto públicas."""
    path = request.url.path

    # Permitir rutas públicas
    if any(path.startswith(route) for route in PUBLIC_ROUTES):
        return await call_next(request)

    # Verificar token en sesión
    token = request.session.get("access_token")

    if not token:
        # Si es una petición API, retornar 401
        if path.startswith("/api/"):
            raise HTTPException(status_code=401, detail="No autenticado")
        # Si es una página web, redirigir a login
        else:
            return RedirectResponse(url="/")

    # Token válido - agregar usuario al request state
    request.state.user = {"token": token}
    return await call_next(request)
