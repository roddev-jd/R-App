"""SharePoint authentication module using MSAL."""

# Standard library
import getpass
import logging
from pathlib import Path
from typing import Optional

# Third-party
import msal

class SharePointAuth:
    """Handles SharePoint authentication using Microsoft Authentication Library (MSAL)."""
    
    # Azure CLI public client ID
    CLIENT_ID = "04b07795-8ddb-461a-bbee-02f9e1bf7b46"
    AUTHORITY = "https://login.microsoftonline.com/common"
    SCOPES = ["https://graph.microsoft.com/.default"]
    CACHE_DIR_NAME = ".ripley_imagetools_cache"

    def __init__(self) -> None:
        """Initialize SharePoint authentication with user-specific token cache."""
        logging.info("🔐 Creating new SharePointAuth instance")
        self.cache_filename = self._get_cache_filename()
        self.cache = self._load_token_cache()
        self.app = self._create_msal_app()
        logging.debug(f"🔐 SharePointAuth initialized - cache file: {self.cache_filename}")
    
    def _get_cache_filename(self) -> Path:
        """Get user-specific cache filename."""
        current_user = getpass.getuser()
        cache_dir = Path.home() / self.CACHE_DIR_NAME
        cache_dir.mkdir(exist_ok=True)
        return cache_dir / f"sharepoint_token_cache_{current_user}.bin"
    
    def _load_token_cache(self) -> msal.SerializableTokenCache:
        """Load existing token cache or create new one."""
        cache = msal.SerializableTokenCache()
        if self.cache_filename.exists():
            cache.deserialize(self.cache_filename.read_text(encoding='utf-8'))
        return cache
    
    def _create_msal_app(self) -> msal.PublicClientApplication:
        """Create MSAL public client application."""
        return msal.PublicClientApplication(
            self.CLIENT_ID,
            authority=self.AUTHORITY,
            token_cache=self.cache,
            verify=False
        )

    def _save_cache(self) -> None:
        """Save token cache to disk if it has changed."""
        if self.cache.has_state_changed:
            self.cache_filename.write_text(self.cache.serialize(), encoding='utf-8')

    def get_token(self) -> str:
        """Get access token, trying silent acquisition first, then interactive."""
        # Try silent token acquisition first
        result = self._try_silent_acquisition()
        
        # Fall back to interactive acquisition if needed
        if not result:
            result = self._try_interactive_acquisition()
        
        return self._extract_token(result)
    
    def _try_silent_acquisition(self) -> Optional[dict]:
        """Attempt silent token acquisition using cached accounts."""
        accounts = self.app.get_accounts()
        if not accounts:
            logging.debug("🔒 No cached accounts found - will require interactive auth")
            return None

        logging.debug(f"🔒 Found {len(accounts)} cached account(s) - attempting silent token acquisition")
        result = self.app.acquire_token_silent(self.SCOPES, account=accounts[0])

        # MEJORA: Validar que el resultado contiene un token válido
        if result and "access_token" in result:
            logging.info("✅ Token acquired silently from cache")
            self._save_cache()
            return result
        elif result and "error" in result:
            # El resultado contiene un error (ej: token expirado, refresh failed)
            logging.warning(f"⚠️ Silent token acquisition failed: {result.get('error')} - {result.get('error_description', '')}")
            return None  # Forzar auth interactiva

        # Resultado inesperado o vacío
        logging.debug("🔒 Silent acquisition returned empty/invalid result")
        return None
    
    def _try_interactive_acquisition(self) -> dict:
        """Perform interactive token acquisition."""
        logging.info("🔓 Starting interactive token acquisition (browser window will open)")
        result = self.app.acquire_token_interactive(self.SCOPES)
        if result and "access_token" in result:
            logging.info("✅ Interactive authentication successful")
            self._save_cache()
        else:
            logging.error(f"❌ Interactive authentication failed: {result.get('error', 'Unknown error')}")
        return result
    
    def _extract_token(self, result: dict) -> str:
        """Extract access token from MSAL result."""
        if "access_token" in result:
            return result["access_token"]
        
        error_msg = result.get("error_description", "No se pudo adquirir un token.")
        raise Exception(error_msg)

# Instancia global para usar en toda la aplicación
_auth_instance = None

def get_valid_token() -> Optional[dict]:
    """
    Función compatible con el código existente del backend.
    Retorna información del token en formato dict.
    """
    global _auth_instance
    
    if _auth_instance is None:
        _auth_instance = SharePointAuth()
    
    try:
        access_token = _auth_instance.get_token()
        return {
            'access_token': access_token,
            'token_type': 'Bearer'
        }
    except Exception as e:
        logging.warning(f"Error obteniendo token de SharePoint: {e}")
        return None


def get_sharepoint_authenticator() -> SharePointAuth:
    """
    Obtiene la instancia única de SharePointAuth (patrón Singleton).
    Reutiliza la misma instancia para mantener la sesión token viva.

    Esta función es utilizada por los módulos async (main_logic_async.py,
    async_sharepoint_service.py) y el código síncrono legacy.

    Returns:
        SharePointAuth: Instancia única del autenticador
    """
    global _auth_instance

    if _auth_instance is None:
        logging.info("🔐 Initializing SINGLETON SharePointAuth instance (first call)")
        _auth_instance = SharePointAuth()
    else:
        logging.debug("♻️ Reusing existing SharePointAuth singleton instance")

    return _auth_instance


def main() -> None:
    """Example usage - will be moved to main_logic.py."""
    auth = SharePointAuth()
    try:
        token = auth.get_token()
        print("Token adquirido con éxito!")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main() 