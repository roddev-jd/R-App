"""
Ripley Image Tools - GitHub Updater
Sistema de actualización basado en GitHub Releases
"""

import requests
import warnings
import tempfile
import zipfile
import shutil
import logging
from pathlib import Path
from packaging import version as pkg_version

# Deshabilitar advertencias SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

logger = logging.getLogger(__name__)

class GitHubUpdater:
    """Actualizador que obtiene releases desde GitHub."""

    def __init__(self, repo_owner: str, repo_name: str):
        self.repo = f"{repo_owner}/{repo_name}"
        self.api_base = "https://api.github.com"
        logger.info(f"GitHubUpdater initialized for {self.repo}")

    def get_current_version(self) -> str:
        """Lee versión actual del archivo VERSION.txt."""
        version_file = Path(__file__).parent / "VERSION.txt"
        if version_file.exists():
            return version_file.read_text().strip()
        return "0.0.0"

    def check_for_updates(self) -> dict:
        """
        Verifica si hay actualizaciones en GitHub.

        Returns:
            dict: Información de actualización con keys:
                - has_update (bool)
                - current_version (str)
                - new_version (str) - si has_update es True
                - download_url (str) - si has_update es True
                - notes (str) - si has_update es True
                - error (str) - si hubo error
        """
        try:
            current = pkg_version.parse(self.get_current_version())
            latest = self.get_latest_release()
            remote_version = pkg_version.parse(latest["version"])

            if remote_version > current:
                logger.info(f"Update available: {current} -> {remote_version}")
                return {
                    "has_update": True,
                    "current_version": str(current),
                    "new_version": latest["version"],
                    "download_url": latest["url"],
                    "notes": latest["notes"]
                }
            else:
                logger.info(f"No update available. Current: {current}")
                return {
                    "has_update": False,
                    "current_version": str(current)
                }
        except Exception as e:
            logger.error(f"Error checking for updates: {e}")
            return {
                "has_update": False,
                "error": str(e)
            }

    def get_latest_release(self) -> dict:
        """
        Obtiene último release desde GitHub API.

        Returns:
            dict: Información del release con keys:
                - version (str)
                - url (str): URL de descarga del .zip
                - notes (str): Release notes
                - published_at (str)
        """
        url = f"{self.api_base}/repos/{self.repo}/releases/latest"

        logger.info(f"Fetching latest release from {url}")
        response = requests.get(url, timeout=10, verify=False)
        response.raise_for_status()
        data = response.json()

        return {
            "version": data["tag_name"].lstrip("v"),  # v1.0.0 → 1.0.0
            "url": self._get_zip_asset_url(data["assets"]),
            "notes": data["body"],
            "published_at": data["published_at"]
        }

    def _get_zip_asset_url(self, assets: list) -> str:
        """Encuentra asset .zip en el release."""
        for asset in assets:
            if asset["name"].endswith(".zip"):
                logger.info(f"Found zip asset: {asset['name']}")
                return asset["browser_download_url"]
        raise ValueError("No se encontró archivo .zip en el release")

    def perform_update(self, download_url: str, progress_callback=None) -> dict:
        """
        Descarga y aplica actualización.

        Args:
            download_url: URL del .zip a descargar
            progress_callback: Función opcional para reportar progreso (0-100)

        Returns:
            dict: Resultado con keys:
                - success (bool)
                - error (str) - si success es False
        """
        logger.info("Starting update process...")

        # 1. Crear backup
        backup_dir = self._create_backup()
        logger.info(f"Backup created at {backup_dir}")

        try:
            # 2. Descargar release
            zip_path = self._download_release(download_url, progress_callback)
            logger.info(f"Release downloaded to {zip_path}")

            # 3. Extraer en directorio temporal
            temp_extract = tempfile.mkdtemp()
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_extract)
            logger.info(f"Extracted to {temp_extract}")

            # 4. Limpiar directorio actual (excepto Proceso/ y cache)
            self._clean_installation_directory()
            logger.info("Installation directory cleaned")

            # 5. Copiar archivos nuevos
            self._install_fresh_version(temp_extract)
            logger.info("New version installed")

            # 6. Limpiar temporales
            shutil.rmtree(temp_extract)
            Path(zip_path).unlink()
            logger.info("Temporary files cleaned")

            return {"success": True}

        except Exception as e:
            logger.error(f"Update failed: {e}. Rolling back...")
            # Rollback
            self._restore_from_backup(backup_dir)
            return {"success": False, "error": str(e)}

    def _create_backup(self) -> Path:
        """Crea backup completo del proyecto."""
        backup_dir = tempfile.mkdtemp(prefix="ripley_backup_")
        project_root = Path(__file__).parent

        preserve_list = [".git", "__pycache__", "Proceso", ".ripley_imagetools_cache"]

        for item in project_root.iterdir():
            if item.name not in preserve_list:
                if item.is_dir():
                    shutil.copytree(item, Path(backup_dir) / item.name)
                else:
                    shutil.copy2(item, backup_dir)

        return Path(backup_dir)

    def _download_release(self, url: str, progress_callback) -> Path:
        """Descarga release con progreso."""
        logger.info(f"Downloading from {url}")
        response = requests.get(url, stream=True, timeout=30, verify=False)
        response.raise_for_status()

        total_size = int(response.headers.get('content-length', 0))
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.zip')

        downloaded = 0
        for chunk in response.iter_content(chunk_size=8192):
            temp_file.write(chunk)
            downloaded += len(chunk)

            if progress_callback and total_size:
                progress = (downloaded / total_size) * 100
                progress_callback(progress)

        temp_file.close()
        return Path(temp_file.name)

    def _clean_installation_directory(self):
        """Limpia directorio manteniendo datos de usuario."""
        project_root = Path(__file__).parent
        preserve = ["Proceso", ".ripley_imagetools_cache", "updater.py", "VERSION.txt"]

        for item in project_root.iterdir():
            if item.name not in preserve:
                try:
                    if item.is_dir():
                        shutil.rmtree(item)
                    else:
                        item.unlink()
                except Exception as e:
                    logger.warning(f"Could not delete {item}: {e}")

    def _install_fresh_version(self, source_dir: Path):
        """Copia archivos nuevos."""
        project_root = Path(__file__).parent

        for item in Path(source_dir).iterdir():
            dest = project_root / item.name
            try:
                if item.is_dir():
                    shutil.copytree(item, dest)
                else:
                    shutil.copy2(item, dest)
            except Exception as e:
                logger.warning(f"Could not copy {item}: {e}")

    def _restore_from_backup(self, backup_dir: Path):
        """Restaura desde backup."""
        project_root = Path(__file__).parent

        # Limpiar
        for item in project_root.iterdir():
            if item.name != ".ripley_imagetools_cache":
                try:
                    if item.is_dir():
                        shutil.rmtree(item)
                    else:
                        item.unlink()
                except:
                    pass

        # Restaurar
        for item in backup_dir.iterdir():
            dest = project_root / item.name
            try:
                if item.is_dir():
                    shutil.copytree(item, dest)
                else:
                    shutil.copy2(item, dest)
            except Exception as e:
                logger.error(f"Could not restore {item}: {e}")
