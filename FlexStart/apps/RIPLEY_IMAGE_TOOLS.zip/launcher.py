"""
Ripley Image Tools - Launcher
Lanzador tkinter para Ripley Image Tools
"""

import tkinter as tk
from tkinter import ttk, messagebox
import threading
import subprocess
import os
import sys
import configparser
import webbrowser
import time
import requests
from pathlib import Path

# Constantes
MIN_PORT = 8005
MAX_PORT = 8050
LAUNCHER_SECTION = "LauncherSettings"
PORT_KEY = "last_used_port"

# --- Funciones de Gestión de Config ---
def get_config_path() -> str:
    """Obtiene la ruta del config.ini del proyecto."""
    return str(Path(__file__).parent / "system" / "config.ini")

def get_version() -> str:
    """Lee la versión actual del archivo VERSION.txt."""
    version_file = Path(__file__).parent / "system" / "VERSION.txt"
    if version_file.exists():
        return version_file.read_text().strip()
    return "1.0.0"

def get_and_update_next_port() -> int:
    """Obtiene y actualiza el siguiente puerto disponible."""
    config_path = get_config_path()
    parser = configparser.ConfigParser(interpolation=None)
    parser.optionxform = str

    try:
        parser.read(config_path, encoding='utf-8')
    except:
        pass

    last_port = parser.getint(LAUNCHER_SECTION, PORT_KEY, fallback=MIN_PORT - 1)
    current_port = last_port + 1
    if not (MIN_PORT <= current_port <= MAX_PORT):
        current_port = MIN_PORT

    if not parser.has_section(LAUNCHER_SECTION):
        parser.add_section(LAUNCHER_SECTION)
    parser.set(LAUNCHER_SECTION, PORT_KEY, str(current_port))

    try:
        with open(config_path, 'w', encoding='utf-8') as configfile:
            parser.write(configfile)
    except Exception as e:
        print(f"Advertencia: No se pudo guardar el puerto: {e}")

    return current_port

# --- Clase Principal del Launcher ---
class RipleyImageToolsLauncher(tk.Tk):
    def __init__(self):
        super().__init__()

        # Configuración de la ventana
        self.version = get_version()
        self.title(f"Ripley Image Tools v{self.version}")
        self.geometry("450x380")
        self.configure(bg="#fafbfe")
        self.resizable(False, False)

        # Variables de estado
        self.initial_port = get_and_update_next_port()
        self.server_process = None
        self.server_ready = False
        self.browser_opened = False
        self.update_info = None

        # Crear interfaz
        self.create_widgets()

        # Iniciar verificación de actualizaciones
        self.check_for_updates_non_blocking()

        # Protocolo de cierre
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

    def create_widgets(self):
        """Crea todos los widgets de la interfaz."""
        # Header compacto
        header_frame = tk.Frame(self, bg="#4154f1", height=60)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)

        # Título con fuente Raleway
        title_label = tk.Label(
            header_frame,
            text="Ripley Image Tools",
            bg="#4154f1",
            fg="white",
            font=("Raleway", 16, "bold")
        )
        title_label.pack(pady=18)

        # Main content compacto
        main_frame = tk.Frame(self, bg="#fafbfe")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=15)

        # Version compacto
        version_label = tk.Label(
            main_frame,
            text=f"v{self.version}",
            bg="#fafbfe",
            fg="#717592",
            font=("Nunito", 9)
        )
        version_label.pack(pady=(0, 8))

        # Status section compacto
        self.status_label = tk.Label(
            main_frame,
            text="● Listo para iniciar",
            bg="#fafbfe",
            fg="#151f3d",
            font=("Nunito", 11, "bold")
        )
        self.status_label.pack(pady=6)

        self.port_label = tk.Label(
            main_frame,
            text=f"Puerto: {self.initial_port}",
            bg="#fafbfe",
            fg="#717592",
            font=("Nunito", 9)
        )
        self.port_label.pack(pady=3)

        # Launch button compacto
        self.launch_button = tk.Button(
            main_frame,
            text="▶  Iniciar Aplicación",
            command=self.start_server_thread,
            bg="#ea338c",
            fg="white",
            font=("Nunito", 12, "bold"),
            relief=tk.FLAT,
            cursor="hand2",
            padx=25,
            pady=10,
            borderwidth=0,
            highlightthickness=0
        )
        self.launch_button.pack(pady=12)
        
        # Hover effect simulation (funcionalidad básica)
        self.launch_button.bind("<Enter>", lambda e: self.launch_button.config(bg="#f25ca3"))
        self.launch_button.bind("<Leave>", lambda e: self.launch_button.config(bg="#ea338c") if self.launch_button["state"] != "disabled" else None)

        # Progress frame compacto
        self.progress_frame = tk.Frame(main_frame, bg="#fafbfe")
        self.progress_frame.pack(fill=tk.X, pady=8)

        self.progress_bar = ttk.Progressbar(
            self.progress_frame,
            mode='indeterminate',
            length=350
        )
        self.progress_bar.pack()
        self.progress_bar.pack_forget()  # Ocultar inicialmente

        # Update info label compacto
        self.update_label = tk.Label(
            main_frame,
            text="",
            bg="#fafbfe",
            fg="#717592",
            font=("Nunito", 8),
            wraplength=400
        )
        self.update_label.pack(pady=6)

        # Footer compacto
        footer_frame = tk.Frame(self, bg="#fafbfe", height=30)
        footer_frame.pack(fill=tk.X, side=tk.BOTTOM)
        footer_frame.pack_propagate(False)

        tk.Label(
            footer_frame,
            text="© 2025 E-Commerce Ripley",
            bg="#fafbfe",
            fg="#9499ab",
            font=("Nunito", 7)
        ).pack(side=tk.BOTTOM, pady=8)

    def check_for_updates_non_blocking(self):
        """Verifica actualizaciones en segundo plano."""
        thread = threading.Thread(target=self._update_check_worker, daemon=True)
        thread.start()

    def _update_check_worker(self):
        """Worker que verifica actualizaciones (en thread separado)."""
        try:
            from system.updater import GitHubUpdater

            # Leer configuración
            config_path = get_config_path()
            parser = configparser.ConfigParser(interpolation=None)
            parser.read(config_path, encoding='utf-8')

            repo_owner = parser.get("GitHub", "repo_owner", fallback="roddev-jd")
            repo_name = parser.get("GitHub", "repo_name", fallback="ripley-image-tools")

            updater = GitHubUpdater(repo_owner, repo_name)
            self.update_info = updater.check_for_updates()
            self.after(100, self.render_update_status)
        except Exception as e:
            print(f"Error checking updates: {e}")

    def render_update_status(self):
        """Renderiza el estado de actualización en el UI."""
        if not self.update_info:
            return

        if self.update_info.get("has_update"):
            new_version = self.update_info.get("new_version", "desconocida")
            self.update_label.config(
                text=f"⚡ Nueva versión disponible: v{new_version} · Haz clic aquí para actualizar",
                fg="#ea338c",
                cursor="hand2",
                font=("Nunito", 10, "bold")
            )
            self.update_label.bind("<Button-1>", lambda e: self.show_update_dialog())

    def show_update_dialog(self):
        """Muestra diálogo para confirmar actualización."""
        if not self.update_info or not self.update_info.get("has_update"):
            return

        result = messagebox.askyesno(
            "Actualización Disponible",
            f"Hay una nueva versión disponible: v{self.update_info['new_version']}\n\n"
            f"Versión actual: v{self.version}\n\n"
            "¿Deseas actualizar ahora?\n\n"
            "Nota: La aplicación se cerrará durante la actualización."
        )

        if result:
            self.perform_update()

    def perform_update(self):
        """Ejecuta la actualización."""
        if not self.update_info or not self.update_info.get("has_update"):
            return

        try:
            from system.updater import GitHubUpdater

            # Leer configuración
            config_path = get_config_path()
            parser = configparser.ConfigParser(interpolation=None)
            parser.read(config_path, encoding='utf-8')

            repo_owner = parser.get("GitHub", "repo_owner", fallback="roddev-jd")
            repo_name = parser.get("GitHub", "repo_name", fallback="ripley-image-tools")

            updater = GitHubUpdater(repo_owner, repo_name)
            download_url = self.update_info.get("download_url")

            # Cerrar servidor si está corriendo
            if self.server_process:
                try:
                    self.server_process.terminate()
                    self.server_process.wait(timeout=5)
                except:
                    self.server_process.kill()
                self.server_process = None

            # Mostrar progreso
            progress_window = tk.Toplevel(self)
            progress_window.title("Actualizando...")
            progress_window.geometry("400x150")
            progress_window.transient(self)
            progress_window.grab_set()

            progress_label = tk.Label(progress_window, text="Descargando actualización...", font=("Nunito", 11))
            progress_label.pack(pady=20)

            progress_bar = ttk.Progressbar(progress_window, length=300, mode='determinate')
            progress_bar.pack(pady=10)

            def update_progress(percent):
                progress_bar['value'] = percent
                progress_window.update_idletasks()

            # Ejecutar actualización en thread
            def update_worker():
                result = updater.perform_update(download_url, progress_callback=update_progress)

                if result.get("success"):
                    progress_window.destroy()
                    messagebox.showinfo(
                        "Actualización Completa",
                        f"La actualización a la versión {self.update_info['new_version']} "
                        "se completó exitosamente.\n\n"
                        "La aplicación se cerrará ahora. Por favor, reiníciala para usar la nueva versión."
                    )
                    self.destroy()
                else:
                    progress_window.destroy()
                    messagebox.showerror(
                        "Error de Actualización",
                        f"No se pudo completar la actualización:\n\n{result.get('error', 'Error desconocido')}"
                    )

            thread = threading.Thread(target=update_worker, daemon=True)
            thread.start()

        except Exception as e:
            messagebox.showerror(
                "Error",
                f"Error al intentar actualizar:\n\n{str(e)}"
            )

    def start_server_thread(self):
        """Inicia el servidor en un thread separado."""
        if self.server_process:
            messagebox.showwarning("Advertencia", "El servidor ya está en ejecución")
            return

        self.launch_button.config(state=tk.DISABLED, text="Iniciando...")
        self.progress_bar.pack()
        self.progress_bar.start()
        self.status_label.config(text="● Iniciando servidor...", fg="#4154f1")

        thread = threading.Thread(target=self._server_worker, daemon=True)
        thread.start()

    def _server_worker(self):
        """Worker que inicia el servidor uvicorn."""
        try:
            # Comando para iniciar uvicorn
            app_module = "system.backend.app:app"
            cmd = [
                sys.executable, "-m", "uvicorn",
                app_module,
                "--host", "127.0.0.1",
                "--port", str(self.initial_port),
                "--reload"
            ]

            # Iniciar proceso
            self.server_process = subprocess.Popen(
                cmd,
                cwd=str(Path(__file__).parent),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True
            )

            # Esperar a que el servidor esté listo
            self.after(100, self.check_server_responsive)

        except Exception as e:
            self.after(100, lambda: self.show_server_error(str(e)))

    def check_server_responsive(self):
        """Verifica si el servidor está respondiendo."""
        try:
            url = f"http://127.0.0.1:{self.initial_port}/health"
            response = requests.get(url, timeout=2, verify=False)

            if response.status_code == 200:
                self.server_ready = True
                self.on_server_ready()
            else:
                # Reintentar
                self.after(500, self.check_server_responsive)
        except:
            # Servidor aún no está listo - reintentar
            self.after(500, self.check_server_responsive)

    def on_server_ready(self):
        """Callback cuando el servidor está listo."""
        self.progress_bar.stop()
        self.progress_bar.pack_forget()
        self.status_label.config(text="● Servidor activo", fg="#10b981")
        self.launch_button.config(
            text="✓ Servidor Activo",
            state=tk.DISABLED,
            bg="#10b981"
        )

        # Abrir navegador
        if not self.browser_opened:
            self.browser_opened = True
            url = f"http://127.0.0.1:{self.initial_port}/"
            webbrowser.open(url)

            # Mostrar botón para reabrir
            self.reopen_button = tk.Button(
                self.progress_frame,
                text="🌐 Abrir en navegador",
                command=lambda: webbrowser.open(url),
                bg="#f0f0f0",
                relief=tk.FLAT,
                cursor="hand2",
                padx=20,
                pady=10
            )
            self.reopen_button.pack(pady=10)

    def show_server_error(self, error_msg):
        """Muestra error de servidor."""
        self.progress_bar.stop()
        self.progress_bar.pack_forget()
        self.status_label.config(text="● Error al iniciar servidor", fg="#ef4444")
        self.launch_button.config(state=tk.NORMAL, text="▶  Reintentar", bg="#ea338c")

        messagebox.showerror(
            "Error al iniciar servidor",
            f"No se pudo iniciar el servidor:\n\n{error_msg}"
        )

    def on_closing(self):
        """Maneja el cierre de la aplicación."""
        if self.server_process:
            result = messagebox.askyesno(
                "Cerrar Aplicación",
                "¿Estás seguro de que deseas cerrar la aplicación?\n\n"
                "Esto cerrará el servidor y todas las herramientas."
            )

            if not result:
                return

            # Terminar proceso del servidor
            try:
                self.server_process.terminate()
                self.server_process.wait(timeout=5)
            except:
                self.server_process.kill()

        self.destroy()

# --- Entry Point ---
if __name__ == "__main__":
    app = RipleyImageToolsLauncher()
    app.mainloop()
